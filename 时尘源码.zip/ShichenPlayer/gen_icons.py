#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""时尘播放器 —— 手绘图标生成器（矢量风格线性图标 / 品牌图标）"""
import os, math
from PIL import Image, ImageDraw

RES = "/data/workspace/shichen/res"
WHITE = (255, 255, 255, 255)
SS = 4  # supersample

DENS = {"mdpi": 1.0, "hdpi": 1.5, "xhdpi": 2.0, "xxhdpi": 3.0, "xxxhdpi": 4.0}


class Pen:
    def __init__(self, draw, px):
        self.d = draw
        self.px = px            # 像素 / dp
        self.w = 1.75 * px      # 线宽

    def P(self, x, y):
        return (x * self.px, y * self.px)

    def line(self, x1, y1, x2, y2, w=None):
        w = self.w if w is None else w * self.px
        a, b = self.P(x1, y1), self.P(x2, y2)
        self.d.line([a, b], fill=WHITE, width=int(round(w)))
        r = w / 2.0
        for p in (a, b):
            self.d.ellipse([p[0] - r, p[1] - r, p[0] + r, p[1] + r], fill=WHITE)

    def poly(self, pts, close=False, w=None):
        w = self.w if w is None else w * self.px
        p = [self.P(*q) for q in pts]
        if close:
            p.append(p[0])
        self.d.line(p, fill=WHITE, width=int(round(w)))
        r = w / 2.0
        for q in p:
            self.d.ellipse([q[0] - r, q[1] - r, q[0] + r, q[1] + r], fill=WHITE)

    def rect(self, x1, y1, x2, y2, w=None, r=1.2):
        """圆角矩形描边"""
        w = self.w if w is None else w * self.px
        rr = r * self.px
        box = [x1 * self.px, y1 * self.px, x2 * self.px, y2 * self.px]
        self.d.rounded_rectangle(box, radius=rr, outline=WHITE, width=int(round(w)))

    def frect(self, x1, y1, x2, y2, r=1.2):
        rr = r * self.px
        self.d.rounded_rectangle([x1 * self.px, y1 * self.px, x2 * self.px, y2 * self.px],
                                 radius=rr, fill=WHITE)

    def circle(self, cx, cy, r, w=None):
        w = self.w if w is None else w * self.px
        c = self.P(cx, cy)
        R = r * self.px
        self.d.ellipse([c[0] - R, c[1] - R, c[0] + R, c[1] + R],
                       outline=WHITE, width=int(round(w)))

    def fcircle(self, cx, cy, r):
        c = self.P(cx, cy)
        R = r * self.px
        self.d.ellipse([c[0] - R, c[1] - R, c[0] + R, c[1] + R], fill=WHITE)

    def arc(self, cx, cy, r, a0, a1, w=None):
        w = self.w if w is None else w * self.px
        c = self.P(cx, cy)
        R = r * self.px
        self.d.arc([c[0] - R, c[1] - R, c[0] + R, c[1] + R], a0, a1,
                   fill=WHITE, width=int(round(w)))

    def fillpoly(self, pts):
        self.d.polygon([self.P(*q) for q in pts], fill=WHITE)

    def tri(self, pts):
        self.fillpoly(pts)

    def dot(self, cx, cy, r=1.3):
        self.fcircle(cx, cy, r)

    def shape(self, pts_outer, pts_inner=None):
        """月牙类形状：外弧点列 + 内弧点列"""
        allp = list(pts_outer) + list(reversed(pts_inner)) if pts_inner else pts_outer
        self.fillpoly(allp)


def ring_pts(cx, cy, r, a0, a1, step=6):
    pts = []
    a = a0
    while a <= a1 + 0.001:
        pts.append((cx + r * math.cos(math.radians(a)), cy + r * math.sin(math.radians(a))))
        a += step
    return pts


# ---------------------------------------------------------------- 图标定义
def I_library(p):
    p.rect(2.5, 4.5, 21.5, 19.5, r=2.4)
    p.tri([(10, 9), (16, 12), (10, 15)])


def I_folder(p):
    p.poly([(3, 6.5), (9.5, 6.5), (11.5, 9), (21, 9), (21, 19.5), (3, 19.5)], close=True)


def I_folder_open(p):
    p.poly([(3, 6.5), (9.5, 6.5), (11.5, 9), (21, 9), (21, 20), (3, 20)], close=True)
    p.line(3, 12, 21, 12)


def I_history(p):
    p.arc(12, 12.5, 8, 35, 330)
    p.line(12, 12.5, 12, 7.5)
    p.line(12, 12.5, 16, 10)


def I_settings(p):
    p.circle(12, 12, 7.2)
    p.circle(12, 12, 2.8)
    for i in range(6):
        a = math.radians(i * 60 + 30)
        p.line(12 + 3.6 * math.cos(a), 12 + 3.6 * math.sin(a),
               12 + 7.2 * math.cos(a), 12 + 7.2 * math.sin(a))


def I_search(p):
    p.circle(10.5, 10.5, 6.6)
    p.line(15.4, 15.4, 20.5, 20.5)


def I_sort(p):
    p.line(3.5, 6.5, 15, 6.5)
    p.line(3.5, 12, 12, 12)
    p.line(3.5, 17.5, 9, 17.5)
    p.line(20.5, 7, 20.5, 18)
    p.poly([(18, 9), (20.5, 6.5), (23, 9)])


def I_grid(p):
    for (x, y) in ((3, 3), (13, 3), (3, 13), (13, 13)):
        p.frect(x, y, x + 8, y + 8, r=1.6)


def I_list(p):
    for y in (4, 10.5, 17):
        p.frect(3, y, 7, y + 5, r=1.2)
        p.line(9.5, y + 2.5, 21, y + 2.5)


def I_refresh(p):
    p.arc(12, 12, 8, 40, 320)
    p.poly([(20.5, 2.5), (21.5, 8.5), (15.5, 6.5)], close=True)


def I_back(p):
    p.line(20.5, 12, 5, 12)
    p.poly([(11, 6), (4.5, 12), (11, 18)])


def I_close(p):
    p.line(5.5, 5.5, 18.5, 18.5)
    p.line(18.5, 5.5, 5.5, 18.5)


def I_check(p):
    p.poly([(4, 12.5), (9.5, 18), (20, 6)])


def I_more(p):
    for y in (5.2, 12, 18.8):
        p.fcircle(12, y, 1.7)


def I_add(p):
    p.line(12, 4.5, 12, 19.5)
    p.line(4.5, 12, 19.5, 12)


def I_delete(p):
    p.poly([(5, 7.5), (5, 20.5), (19, 20.5), (19, 7.5)], close=True)
    p.line(3, 7.5, 21, 7.5)
    p.line(9, 4.5, 9, 7.5)
    p.line(15, 4.5, 15, 7.5)


def I_fav(p):
    heart = [(12, 20.2), (4.2, 12.4), (4.2, 8.4), (6.6, 5.6), (9.6, 5.6),
             (12, 8.4), (14.4, 5.6), (17.4, 5.6), (19.8, 8.4), (19.8, 12.4)]
    p.poly(heart, close=True)


def I_fav_filled(p):
    heart = [(12, 20.2), (4.2, 12.4), (4.2, 8.4), (6.6, 5.6), (9.6, 5.6),
             (12, 8.4), (14.4, 5.6), (17.4, 5.6), (19.8, 8.4), (19.8, 12.4)]
    p.fillpoly(heart)


def I_info(p):
    p.circle(12, 12, 8.6)
    p.line(12, 11, 12, 17)
    p.fcircle(12, 7.6, 1.2)


def I_shuffle(p):
    p.poly([(3, 6.5), (13.5, 6.5), (17.5, 10.5)])
    p.poly([(13.5, 10), (17.5, 10.5), (17, 14.5)])
    p.poly([(21, 17.5), (10.5, 17.5), (6.5, 13.5)])
    p.poly([(10.5, 14), (6.5, 13.5), (7, 9.5)])


def I_repeat(p):
    p.arc(12, 12, 8, 55, 305)
    p.poly([(20.2, 8.2), (20.8, 13.4), (15.6, 11.2)], close=True)


def I_play(p):
    p.tri([(8, 5), (19.2, 12), (8, 19)])


def I_pause(p):
    p.frect(7, 5, 10.6, 19, r=1.1)
    p.frect(13.4, 5, 17, 19, r=1.1)


def I_prev(p):
    p.line(19.5, 5.5, 19.5, 18.5)
    p.tri([(16, 5.5), (16, 18.5), (5, 12)])


def I_next(p):
    p.line(4.5, 5.5, 4.5, 18.5)
    p.tri([(8, 5.5), (8, 18.5), (19, 12)])


def I_rew(p):
    p.tri([(11.5, 6), (11.5, 18), (3.5, 12)])
    p.tri([(20.5, 6), (20.5, 18), (12.5, 12)])


def I_ff(p):
    p.tri([(3.5, 6), (3.5, 18), (11.5, 12)])
    p.tri([(12.5, 6), (12.5, 18), (20.5, 12)])


def I_lock(p):
    p.rect(5, 10.5, 19, 20, r=2.2)
    p.arc(12, 10.5, 4.6, 180, 360)
    p.line(8, 15, 16, 15)


def I_unlock(p):
    p.rect(5, 10.5, 19, 20, r=2.2)
    p.arc(12, 10.5, 4.6, 200, 340)
    p.line(8, 15, 16, 15)


def I_speed(p):
    p.tri([(3.5, 5), (12, 12), (3.5, 19)])
    p.tri([(12, 5), (20.5, 12), (12, 19)])


def I_subtitle(p):
    p.rect(2.5, 5, 21.5, 19, r=2.6)
    p.line(6, 10, 12, 10)
    p.line(14, 10, 18, 10)
    p.line(6, 14.5, 15, 14.5)


def I_audio(p):
    p.line(8.5, 17, 8.5, 6)
    p.line(8.5, 6, 18, 8.6)
    p.fcircle(6.6, 17.4, 2.6)
    p.fcircle(16.1, 15.4, 2.6)


def I_track(p):
    p.line(5, 10, 5, 14)
    p.line(9.5, 6.5, 9.5, 17.5)
    p.line(14, 8.5, 14, 15.5)
    p.line(18.5, 11, 18.5, 13)


def I_ratio(p):
    p.rect(2.5, 5.5, 21.5, 18.5, r=2)
    p.rect(6.5, 8.5, 17.5, 15.5, r=1.2)


def I_screenshot(p):
    p.rect(3, 6.5, 21, 20, r=2.6)
    p.poly([(9, 6.5), (12, 3.5), (15, 6.5)])
    p.circle(12, 13.2, 3.6)


def I_pip(p):
    p.rect(2.5, 4.5, 21.5, 19.5, r=2.2)
    p.frect(12.5, 12.5, 20, 18.5, r=1.4)


def I_sleep(p):
    outer = ring_pts(12.5, 12.5, 8.5, 62, 298, 5)
    inner = ring_pts(16.5, 10.5, 7.4, 300, 60, 5) if False else \
        [(16.5 + 7.4 * math.cos(math.radians(a)), 10.5 + 7.4 * math.sin(math.radians(a)))
         for a in [300 + i * (420 / 40.0) for i in range(41)]]
    p.shape(outer, inner)
    p.fcircle(19.5, 5.5, 1.1)
    p.fcircle(6.5, 18.5, 0.9)


def I_brightness(p):
    p.circle(12, 12, 4.4)
    for i in range(8):
        a = math.radians(i * 45)
        p.line(12 + 6.6 * math.cos(a), 12 + 6.6 * math.sin(a),
               12 + 9.4 * math.cos(a), 12 + 9.4 * math.sin(a))


def I_volume(p):
    p.fillpoly([(3, 9.2), (7, 9.2), (12, 4.8), (12, 19.2), (7, 14.8), (3, 14.8)])
    p.arc(12, 12, 5.4, -52, 52)
    p.arc(12, 12, 8.4, -55, 55)


def I_mute(p):
    p.fillpoly([(3, 9.2), (7, 9.2), (12, 4.8), (12, 19.2), (7, 14.8), (3, 14.8)])
    p.line(15.5, 9.5, 20.5, 14.5)
    p.line(20.5, 9.5, 15.5, 14.5)


def I_fullscreen(p):
    p.poly([(3, 9.5), (3, 3), (9.5, 3)])
    p.poly([(14.5, 3), (21, 3), (21, 9.5)])
    p.poly([(21, 14.5), (21, 21), (14.5, 21)])
    p.poly([(9.5, 21), (3, 21), (3, 14.5)])


def I_fullscreen_exit(p):
    p.poly([(9.5, 3), (3, 3), (3, 9.5)])
    p.poly([(21, 9.5), (21, 3), (14.5, 3)])
    p.poly([(14.5, 21), (21, 21), (21, 14.5)])
    p.poly([(3, 14.5), (3, 21), (9.5, 21)])


def I_equalizer(p):
    for x, y in ((6, 9), (12, 14.5), (18, 7)):
        p.line(x, 4, x, 20, w=1.1)
        p.fcircle(x, y, 1.8)


def I_url(p):
    p.circle(12, 12, 8.6)
    p.line(3.4, 12, 20.6, 12)
    p.d_ellipse = None
    c = p.P(12, 12)
    p.d.ellipse([c[0] - 4.2 * p.px, c[1] - 8.6 * p.px, c[0] + 4.2 * p.px, c[1] + 8.6 * p.px],
                outline=WHITE, width=int(round(p.w)))


def I_timer(p):
    p.circle(12, 13, 8)
    p.line(12, 13, 12, 8)
    p.line(12, 13, 15.6, 15)
    p.line(9, 3, 15, 3)
    p.line(12, 3, 12, 5)


def I_ab(p):
    p.arc(12, 12, 8.6, 45, 315)
    p.poly([(6.5, 16.5), (9, 9.5), (11.5, 16.5)])
    p.line(7.4, 14, 10.2, 14)
    p.line(14, 9.5, 14, 16.5)
    p.arc(14, 12.6, 3.5, -90, 90)
    p.arc(14, 12.6, 1.7, -90, 90)


def I_whitelist(p):
    p.poly([(3, 6.5), (9.5, 6.5), (11.5, 9), (21, 9), (21, 19.5), (3, 19.5)], close=True)
    p.poly([(7.5, 14.5), (11, 18), (17, 11)])


def I_blacklist(p):
    p.poly([(3, 6.5), (9.5, 6.5), (11.5, 9), (21, 9), (21, 19.5), (3, 19.5)], close=True)
    p.line(9, 12.5, 15, 18)
    p.line(15, 12.5, 9, 18)


def I_theme(p):
    p.circle(12, 12, 8.6)
    p.fcircle(9, 9, 1.5)
    p.fcircle(15, 9.6, 1.5)
    p.fcircle(10.5, 15.5, 1.5)


def I_decode(p):
    p.rect(6.5, 6.5, 17.5, 17.5, r=1.6)
    p.rect(9.8, 9.8, 14.2, 14.2, r=1.0)
    for i in range(3):
        y = 9.5 + i * 3.2
        p.line(2.6, y, 6.5, y, w=1.2)
        p.line(17.5, y, 21.4, y, w=1.2)
        p.line(y, 2.6, y, 6.5, w=1.2)
        p.line(y, 17.5, y, 21.4, w=1.2)


def I_storage(p):
    p.poly([(6, 3), (16, 3), (19.5, 6.5), (19.5, 21), (4.5, 21), (4.5, 6)], close=True)
    p.line(8, 10, 16, 10)
    p.line(8, 14, 13, 14)


def I_sparkle(p):
    p.fillpoly([(12, 2.5), (13.9, 9.4), (20.5, 11), (13.9, 12.8), (12, 20),
                (10.1, 12.8), (3.5, 11), (10.1, 9.4)])
    p.fcircle(19, 4.5, 1.3)
    p.fcircle(5, 18.5, 1.0)


def I_scan(p):
    p.poly([(3, 8.5), (3, 3.5), (8, 3.5)])
    p.poly([(16, 3.5), (21, 3.5), (21, 8.5)])
    p.poly([(21, 15.5), (21, 20.5), (16, 20.5)])
    p.poly([(8, 20.5), (3, 20.5), (3, 15.5)])
    p.line(6, 12, 18, 12)


def I_video_file(p):
    p.poly([(4, 3.5), (13, 3.5), (16, 6.5), (20, 6.5), (20, 20.5), (4, 20.5)], close=True)
    p.tri([(9.5, 11), (15.5, 14.2), (9.5, 17.5)])


def I_eye(p):
    outer = [(12 + 9.2 * math.cos(math.radians(a)), 12 + 5.6 * math.sin(math.radians(a)))
             for a in range(0, 181, 8)]
    inner = [(12 + 9.2 * math.cos(math.radians(a)), 12 - 5.6 * math.sin(math.radians(a)))
             for a in range(180, -1, -8)]
    p.poly(outer + inner, close=False, w=1.6)
    p.circle(12, 12, 3.1)


def I_rotate(p):
    p.arc(12, 12, 8.4, 30, 300)
    p.poly([(19.6, 6.4), (21.4, 11.6), (16.2, 10.4)], close=True)
    p.fcircle(12, 12, 1.6)


def I_playlist(p):
    p.line(8.5, 6.5, 20, 6.5)
    p.line(8.5, 12, 20, 12)
    p.line(8.5, 17.5, 20, 17.5)
    p.tri([(3.5, 5), (7, 6.8), (3.5, 8.6)])
    p.fcircle(4, 12, 1.1)
    p.fcircle(4, 17.5, 1.1)


def I_arrow_up(p):
    p.line(12, 20, 12, 5)
    p.poly([(6.5, 10.5), (12, 4.8), (17.5, 10.5)])


def I_minus(p):
    p.line(5, 12, 19, 12)


def I_fw(p):
    p.arc(12, 12, 7.6, 60, 300)
    p.tri([(10.5, 6.5), (10.5, 17.5), (4, 12)])


ICONS = {
    "ic_library": I_library, "ic_folder": I_folder, "ic_folder_open": I_folder_open,
    "ic_history": I_history, "ic_settings": I_settings, "ic_search": I_search,
    "ic_sort": I_sort, "ic_grid": I_grid, "ic_list": I_list, "ic_refresh": I_refresh,
    "ic_back": I_back, "ic_close": I_close, "ic_check": I_check, "ic_more": I_more,
    "ic_add": I_add, "ic_delete": I_delete, "ic_fav": I_fav, "ic_fav_filled": I_fav_filled,
    "ic_info": I_info, "ic_shuffle": I_shuffle, "ic_repeat": I_repeat, "ic_play": I_play,
    "ic_pause": I_pause, "ic_prev": I_prev, "ic_next": I_next, "ic_rew": I_rew,
    "ic_ff": I_ff, "ic_lock": I_lock, "ic_unlock": I_unlock, "ic_speed": I_speed,
    "ic_subtitle": I_subtitle, "ic_audio": I_audio, "ic_track": I_track,
    "ic_ratio": I_ratio, "ic_screenshot": I_screenshot, "ic_pip": I_pip,
    "ic_sleep": I_sleep, "ic_brightness": I_brightness, "ic_volume": I_volume,
    "ic_mute": I_mute, "ic_fullscreen": I_fullscreen, "ic_fullscreen_exit": I_fullscreen_exit,
    "ic_equalizer": I_equalizer, "ic_url": I_url, "ic_timer": I_timer, "ic_ab": I_ab,
    "ic_whitelist": I_whitelist, "ic_blacklist": I_blacklist, "ic_theme": I_theme,
    "ic_decode": I_decode, "ic_storage": I_storage, "ic_sparkle": I_sparkle,
    "ic_scan": I_scan, "ic_video_file": I_video_file, "ic_eye": I_eye,
    "ic_rotate": I_rotate, "ic_playlist": I_playlist, "ic_arrow_up": I_arrow_up,
    "ic_minus": I_minus, "ic_fw": I_fw,
}


def make_icon(fn, size_px):
    S = size_px * SS
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    fn(Pen(d, S / 24.0))
    return img.resize((size_px, size_px), Image.LANCZOS)


def build_icons():
    total = 0
    for name, fn in ICONS.items():
        for dens, mult in DENS.items():
            size = int(round(24 * mult))
            folder = os.path.join(RES, "drawable-" + dens)
            os.makedirs(folder, exist_ok=True)
            im = make_icon(fn, size)
            im.save(os.path.join(folder, name + ".png"))
            total += 1
    print("icons generated:", total, "->", len(ICONS), "kinds")


# ---------------------------------------------------------------- 品牌图标
def draw_hourglass(d, cx, cy, s, colors):
    """沙漏：s 为半高，返回外框路径点"""
    w = s * 0.62
    neck = s * 0.13
    pts = [(cx - w, cy - s), (cx + w, cy - s), (cx + neck, cy), (cx + w, cy + s),
           (cx - w, cy + s), (cx - neck, cy)]
    d.polygon(pts, fill=colors["glass"])
    return pts


def build_launcher():
    # adaptive icon foreground 432x432 (108dp @400dpi)
    for dens, mult in DENS.items():
        mip = os.path.join(RES, "mipmap-" + dens)
        os.makedirs(mip, exist_ok=True)
        fg_size = int(round(108 * mult))
        fg = Image.new("RGBA", (fg_size * SS, fg_size * SS), (0, 0, 0, 0))
        d = ImageDraw.Draw(fg)
        U = fg_size * SS / 108.0

        def u(v):
            return v * U

        cx, cy = u(54), u(54)
        # 沙漏主体（渐变紫->青）
        glass = (124, 108, 255, 255)
        grad = Image.new("RGBA", fg.size, (0, 0, 0, 0))
        gd = ImageDraw.Draw(grad)
        # 渐变填充：逐行混合
        top = (155, 120, 255, 255)
        bot = (60, 220, 210, 255)
        h = fg.size[1]
        for y in range(int(cy - u(30)), int(cy + u(30))):
            t = (y - (cy - u(30))) / (2 * u(30))
            col = tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(3)) + (255,)
            gd.line([(0, y), (fg.size[0], y)], fill=col)
        w, neck = u(26), u(5.5)
        glass_pts = [(cx - w, cy - u(30)), (cx + w, cy - u(30)), (cx + neck, cy),
                     (cx + w, cy + u(30)), (cx - w, cy + u(30)), (cx - neck, cy)]
        gd.polygon(glass_pts, fill=(255, 255, 255, 255))
        fg = Image.alpha_composite(fg, Image.eval(grad, lambda v: v))
        fg = Image.new("RGBA", fg.size, (0, 0, 0, 0))
        # 用渐变裁剪出沙漏形状
        mask = Image.new("L", fg.size, 0)
        ImageDraw.Draw(mask).polygon(glass_pts, fill=255)
        grad.putalpha(mask)
        fg = Image.alpha_composite(fg, grad)
        d = ImageDraw.Draw(fg)
        # 沙漏描边
        d.line(glass_pts + [glass_pts[0]], fill=(255, 255, 255, 230), width=int(round(u(2.2))))
        # 顶/底横条
        d.rounded_rectangle([cx - w - u(3), cy - u(34), cx + w + u(3), cy - u(29)],
                            radius=u(2.5), fill=(255, 255, 255, 235))
        d.rounded_rectangle([cx - w - u(3), cy + u(29), cx + w + u(3), cy + u(34)],
                            radius=u(2.5), fill=(255, 255, 255, 235))
        # 中间播放三角
        d.polygon([(cx - u(6), cy - u(9)), (cx + u(10), cy), (cx - u(6), cy + u(9))],
                  fill=(255, 255, 255, 255))
        # 星尘
        for (sx, sy, sr) in ((u(22), u(24), u(2.6)), (u(84), u(30), u(2.0)),
                             (u(80), u(78), u(2.6)), (u(26), u(80), u(1.8)),
                             (u(54), u(14), u(1.6))):
            d.ellipse([sx - sr, sy - sr, sx + sr, sy + sr], fill=(255, 255, 255, 220))
        fg = fg.resize((fg_size, fg_size), Image.LANCZOS)
        fg.save(os.path.join(mip, "ic_launcher_foreground.png"))

        # 传统方形图标
        leg = int(round(48 * mult))
        img = Image.new("RGBA", (leg * SS, leg * SS), (0, 0, 0, 0))
        bg = Image.new("RGBA", img.size, (0, 0, 0, 0))
        bd = ImageDraw.Draw(bg)
        bd.rounded_rectangle([0, 0, img.size[0] - 1, img.size[1] - 1],
                             radius=int(leg * SS * 0.22), fill=(18, 18, 26, 255))
        # 斜向渐变高光
        g2 = Image.new("RGBA", img.size, (0, 0, 0, 0))
        g2d = ImageDraw.Draw(g2)
        for y in range(img.size[1]):
            t = y / float(img.size[1])
            c = (int(30 + 40 * t), int(24 + 30 * t), int(60 + 90 * t), 255)
            g2d.line([(0, y), (img.size[0], y)], fill=c)
        mask = Image.new("L", img.size, 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, img.size[0] - 1, img.size[1] - 1],
                                               radius=int(leg * SS * 0.22), fill=255)
        g2.putalpha(mask)
        bg = Image.alpha_composite(bg, g2)
        inner = fg.resize((int(leg * SS * 0.78), int(leg * SS * 0.78)), Image.LANCZOS)
        ox = (img.size[0] - inner.size[0]) // 2
        oy = (img.size[1] - inner.size[1]) // 2
        bg.alpha_composite(inner, (ox, oy))
        bg.resize((leg, leg), Image.LANCZOS).save(os.path.join(mip, "ic_launcher.png"))
    print("launcher icons done")


if __name__ == "__main__":
    build_icons()
    build_launcher()
