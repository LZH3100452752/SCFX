package com.shichen.player;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** 目录选择：可逐级浏览、可手动输入路径、可添加当前目录 */
public class DirPicker {

    public interface OnDir {
        void onDir(String path);
    }

    private final Activity act;
    private final int d;
    private String current;
    private TextView pathView;
    private TextView countView;
    private final OnDir cb;

    public DirPicker(Activity a, OnDir cb) {
        act = a;
        this.cb = cb;
        d = (int) a.getResources().getDisplayMetrics().density;
        current = Environment.getExternalStorageDirectory().getAbsolutePath();
    }

    public View build() {
        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(4 * d, 0, 4 * d, 4 * d);

        /* 当前路径 */
        pathView = new TextView(act);
        pathView.setTextSize(11.5f);
        pathView.setTextColor(ThemeEngine.sub(act));
        pathView.setSingleLine(true);
        pathView.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        pathView.setPadding(10 * d, 4 * d, 10 * d, 6 * d);
        root.addView(pathView);

        /* 手动输入 */
        EditText et = new EditText(act);
        et.setHint("或直接输入完整路径，如 /sdcard/Movies");
        et.setTextSize(12.5f);
        et.setSingleLine(true);
        et.setTextColor(ThemeEngine.text(act));
        et.setHintTextColor(ThemeEngine.sub(act));
        et.setBackgroundResource(R.drawable.bg_panel_row);
        et.setPadding(12 * d, 10 * d, 12 * d, 10 * d);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        elp.bottomMargin = 6 * d;
        root.addView(et, elp);
        et.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
                String p = s.toString().trim();
                if (p.length() > 2 && new File(p).isDirectory()) {
                    current = p;
                    refresh.run();
                }
            }

            public void afterTextChanged(Editable s) {
            }
        });

        /* 目录列表 */
        listView = new ListView(act);
        listView.setDivider(null);
        listView.setDividerHeight(0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (int) (280 * d));
        root.addView(listView, lp);

        /* 底部操作 */
        LinearLayout bar = new LinearLayout(act);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(6 * d, 8 * d, 6 * d, 2 * d);

        countView = new TextView(act);
        countView.setTextSize(11.5f);
        countView.setTextColor(ThemeEngine.sub(act));
        countView.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(countView);

        bar.addView(action("选择此目录", new View.OnClickListener() {
            public void onClick(View v) {
                if (cb != null) {
                    cb.onDir(current);
                }
            }
        }));
        root.addView(bar);

        refresh.run();
        return root;
    }

    private TextView action(String text, View.OnClickListener l) {
        TextView t = new TextView(act);
        t.setText(text);
        t.setTextSize(12.5f);
        t.setTextColor(Color.WHITE);
        t.setBackgroundResource(R.drawable.bg_panel_btn_sel);
        t.setGravity(Gravity.CENTER);
        t.setPadding(14 * d, 8 * d, 14 * d, 8 * d);
        t.setOnClickListener(l);
        return t;
    }

    private ListView listView;
    private Runnable refresh = new Runnable() {
        public void run() {
            if (pathView != null) {
                pathView.setText(current);
            }
            File dir = new File(current);
            File[] fs = dir.listFiles();
            List<Object> rows = new ArrayList<Object>();
            String parent = dir.getParent();
            if (parent != null && !parent.equals(current)) {
                rows.add(new UpRow(parent));
            }
            if (fs != null) {
                List<File> dirs = new ArrayList<File>();
                for (File f : fs) {
                    if (f.isDirectory() && !f.getName().startsWith(".")) {
                        dirs.add(f);
                    }
                }
                Collections.sort(dirs, new Comparator<File>() {
                    public int compare(File a, File b) {
                        return a.getName().compareToIgnoreCase(b.getName());
                    }
                });
                rows.addAll(dirs);
            }
            if (countView != null) {
                countView.setText(rows.size() + " 个目录");
            }
            final List<Object> data = rows;
            listView.setAdapter(new ArrayAdapter<Object>(act,
                    android.R.layout.simple_list_item_1, data) {
                public View getView(int pos, View v, ViewGroup p) {
                    TextView tv = new TextView(act);
                    Object o = data.get(pos);
                    if (o instanceof UpRow) {
                        tv.setText("↑  返回上级");
                        tv.setTextColor(ThemeEngine.accent(act));
                    } else {
                        tv.setText(((File) o).getName());
                        tv.setTextColor(0xFFEEEEF5);
                    }
                    tv.setTextSize(14f);
                    tv.setPadding(14 * d, 12 * d, 14 * d, 12 * d);
                    tv.setSingleLine(true);
                    return tv;
                }
            });
            listView.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
                public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                    Object o = data.get(pos);
                    if (o instanceof UpRow) {
                        current = ((UpRow) o).path;
                    } else {
                        current = ((File) o).getAbsolutePath();
                    }
                    refresh.run();
                }
            });
        }
    };

    private static class UpRow {
        String path;

        UpRow(String p) {
            path = p;
        }
    }

    /** 便捷入口：弹出面板选择目录 */
    public static void pick(Activity act, String title, final OnDir cb) {
        DirPicker dp = new DirPicker(act, cb);
        Ui.panel(act, title, dp.build(), false, null);
    }
}
