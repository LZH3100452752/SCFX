package com.shichen.player;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {

    private static final int REQ_PERM = 1001;

    private FrameLayout content;
    private int tab = 0;
    private Handler main = new Handler(Looper.getMainLooper());
    private DbHelper db;

    private List<VideoItem> all = new ArrayList<VideoItem>();
    private List<VideoItem> shown = new ArrayList<VideoItem>();
    private VideoAdapter libAdapter;
    private HistoryAdapter historyAdapter;
    private SettingsPage settings;
    private String query = "";
    private int mode = 0;              // 0 视频 1 文件夹 2 收藏
    private String curDir = null;
    private List<Object> folderRows = new ArrayList<Object>();
    private DirVideoAdapter folderAdapter;
    private View libView, historyView, settingsView;
    private long backPressed = 0;
    private int historySubTab = 0;
    private int[] tabIds = {R.id.tab_library, R.id.tab_history, R.id.tab_settings};

    protected void onCreate(Bundle b) {
        ThemeEngine.apply(this);
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        db = new DbHelper(this);
        content = (FrameLayout) findViewById(R.id.content);
        for (int i = 0; i < tabIds.length; i++) {
            final int idx = i;
            View v = findViewById(tabIds[i]);
            if (v != null) {
                v.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v2) {
                        switchTab(idx);
                    }
                });
            }
        }
        int startMode = getIntent().getIntExtra("mode", 0);
        if (startMode == 1) {
            mode = 1;
            curDir = null;
        }
        int saved = Prefs.lastTab(this);
        if (saved > 2) {
            saved = 0;
        }
        switchTab(saved);
        checkPerm();
    }

    private void highlightTabs() {
        int[][] ids = {{R.id.tab_library, R.id.tab_library_icon, R.id.tab_library_text, R.id.ind_library},
                {R.id.tab_history, R.id.tab_history_icon, R.id.tab_history_text, R.id.ind_history},
                {R.id.tab_settings, R.id.tab_settings_icon, R.id.tab_settings_text, R.id.ind_settings}};
        int[] icons = {R.drawable.ic_library, R.drawable.ic_history, R.drawable.ic_settings};
        int acc = ThemeEngine.accent(this);
        int sub = ThemeEngine.sub(this);
        for (int i = 0; i < ids.length; i++) {
            ImageView iv = (ImageView) findViewById(ids[i][1]);
            TextView tv = (TextView) findViewById(ids[i][2]);
            View ind = findViewById(ids[i][3]);
            boolean on = (i == tab);
            if (iv != null) {
                iv.setImageResource(icons[i]);
                iv.setColorFilter(on ? acc : sub);
            }
            if (tv != null) {
                tv.setTextColor(on ? acc : sub);
            }
            if (ind != null) {
                ind.setVisibility(on ? View.VISIBLE : View.INVISIBLE);
            }
        }
    }

    private void switchTab(int idx) {
        if (idx < 0 || idx > 2) {
            idx = 0;
        }
        tab = idx;
        Prefs.setLastTab(this, idx);
        content.removeAllViews();
        highlightTabs();
        if (idx == 0) {
            if (libView == null) {
                libView = LayoutInflater.from(this).inflate(R.layout.page_library, content, false);
                setupLibrary(libView);
            }
            content.addView(libView);
            refreshLibrary();
        } else if (idx == 1) {
            historyView = LayoutInflater.from(this).inflate(R.layout.page_history, content, false);
            content.addView(historyView);
            setupHistory(historyView);
        } else {
            settingsView = LayoutInflater.from(this).inflate(R.layout.page_settings, content, false);
            content.addView(settingsView);
            setupSettings(settingsView);
        }
    }

    /* ==================== 权限 ==================== */
    private void checkPerm() {
        String perm = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_VIDEO : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{perm}, REQ_PERM);
        } else {
            loadData(false);
        }
    }

    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == REQ_PERM) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
                loadData(true);
            } else {
                Ui.toast(this, R.string.perm_needed);
            }
        }
    }

    /* ==================== 扫描 ==================== */
    private void loadData(final boolean toast) {
        final ProgressBar pb = libView == null ? null : (ProgressBar) libView.findViewById(R.id.progress);
        if (pb != null) {
            pb.setVisibility(View.VISIBLE);
        }
        new Thread(new Runnable() {
            public void run() {
                final List<VideoItem> list = VideoScanner.scan(MainActivity.this);
                attachMeta(list);
                main.post(new Runnable() {
                    public void run() {
                        all = list;
                        if (pb != null) {
                            pb.setVisibility(View.GONE);
                        }
                        refreshLibrary();
                        if (toast) {
                            Ui.toast(MainActivity.this, getString(R.string.scan_done, all.size()));
                        }
                    }
                });
            }
        }).start();
    }

    private void attachMeta(List<VideoItem> list) {
        Map<String, VideoItem> meta = new HashMap<String, VideoItem>();
        java.util.List<VideoItem> hist;
        try {
            hist = db.getHistory(3000);
        } catch (Exception e) {
            return;
        }
        for (VideoItem v : hist) {
            meta.put(v.path, v);
        }
        for (VideoItem v : list) {
            VideoItem m = meta.get(v.path);
            if (m != null) {
                v.position = m.position;
                v.lastPlay = m.lastPlay;
                v.fav = m.fav;
                if (v.duration <= 0) {
                    v.duration = m.duration;
                }
                if (v.width <= 0) {
                    v.width = m.width;
                    v.height = m.height;
                }
            }
        }
    }

    private void refreshLibrary() {
        if (libView == null) {
            return;
        }
        GridView g = (GridView) libView.findViewById(R.id.grid);
        ListView l = (ListView) libView.findViewById(R.id.list);
        View empty = libView.findViewById(R.id.empty);
        View dirUp = libView.findViewById(R.id.btn_dir_up);
        TextView dirPath = (TextView) libView.findViewById(R.id.dir_path);
        TextView titleTv = (TextView) libView.findViewById(R.id.title);

        if (mode == 1) {
            if (g != null) {
                g.setVisibility(View.GONE);
            }
            if (l != null) {
                l.setVisibility(View.VISIBLE);
            }
            buildFolderRows();
            if (folderAdapter == null) {
                folderAdapter = new DirVideoAdapter(this, folderRows);
            } else {
                folderAdapter.setData(folderRows);
            }
            if (l != null) {
                if (l.getAdapter() != folderAdapter) {
                    l.setAdapter(folderAdapter);
                }
                l.setItemsCanFocus(false);
            bindListClick(l);
            }
            if (empty != null) {
                empty.setVisibility(folderRows.isEmpty() ? View.VISIBLE : View.GONE);
            }
            if (dirUp != null) {
                dirUp.setVisibility(curDir == null ? View.GONE : View.VISIBLE);
            }
            if (dirPath != null) {
                if (curDir != null) {
                    dirPath.setVisibility(View.VISIBLE);
                    String extRoot = android.os.Environment.getExternalStorageDirectory()
                            .getAbsolutePath();
                    String rel = curDir.startsWith(extRoot) ? curDir.substring(extRoot.length())
                            : curDir;
                    dirPath.setText(rel.length() == 0 ? "/" : rel);
                    dirPath.setTextColor(ThemeEngine.sub(this));
                } else {
                    dirPath.setVisibility(View.GONE);
                }
            }
            if (titleTv != null) {
                titleTv.setText(curDir == null ? getString(R.string.view_folder)
                        : new java.io.File(curDir).getName());
                titleTv.setTextColor(ThemeEngine.text(this));
            }
            updateSummary(folderRows.size());
            return;
        }

        shown.clear();
        String q = query.trim().toLowerCase(Locale.getDefault());
        for (VideoItem v : all) {
            if (mode == 2 && !v.fav) {
                continue;
            }
            if (q.length() > 0
                    && !v.title.toLowerCase(Locale.getDefault()).contains(q)
                    && !v.path.toLowerCase(Locale.getDefault()).contains(q)) {
                continue;
            }
            shown.add(v);
        }
        try {
            SortEngine.sort(shown, Prefs.sortField(this), Prefs.sortAsc(this));
        } catch (Exception ignored) {
        }
        boolean grid = Prefs.gridView(this);
        if (g != null) {
            g.setVisibility(grid ? View.VISIBLE : View.GONE);
        }
        if (l != null) {
            l.setVisibility(grid ? View.GONE : View.VISIBLE);
        }
        if (dirUp != null) {
            dirUp.setVisibility(View.GONE);
        }
        if (dirPath != null) {
            dirPath.setVisibility(View.GONE);
        }
        if (titleTv != null) {
            titleTv.setText(mode == 2 ? getString(R.string.tab_fav) : getString(R.string.tab_library));
            titleTv.setTextColor(ThemeEngine.text(this));
        }

        VideoAdapter.OnMoreListener ml = new VideoAdapter.OnMoreListener() {
            public void onMore(VideoItem item) {
                showItemMenu(item);
            }
        };
        if (libAdapter == null) {
            libAdapter = new VideoAdapter(this, shown, grid, ml);
        } else {
            libAdapter.setData(shown, grid);
        }
        if (g != null) {
            if (g.getAdapter() != libAdapter) {
                g.setAdapter(libAdapter);
            }
            bindListClick(g);
        }
        if (l != null) {
            if (l.getAdapter() != libAdapter) {
                l.setAdapter(libAdapter);
            }
            l.setItemsCanFocus(false);
            bindListClick(l);
        }
        if (empty != null) {
            empty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
        }
        updateSummary(shown.size());
    }

    /** 每次刷新都重设点击监听，按当前模式分派（避免模式切换后监听残留导致点击无效） */
    private void bindListClick(AdapterView<?> av) {
        av.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                if (mode == 1) {
                    if (pos < 0 || pos >= folderRows.size()) {
                        return;
                    }
                    Object o = folderRows.get(pos);
                    if (o instanceof DirVideoAdapter.DirEntry) {
                        curDir = ((DirVideoAdapter.DirEntry) o).path;
                        refreshLibrary();
                    } else if (o instanceof VideoItem) {
                        VideoItem it = (VideoItem) o;
                        ArrayList<String> pl = new ArrayList<String>();
                        for (Object r : folderRows) {
                            if (r instanceof VideoItem) {
                                pl.add(((VideoItem) r).path);
                            }
                        }
                        Intent i = new Intent(MainActivity.this, PlayerActivity.class);
                        i.putExtra("path", it.path);
                        i.putExtra("title", it.title);
                        i.putStringArrayListExtra("list", pl);
                        startActivity(i);
                    }
                    return;
                }
                if (pos >= 0 && pos < shown.size()) {
                    play(shown.get(pos), true);
                }
            }
        });
        av.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                if (mode == 1) {
                    if (pos < 0 || pos >= folderRows.size()) {
                        return true;
                    }
                    Object o = folderRows.get(pos);
                    if (o instanceof DirVideoAdapter.DirEntry) {
                        dirMenu(((DirVideoAdapter.DirEntry) o).path);
                        return true;
                    }
                    if (o instanceof VideoItem) {
                        showItemMenu((VideoItem) o);
                        return true;
                    }
                    return false;
                }
                if (pos >= 0 && pos < shown.size()) {
                    showItemMenu(shown.get(pos));
                }
                return true;
            }
        });
    }

    private void updateSummary(int n) {
        TextView count = (TextView) libView.findViewById(R.id.count);
        TextView label = (TextView) libView.findViewById(R.id.sort_label);
        if (count != null) {
            count.setText(mode == 1 ? (curDir == null ? n + " 个文件夹" : n + " 项")
                    : n + " 个视频");
            count.setTextColor(ThemeEngine.sub(this));
        }
        if (label != null) {
            label.setText(SortEngine.summary(null, Prefs.sortField(this), Prefs.sortAsc(this)));
            label.setTextColor(ThemeEngine.accent(this));
        }
    }

    private java.util.Map<String, List<VideoItem>> dirMap() {
        return VideoScanner.groupByDir(all);
    }

    /** 顶层目录：没有被其他含视频目录包含的目录 */
    private static List<String> topLevelDirs(java.util.Map<String, List<VideoItem>> map) {
        List<String> all2 = new ArrayList<String>(map.keySet());
        List<String> tops = new ArrayList<String>();
        for (String d : all2) {
            boolean hasParent = false;
            for (String o : all2) {
                if (!o.equals(d) && d.startsWith(o + "/")) {
                    hasParent = true;
                    break;
                }
            }
            if (!hasParent) {
                tops.add(d);
            }
        }
        sortDirNames(tops);
        return tops;
    }

    /** 直接子目录，中间空层折叠 */
    private static List<String> childDirs(java.util.Map<String, List<VideoItem>> map, String parent) {
        List<String> out = new ArrayList<String>();
        java.util.Set<String> seen = new java.util.HashSet<String>();
        for (String d : map.keySet()) {
            if (!d.startsWith(parent + "/")) {
                continue;
            }
            String rest = d.substring(parent.length() + 1);
            String[] parts = rest.split("/");
            String cur = parent;
            for (int i = 0; i < parts.length; i++) {
                cur = cur + "/" + parts[i];
                if (map.containsKey(cur) || i == parts.length - 1) {
                    if (seen.add(cur)) {
                        out.add(cur);
                    }
                    break;
                }
            }
        }
        sortDirNames(out);
        return out;
    }

    private static void sortDirNames(List<String> dirs) {
        java.util.Collections.sort(dirs, new java.util.Comparator<String>() {
            public int compare(String a, String b) {
                return new java.io.File(a).getName().compareToIgnoreCase(
                        new java.io.File(b).getName());
            }
        });
    }

    private void buildFolderRows() {
        folderRows.clear();
        java.util.Map<String, List<VideoItem>> map = dirMap();
        if (curDir == null) {
            for (String d : topLevelDirs(map)) {
                folderRows.add(makeEntry(map, d));
            }
            return;
        }
        for (String d : childDirs(map, curDir)) {
            folderRows.add(makeEntry(map, d));
        }
        List<VideoItem> vs = map.get(curDir);
        if (vs != null) {
            List<VideoItem> copy = new ArrayList<VideoItem>(vs);
            try {
                SortEngine.sort(copy, Prefs.sortField(this), Prefs.sortAsc(this));
            } catch (Exception ignored) {
            }
            folderRows.addAll(copy);
        }
    }

    private DirVideoAdapter.DirEntry makeEntry(java.util.Map<String, List<VideoItem>> map, String d) {
        DirVideoAdapter.DirEntry e = new DirVideoAdapter.DirEntry(d);
        int n = 0;
        long sz = 0;
        for (java.util.Map.Entry<String, List<VideoItem>> en : map.entrySet()) {
            if (en.getKey().equals(d) || en.getKey().startsWith(d + "/")) {
                n += en.getValue().size();
                for (VideoItem v : en.getValue()) {
                    sz += v.size;
                }
            }
        }
        e.count = n;
        e.size = sz;
        List<VideoItem> direct = map.get(d);
        e.direct = direct == null ? 0 : direct.size();
        return e;
    }

    private void dirMenu(final String dir) {
        String[] opts = {"加入白名单目录", "加入黑名单目录", "播放整个文件夹"};
        Ui.sheet(this, new java.io.File(dir).getName(), opts, -1, new Ui.OnPick() {
            public void onPick(int index) {
                if (index == 0) {
                    db.addDir(dir, DbHelper.TYPE_WHITE);
                    Ui.toast(MainActivity.this, R.string.added_to_whitelist);
                    loadData(true);
                } else if (index == 1) {
                    db.addDir(dir, DbHelper.TYPE_BLACK);
                    Ui.toast(MainActivity.this, R.string.added_to_blacklist);
                    loadData(true);
                } else {
                    java.util.Map<String, List<VideoItem>> map = dirMap();
                    ArrayList<String> pl = new ArrayList<String>();
                    List<String> ds = new ArrayList<String>();
                    for (String k : map.keySet()) {
                        if (k.equals(dir) || k.startsWith(dir + "/")) {
                            ds.add(k);
                        }
                    }
                    sortDirNames(ds);
                    for (String k : ds) {
                        for (VideoItem v : map.get(k)) {
                            pl.add(v.path);
                        }
                    }
                    if (pl.isEmpty()) {
                        return;
                    }
                    Intent i = new Intent(MainActivity.this, PlayerActivity.class);
                    i.putExtra("path", pl.get(0));
                    i.putStringArrayListExtra("list", pl);
                    startActivity(i);
                }
            }
        });
    }

    private void setupLibrary(View v) {
        final EditText et = (EditText) v.findViewById(R.id.search);
        final ImageButton clear = (ImageButton) v.findViewById(R.id.btn_clear_search);
        if (et != null) {
            et.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int a, int b, int c) {
                }

                public void onTextChanged(CharSequence s, int a, int b, int c) {
                    query = s.toString();
                    if (clear != null) {
                        clear.setVisibility(query.length() > 0 ? View.VISIBLE : View.GONE);
                    }
                    refreshLibrary();
                }

                public void afterTextChanged(Editable s) {
                }
            });
            et.setTextColor(ThemeEngine.text(this));
            et.setHintTextColor(ThemeEngine.sub(this));
        }
        if (clear != null) {
            clear.setColorFilter(ThemeEngine.sub(this));
            clear.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    if (et != null) {
                        et.setText("");
                    }
                }
            });
        }
        setupHeader(v);
        int sub = ThemeEngine.sub(this);
        ImageButton bs = (ImageButton) v.findViewById(R.id.btn_sort);
        ImageButton bsc = (ImageButton) v.findViewById(R.id.btn_scan);
        ImageButton bm = (ImageButton) v.findViewById(R.id.btn_more);
        if (bs != null) {
            bs.setColorFilter(sub);
            bs.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    showSort();
                }
            });
        }
        if (bsc != null) {
            bsc.setColorFilter(sub);
            bsc.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    loadData(true);
                }
            });
        }
        if (bm != null) {
            bm.setColorFilter(sub);
            bm.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    showLibMenu();
                }
            });
        }
        View empty = v.findViewById(R.id.empty);
        if (empty != null) {
            empty.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    loadData(true);
                }
            });
        }

    }

    private void setupHeader(final View v) {
        int sub = ThemeEngine.sub(this);
        int text = ThemeEngine.text(this);
        ImageButton bf = (ImageButton) v.findViewById(R.id.btn_folder);
        ImageButton bfv = (ImageButton) v.findViewById(R.id.btn_fav_filter);
        ImageButton bs2 = (ImageButton) v.findViewById(R.id.btn_search_toggle);
        ImageButton bv = (ImageButton) v.findViewById(R.id.btn_view);
        ImageButton bu = (ImageButton) v.findViewById(R.id.btn_dir_up);
        final android.widget.LinearLayout searchRow =
                (android.widget.LinearLayout) v.findViewById(R.id.search_row);

        if (bf != null) {
            bf.setColorFilter(mode == 1 ? ThemeEngine.accent(this) : sub);
            bf.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    mode = (mode == 1) ? 0 : 1;
                    curDir = null;
                    setupHeader(libView);
                    refreshLibrary();
                }
            });
        }
        if (bfv != null) {
            bfv.setImageResource(mode == 2 ? R.drawable.ic_fav_filled : R.drawable.ic_fav);
            bfv.setColorFilter(mode == 2 ? ThemeEngine.accent(this) : sub);
            bfv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    mode = (mode == 2) ? 0 : 2;
                    curDir = null;
                    setupHeader(libView);
                    refreshLibrary();
                }
            });
        }
        if (bs2 != null) {
            bs2.setColorFilter(searchRow != null && searchRow.getVisibility() == View.VISIBLE
                    ? ThemeEngine.accent(this) : sub);
            bs2.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    if (searchRow == null) {
                        return;
                    }
                    boolean show = searchRow.getVisibility() != View.VISIBLE;
                    searchRow.setVisibility(show ? View.VISIBLE : View.GONE);
                    android.widget.EditText et =
                            (android.widget.EditText) libView.findViewById(R.id.search);
                    if (show && et != null) {
                        et.requestFocus();
                    }
                    if (!show && et != null) {
                        et.setText("");
                    }
                    setupHeader(libView);
                }
            });
        }
        if (bv != null) {
            bv.setImageResource(Prefs.gridView(this) ? R.drawable.ic_grid : R.drawable.ic_list);
            bv.setColorFilter(sub);
            bv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    Prefs.setGridView(MainActivity.this, !Prefs.gridView(MainActivity.this));
                    setupHeader(libView);
                    refreshLibrary();
                }
            });
        }
        if (bu != null) {
            bu.setColorFilter(text);
            bu.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    dirUp();
                }
            });
        }
    }

    private void dirUp() {
        if (curDir == null) {
            return;
        }
        java.util.Map<String, List<VideoItem>> map = dirMap();
        String p = curDir.substring(0, curDir.lastIndexOf('/'));
        if (p != null && p.length() > 0 && map.containsKey(p)) {
            curDir = p;
        } else {
            curDir = null;
        }
        refreshLibrary();
    }

    private void showSort() {
        Ui.sortDialog(this, new Ui.SortCb() {
            public void onApply() {
                if (Prefs.folderMode(MainActivity.this)) {
                    Prefs.setFolderMode(MainActivity.this, false);
                    mode = 1;
                    curDir = null;
                    if (libView != null) {
                        setupHeader(libView);
                    }
                    refreshLibrary();
                    return;
                }
                refreshLibrary();
            }
        });
    }

    private void showLibMenu() {
        String[] opts = {getString(R.string.sort_title), "文件夹浏览",
                "重新扫描", getString(R.string.url_title)};
        Ui.sheet(this, "视频库", opts, -1, new Ui.OnPick() {
            public void onPick(int index) {
                switch (index) {
                    case 0:
                        showSort();
                        break;
                    case 1:
                        mode = 1;
                        curDir = null;
                        setupHeader(libView);
                        refreshLibrary();
                        break;
                    case 2:
                        loadData(true);
                        break;
                    case 3:
                        showUrl();
                        break;
                }
            }
        });
    }

    private void showUrl() {
        Ui.input(this, getString(R.string.url_title), "", getString(R.string.url_hint), new Ui.OnText() {
            public void onText(String text) {
                if (text.length() == 0) {
                    return;
                }
                ArrayList<String> pl = new ArrayList<String>();
                pl.add(text);
                Intent in = new Intent(MainActivity.this, PlayerActivity.class);
                in.putExtra("path", text);
                in.putStringArrayListExtra("list", pl);
                startActivity(in);
            }
        });
    }

    private void showItemMenu(final VideoItem item) {
        String[] opts = {getString(R.string.play),
                item.fav ? getString(R.string.unfav) : getString(R.string.fav),
                "加入白名单目录", "加入黑名单目录",
                getString(R.string.info_title), getString(R.string.delete_record)};
        Ui.sheet(this, item.title, opts, -1, new Ui.OnPick() {
            public void onPick(int index) {
                switch (index) {
                    case 0:
                        play(item, true);
                        break;
                    case 1:
                        db.setFav(item.path, !item.fav);
                        item.fav = !item.fav;
                        refreshLibrary();
                        break;
                    case 2:
                        db.addDir(item.dir(), DbHelper.TYPE_WHITE);
                        Ui.toast(MainActivity.this, R.string.added_to_whitelist);
                        loadData(true);
                        break;
                    case 3:
                        db.addDir(item.dir(), DbHelper.TYPE_BLACK);
                        Ui.toast(MainActivity.this, R.string.added_to_blacklist);
                        loadData(true);
                        break;
                    case 4:
                        showInfo(item);
                        break;
                    case 5:
                        db.delete(item.path);
                        refreshLibrary();
                        break;
                }
            }
        });
    }

    private void showInfo(VideoItem item) {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_info, null);
        TextView name = (TextView) v.findViewById(R.id.name);
        name.setText(item.title);
        name.setTextColor(ThemeEngine.accent(this));
        LinearLayout rows = (LinearLayout) v.findViewById(R.id.rows);
        rows.addView(Ui.row(this, "时长", MediaUtils.formatDurationCn(item.duration)));
        rows.addView(Ui.row(this, "大小", MediaUtils.formatSize(item.size)));
        rows.addView(Ui.row(this, "分辨率", item.resolution().length() > 0 ? item.resolution() : "未知"));
        rows.addView(Ui.row(this, "格式", item.ext().toUpperCase()));
        rows.addView(Ui.row(this, "添加", MediaUtils.formatDate(item.dateAdded)));
        rows.addView(Ui.row(this, "上次播放", MediaUtils.formatRelative(item.lastPlay)));
        try {
            for (Map.Entry<String, String> e : MediaUtils.info(this, item.path).entrySet()) {
                rows.addView(Ui.row(this, e.getKey(), e.getValue()));
            }
        } catch (Exception ignored) {
        }
        rows.addView(Ui.row(this, "路径", item.path));
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(v);
        Ui.panel(this, getString(R.string.info_title), sv, true, null);
    }

    private void play(VideoItem item, boolean resume) {
        if (item == null || item.path == null) {
            Ui.toast(this, "视频路径无效");
            return;
        }
        try {
            doPlay(item, resume);
        } catch (Exception e) {
            Ui.toast(this, "打开失败：" + e.getMessage());
        }
    }

    private void doPlay(VideoItem item, boolean resume) {
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("path", item.path);
        i.putExtra("title", item.title);
        i.putExtra("resume", resume);
        ArrayList<String> pl = new ArrayList<String>();
        for (VideoItem v : shown) {
            pl.add(v.path);
        }
        i.putStringArrayListExtra("list", pl);
        startActivity(i);
    }

    /* ==================== 历史 ==================== */
    private void setupHistory(View v) {
        final ListView list = (ListView) v.findViewById(R.id.list);
        final TextView tabH = (TextView) v.findViewById(R.id.tab_history);
        final TextView tabF = (TextView) v.findViewById(R.id.tab_fav);
        final TextView empty = (TextView) v.findViewById(R.id.empty);
        int sub = ThemeEngine.sub(this);
        if (empty != null) {
            empty.setTextColor(sub);
        }
        ImageButton bc = (ImageButton) v.findViewById(R.id.btn_clear);
        if (bc != null) {
            bc.setColorFilter(sub);
        }

        final HistoryAdapter.OnMoreListener ml = new HistoryAdapter.OnMoreListener() {
            public void onMore(final VideoItem item) {
                String[] opts = {getString(R.string.play),
                        item.fav ? getString(R.string.unfav) : getString(R.string.fav),
                        getString(R.string.delete_record), getString(R.string.info_title)};
                Ui.sheet(MainActivity.this, item.title, opts, -1, new Ui.OnPick() {
                    public void onPick(int index) {
                        if (index == 0) {
                            play(item, true);
                        } else if (index == 1) {
                            db.setFav(item.path, !item.fav);
                            item.fav = !item.fav;
                            if (historyView != null) {
                                setupHistory(historyView);
                            }
                        } else if (index == 2) {
                            db.delete(item.path);
                            if (historyView != null) {
                                setupHistory(historyView);
                            }
                        } else {
                            showInfo(item);
                        }
                    }
                });
            }
        };
        historyAdapter = new HistoryAdapter(this, db.getHistory(300), ml);
        final HistoryAdapter favAdapter = new HistoryAdapter(this, db.getFavorites(), null);

        paintTabs(tabH, tabF, historySubTab == 0);
        if (tabH != null) {
            tabH.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    historySubTab = 0;
                    historyAdapter.setData(db.getHistory(300));
                    list.setAdapter(historyAdapter);
                    if (empty != null) {
                        empty.setVisibility(historyAdapter.getCount() == 0 ? View.VISIBLE : View.GONE);
                        empty.setText(R.string.history_empty);
                    }
                    paintTabs(tabH, tabF, true);
                }
            });
        }
        if (tabF != null) {
            tabF.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    historySubTab = 1;
                    favAdapter.setData(db.getFavorites());
                    list.setAdapter(favAdapter);
                    if (empty != null) {
                        empty.setVisibility(favAdapter.getCount() == 0 ? View.VISIBLE : View.GONE);
                        empty.setText(R.string.fav_empty);
                    }
                    paintTabs(tabH, tabF, false);
                }
            });
        }

        list.setAdapter(historyAdapter);
        if (empty != null) {
            empty.setVisibility(historyAdapter.getCount() == 0 ? View.VISIBLE : View.GONE);
        }
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v2, int pos, long id) {
                Object o = p.getAdapter().getItem(pos);
                if (o instanceof VideoItem) {
                    play((VideoItem) o, true);
                }
            }
        });
        if (bc != null) {
            bc.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    Ui.confirm(MainActivity.this, "确定清空播放历史？", new Runnable() {
                        public void run() {
                            db.clearHistory();
                            if (historyView != null) {
                                setupHistory(historyView);
                            }
                        }
                    });
                }
            });
        }
    }

    private void paintTabs(TextView a, TextView b, boolean first) {
        int s = ThemeEngine.sub(this);
        if (a != null) {
            a.setBackgroundResource(first ? R.drawable.bg_chip_sel : R.drawable.bg_chip);
            a.setTextColor(first ? 0xFFFFFFFF : s);
        }
        if (b != null) {
            b.setBackgroundResource(!first ? R.drawable.bg_chip_sel : R.drawable.bg_chip);
            b.setTextColor(!first ? 0xFFFFFFFF : s);
        }
    }

    /* ==================== 设置 ==================== */
    private void setupSettings(View v) {
        LinearLayout container = (LinearLayout) v.findViewById(R.id.container);
        if (container == null) {
            return;
        }
        settings = new SettingsPage(this, container, new SettingsPage.Change() {
            public void onChanged() {
                hotReloadTheme();
            }
        });
        settings.build(new Runnable() {
            public void run() {
                loadData(true);
            }
        });
    }

    /** 热加载主题：不 recreate，避免闪退与"重启"感 */
    private void hotReloadTheme() {
        ThemeEngine.applyDynamic(this);
        libView = null;
        historyView = null;
        settingsView = null;
        libAdapter = null;
        folderAdapter = null;
        int keep = tab;
        content.removeAllViews();
        switchTab(keep);
        loadData(false);
    }

    public void onBackPressed() {
        if (tab == 0 && mode == 1 && curDir != null) {
            dirUp();
            return;
        }
        if (tab != 0) {
            switchTab(0);
            return;
        }
        if (System.currentTimeMillis() - backPressed > 2000) {
            backPressed = System.currentTimeMillis();
            Ui.toast(this, R.string.exit_confirm);
            return;
        }
        super.onBackPressed();
    }

    protected void onNewIntent(Intent in) {
        super.onNewIntent(in);
        int m = in.getIntExtra("mode", -1);
        if (m == 1 && libView != null) {
            mode = 1;
            curDir = null;
            switchTab(0);
            setupHeader(libView);
            refreshLibrary();
        }
    }

    protected void onResume() {
        super.onResume();
        if (tab == 0 && libView != null) {
            attachMeta(all);
            refreshLibrary();
        } else if (tab == 1 && historyView != null) {
            setupHistory(historyView);
        }
    }
}
