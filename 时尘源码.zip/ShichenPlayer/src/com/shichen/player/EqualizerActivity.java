package com.shichen.player;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.view.ViewGroup;
import android.widget.TextView;

public class EqualizerActivity extends Activity {

    private LinearLayout bands;
    private FlowLayout presets;
    private SeekBar[] sliders;
    private int range;

    protected void onCreate(Bundle b) {
        setTheme(ThemeEngine.themeRes(this));
        super.onCreate(b);
        setContentView(R.layout.activity_equalizer);
        bands = (LinearLayout) findViewById(R.id.bands);
        presets = (FlowLayout) findViewById(R.id.presets);
        final Switch sw = (Switch) findViewById(R.id.sw_enable);
        sw.setChecked(Prefs.audioFxOn(this));
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton button, boolean v) {
                AudioFx.setEnabled(v);
            }
        });
        buildPresets();
        buildBands();
        SeekBar bass = (SeekBar) findViewById(R.id.bass);
        bass.setProgress(Prefs.bassBoost(this));
        bass.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) {
                    AudioFx.setBass(p);
                }
            }

            public void onStartTrackingTouch(SeekBar s) {
            }

            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        SeekBar viz = (SeekBar) findViewById(R.id.viz);
        viz.setProgress(Prefs.virtualizer(this));
        viz.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) {
                    AudioFx.setViz(p);
                }
            }

            public void onStartTrackingTouch(SeekBar s) {
            }

            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        if (!AudioFx.available()) {
            Ui.toast(this, "音效引擎未就绪，请先开始播放音频");
        }
    }

    private void buildPresets() {
        presets.removeAllViews();
        int d = (int) getResources().getDisplayMetrics().density;
        for (int i = 0; i < AudioFx.PRESETS.length; i++) {
            final int idx = i;
            boolean on = i == Prefs.eqPreset(this);
            TextView t = new TextView(this);
            t.setText(AudioFx.PRESETS[i]);
            t.setTextSize(13);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(on ? Color.WHITE : ThemeEngine.text(this));
            t.setBackgroundResource(on ? R.drawable.bg_chip_sel : R.drawable.bg_chip);
            t.setPadding(16 * d, 10 * d, 16 * d, 10 * d);
            t.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    AudioFx.applyPreset(idx, false);
                    buildPresets();
                    buildBands();
                }
            });
            presets.addView(t);
        }
    }

    private void buildBands() {
        bands.removeAllViews();
        int n = AudioFx.bandCount();
        if (n <= 0) {
            TextView t = new TextView(this);
            t.setText("开始播放视频后即可调节各频段");
            t.setTextColor(ThemeEngine.sub(this));
            t.setTextSize(13);
            bands.addView(t);
            return;
        }
        range = AudioFx.range();
        int min = AudioFx.minLevel();
        sliders = new SeekBar[n];
        for (int i = 0; i < n; i++) {
            final int band = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView label = new TextView(this);
            String hz = AudioFx.bandFreq((short) i) + "";
            label.setText(hz + "Hz");
            label.setTextColor(ThemeEngine.sub(this));
            label.setTextSize(11);
            label.setWidth(66);
            SeekBar sb = new SeekBar(this);
            sb.setMax(range * 2);
            int lv = AudioFx.level((short) i);
            sb.setProgress(lv - min);
            sb.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                    if (fromUser) {
                        AudioFx.setLevel((short) band, p + AudioFx.minLevel());
                    }
                }

                public void onStartTrackingTouch(SeekBar s) {
                }

                public void onStopTrackingTouch(SeekBar s) {
                    AudioFx.saveLevels();
                }
            });
            TextView val = new TextView(this);
            val.setText(((lv > 0 ? "+" : "") + (lv / 100)) + "dB");
            val.setTextColor(ThemeEngine.text(this));
            val.setTextSize(11);
            val.setWidth(56);
            val.setGravity(Gravity.RIGHT);
            row.addView(label);
            row.addView(sb);
            row.addView(val);
            sliders[i] = sb;
            bands.addView(row);
        }
    }

    protected void onDestroy() {
        AudioFx.saveLevels();
        super.onDestroy();
    }
}
