package com.shichen.player;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class HistoryAdapter extends BaseAdapter {
    private Context ctx;
    private List<VideoItem> data;
    private int sub, text;
    private OnMoreListener more;

    public interface OnMoreListener {
        void onMore(VideoItem item);
    }

    public HistoryAdapter(Context c, List<VideoItem> d, OnMoreListener m) {
        ctx = c;
        data = d;
        more = m;
        sub = ThemeEngine.sub(c);
        text = ThemeEngine.text(c);
    }

    public void setData(List<VideoItem> d) {
        data = d;
        sub = ThemeEngine.sub(ctx);
        text = ThemeEngine.text(ctx);
        notifyDataSetChanged();
    }

    public int getCount() {
        return data == null ? 0 : data.size();
    }

    public Object getItem(int i) {
        return data.get(i);
    }

    public long getItemId(int i) {
        return i;
    }

    public View getView(final int position, View v, ViewGroup parent) {
        if (v == null) {
            v = LayoutInflater.from(ctx).inflate(R.layout.item_history, parent, false);
        }
        final VideoItem it = data.get(position);
        ImageView thumb = (ImageView) v.findViewById(R.id.thumb);
        TextView title = (TextView) v.findViewById(R.id.title);
        TextView subTv = (TextView) v.findViewById(R.id.sub);
        TextView sizeTv = (TextView) v.findViewById(R.id.size);
        TextView dur = (TextView) v.findViewById(R.id.duration);
        View prog = v.findViewById(R.id.progress);

        ThumbLoader.load(it, thumb);
        title.setText(it.title);
        title.setTextColor(text);
        String info = MediaUtils.formatRelative(it.lastPlay);
        if (it.duration > 0 && it.position > 0) {
            int pct = (int) (it.position * 100L / it.duration);
            if (pct > 100) {
                pct = 100;
            }
            info += "  ·  已看 " + pct + "%";
        }
        subTv.setText(info);
        subTv.setTextColor(sub);
        if (sizeTv != null) {
            sizeTv.setText(MediaUtils.formatSize(it.size) + "  ·  "
                    + (it.resolution().length() > 0 ? it.resolution() : it.ext().toUpperCase()));
            sizeTv.setTextColor(sub);
        }
        dur.setText(it.duration > 0 ? MediaUtils.formatDuration(it.duration) : "--:--");

        if (prog != null) {
            if (it.position > 0 && it.duration > 0) {
                prog.setVisibility(View.VISIBLE);
                float p = (float) it.position / (float) it.duration;
                if (p > 1) {
                    p = 1;
                }
                final float fp = p;
                prog.post(new Runnable() {
                    public void run() {
                        View parent2 = (View) prog.getParent();
                        int w = parent2.getWidth();
                        if (w <= 0) {
                            return;
                        }
                        ViewGroup.LayoutParams lp = prog.getLayoutParams();
                        lp.width = (int) (w * fp);
                        prog.setLayoutParams(lp);
                    }
                });
            } else {
                prog.setVisibility(View.GONE);
            }
        }
        View moreBtn = v.findViewById(R.id.more);
        if (moreBtn != null) {
            if (moreBtn instanceof ImageView) {
                ((ImageView) moreBtn).setColorFilter(sub);
            }
            moreBtn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    if (more != null) {
                        more.onMore(it);
                    }
                }
            });
        }
        return v;
    }
}
