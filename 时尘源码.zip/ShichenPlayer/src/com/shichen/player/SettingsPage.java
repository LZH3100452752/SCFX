package com.shichen.player;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.text.TextWatcher;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SettingsPage {

    public interface Change {
        void onChanged();
    }

    private Activity act;
    private LinearLayout container;
    private Change change;

    public SettingsPage(Activity a, LinearLayout container, Change c) {
        act = a;
        this.container = container;
        this.change = c;
    }

    /** 分组：点击标题可折叠/展开，长按展开全部 */
    private final java.util.List<View> sections = new java.util.ArrayList<View>();
    private final java.util.List<int[]> openState = new java.util.ArrayList<int[]>();
    private final java.util.List<View> sectionViews = new java.util.ArrayList<View>();
    private final java.util.Map<View, java.util.List<View>> groupOf =
            new java.util.HashMap<View, java.util.List<View>>();
    private final java.util.List<java.util.List<View>> sectionItems =
            new java.util.ArrayList<java.util.List<View>>();
    private java.util.List<View> curItems = null;
    private final java.util.List<SearchEntry> searchIndex =
            new java.util.ArrayList<SearchEntry>();
    private LinearLayout root;
    /** 分类页模式：true 表示当前正在看某个分类的内容 */
    private boolean inCategory = false;
    /**
     * 构建分类索引页期间置位。
     * 索引页里的行只是导航入口，绝不能被 register() 记进"当前分组"，
     * 否则它们会被算进最后一个分组（关于）的内容，点进"关于"就会看到一堆分类条目。
     */
    private boolean indexMode = false;
    /** 用于返回/切换分类时重建视图 */
    private Runnable rescanRunner = null;
    private View searchBox = null;

    private static class SearchEntry {
        View view;
        String title;
        String sub;
        Runnable action;

        SearchEntry(View v, String t, String s2, Runnable a) {
            view = v;
            title = t;
            sub = s2;
            action = a;
        }
    }

    /** 单个类别的透明度选择（点选即生效，实时刷新已打开面板） */
    private static void showAlphaPicker(final Activity act, String title,
                                        final String kind, final Change change) {
        String[] os = {"0%（全透明）", "15%", "30%", "45%", "60%", "72%（默认）",
                "85%", "100%（实色）"};
        final int[] vs = {0, 15, 30, 45, 60, 72, 85, 100};
        int cur = 5;
        for (int i = 0; i < vs.length; i++) {
            if (vs[i] == Prefs.panelAlphaKind(act, kind)) {
                cur = i;
            }
        }
        Ui.sheet(act, title, os, cur, new Ui.OnPick() {
            public void onPick(int index) {
                Prefs.setPanelAlphaKind(act, kind, vs[index]);
                Ui.refreshPanelAlpha(act);
                if (change != null) {
                    change.onChanged();
                }
            }
        });
    }

    /** 专项设置：分别调整各类弹窗的背景透明度，全部实时生效 */
    private static void showAlphaAll(final Activity act, final Change change) {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        int d = (int) act.getResources().getDisplayMetrics().density;
        box.setPadding(14 * d, 12 * d, 14 * d, 12 * d);

        TextView tip = new TextView(act);
        tip.setText("分别调整各类弹窗的背景透明度，拖动即时生效");
        tip.setTextSize(12f);
        tip.setTextColor(0xAAFFFFFF);
        box.addView(tip);

        String[] names = {"main", "player", "speed", "playlist"};
        String[] labels = {"主界面 / 设置页弹窗", "播放界面弹窗", "倍速面板", "播放列表"};
        for (int i = 0; i < names.length; i++) {
            final String kind = names[i];
            box.addView(alphaSlider(act, labels[i], kind, change));
        }

        TextView reset = new TextView(act);
        reset.setText("全部恢复默认");
        reset.setTextSize(12.5f);
        reset.setTextColor(ThemeEngine.accent(act));
        reset.setGravity(Gravity.CENTER);
        reset.setPadding(0, 10 * d, 0, 4 * d);
        reset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Prefs.setPanelAlphaKind(act, "main", 72);
                Prefs.setPanelAlphaKind(act, "player", 72);
                Prefs.setPanelAlphaKind(act, "speed", 80);
                Prefs.setPanelAlphaKind(act, "playlist", 72);
                Ui.refreshPanelAlpha(act);
                Ui.toast(act, "已恢复默认");
                if (change != null) {
                    change.onChanged();
                }
            }
        });
        box.addView(reset);

        Ui.panel(act, "专项透明度设置", box, true, null);
    }

    private static View alphaSlider(final Activity act, String label,
                                    final String kind, final Change change) {
        int d = (int) act.getResources().getDisplayMetrics().density;
        LinearLayout ll = new LinearLayout(act);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setPadding(6 * d, 8 * d, 6 * d, 6 * d);

        final TextView tv = new TextView(act);
        tv.setTextSize(12.5f);
        tv.setTextColor(0xFFF0F0F5);
        ll.addView(tv);

        SeekBar sb = new SeekBar(act);
        sb.setMax(100);
        final int[] val = {Prefs.panelAlphaKind(act, kind)};
        sb.setProgress(val[0]);
        tv.setText(label + "：" + val[0] + "%");
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                val[0] = p;
                tv.setText(label + "：" + p + "%");
                Prefs.setPanelAlphaKind(act, kind, p);
                Ui.refreshPanelAlpha(act);   // 实时生效
            }

            public void onStartTrackingTouch(SeekBar b) {
            }

            public void onStopTrackingTouch(SeekBar b) {
                if (change != null) {
                    change.onChanged();
                }
            }
        });
        ll.addView(sb);
        return ll;
    }

    public String appVersion() {
        try {
            android.content.pm.PackageInfo pi = act.getPackageManager()
                    .getPackageInfo(act.getPackageName(), 0);
            return pi.versionName;
        } catch (Exception e) {
            return "未知";
        }
    }

    private void register(View v, String title, String sub, final View.OnClickListener click) {
        if (indexMode) {
            return;   // 导航行不入分组、不入搜索索引
        }
        if (curItems != null) {
            curItems.add(v);
        }
        searchIndex.add(new SearchEntry(v, title, sub == null ? "" : sub, new Runnable() {
            public void run() {
                if (click != null) {
                    click.onClick(v);
                }
            }
        }));
    }

    private String filter = "";

    /** 搜索过滤：命中标题或副标题才显示；空关键词恢复原状 */
    private void applyFilter() {
        String q = filter.trim().toLowerCase(java.util.Locale.getDefault());
        if (q.length() == 0) {
            if (!inCategory) {
                showCategoryIndex();
                return;
            }
            for (View sec : sections) {
                sec.setVisibility(View.VISIBLE);
            }
            for (int i = 0; i < sectionItems.size(); i++) {
                int open = i < openState.size() ? openState.get(i)[0] : 1;
                for (View v : sectionItems.get(i)) {
                    v.setVisibility(open == 1 ? View.VISIBLE : View.GONE);
                }
            }
            return;
        }
        // 搜索时直接跨分类列出命中项，不再受分类页/折叠影响
        if (!inCategory) {
            container.removeAllViews();
            if (searchBox != null) {
                container.addView(searchBox);
            }
            for (SearchEntry e : searchIndex) {
                boolean hit = e.title.toLowerCase(java.util.Locale.getDefault()).contains(q)
                        || e.sub.toLowerCase(java.util.Locale.getDefault()).contains(q);
                e.view.setVisibility(hit ? View.VISIBLE : View.GONE);
                if (hit) {
                    container.addView(e.view);
                }
            }
            return;
        }
        for (View sec : sections) {
            sec.setVisibility(View.GONE);
        }
        for (SearchEntry e : searchIndex) {
            boolean hit = e.title.toLowerCase(java.util.Locale.getDefault()).contains(q)
                    || e.sub.toLowerCase(java.util.Locale.getDefault()).contains(q);
            e.view.setVisibility(hit ? View.VISIBLE : View.GONE);
        }
    }

    private void applyGroupState(View header, java.util.List<View> group, int open) {
        for (View iv : group) {
            iv.setVisibility(open == 1 ? View.VISIBLE : View.GONE);
        }
        ((TextView) header).setCompoundDrawablesWithIntrinsicBounds(0, 0,
                open == 1 ? R.drawable.ic_chevron_down : R.drawable.ic_chevron_right, 0);
    }

    private void collapseAll() {
        for (int i = 0; i < sectionViews.size(); i++) {
            View h = sectionViews.get(i);
            java.util.List<View> g = groupOf.get(h);
            if (g == null) {
                continue;
            }
            int open = i < openState.size() ? openState.get(i)[0] : 0;
            applyGroupState(h, g, open);
        }
    }

    private View section(final String title) {
        final TextView t = new TextView(act);
        t.setText(title);
        t.setTextSize(12f);
        t.setTextColor(ThemeEngine.accent(act));
        int d = (int) act.getResources().getDisplayMetrics().density;
        t.setPadding(18 * d, 16 * d, 18 * d, 8 * d);
        t.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_chevron_down, 0);
        t.setCompoundDrawablePadding(6 * d);
        final java.util.List<View> group = new java.util.ArrayList<View>();
        sectionItems.add(group);
        curItems = group;
        sections.add(t);
        final int[] state = {1};   // 1 展开 0 折叠（默认全部展开）
        openState.add(state);
        sectionViews.add(t);
        groupOf.put(t, group);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                state[0] = state[0] == 1 ? 0 : 1;
                applyGroupState(t, group, state[0]);
            }
        });
        return t;
    }

    private View item(int icon, String title, String sub, View.OnClickListener click) {
        View v = LayoutInflater.from(act).inflate(R.layout.item_setting, null);
        ((ImageView) v.findViewById(R.id.icon)).setImageResource(icon);
        ((TextView) v.findViewById(R.id.title)).setText(title);
        TextView s = (TextView) v.findViewById(R.id.sub);
        if (sub == null || sub.length() == 0) {
            s.setVisibility(View.GONE);
        } else {
            s.setText(sub);
        }
        v.findViewById(R.id.arrow).setVisibility(View.VISIBLE);
        int acc = ThemeEngine.accent(act);
        ((ImageView) v.findViewById(R.id.icon)).setColorFilter(acc);
        v.setOnClickListener(click);
        register(v, title, sub, click);
        return v;
    }

    private View itemValue(int icon, String title, String sub, String value, View.OnClickListener click) {
        View v = item(icon, title, sub, click);
        TextView val = (TextView) v.findViewById(R.id.value);
        val.setVisibility(View.VISIBLE);
        val.setText(value);
        return v;
    }

    private View itemSwitch(int icon, String title, String sub, boolean on,
                            CompoundButton.OnCheckedChangeListener l) {
        View v = LayoutInflater.from(act).inflate(R.layout.item_setting, null);
        ImageView iv = (ImageView) v.findViewById(R.id.icon);
        iv.setImageResource(icon);
        iv.setColorFilter(ThemeEngine.accent(act));
        ((TextView) v.findViewById(R.id.title)).setText(title);
        TextView s = (TextView) v.findViewById(R.id.sub);
        if (sub == null || sub.length() == 0) {
            s.setVisibility(View.GONE);
        } else {
            s.setText(sub);
        }
        Switch sw = (Switch) v.findViewById(R.id.sw);
        sw.setVisibility(View.VISIBLE);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener(l);
        register(v, title, sub, null);
        return v;
    }

    public void build(final Runnable rescan) {
        container.removeAllViews();
        sections.clear();
        openState.clear();
        sectionViews.clear();
        groupOf.clear();
        sectionItems.clear();
        searchIndex.clear();
        curItems = null;
        int dp = (int) act.getResources().getDisplayMetrics().density;
        final EditText search = new EditText(act);
        search.setHint("搜索设置项（如：解码、字幕、手势、白名单）");
        search.setTextSize(13f);
        search.setSingleLine(true);
        search.setTextColor(ThemeEngine.text(act));
        search.setHintTextColor(ThemeEngine.sub(act));
        search.setBackgroundResource(R.drawable.bg_card_sm);
        search.setPadding(14 * dp, 11 * dp, 14 * dp, 11 * dp);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.setMargins(14 * dp, 8 * dp, 14 * dp, 4 * dp);
        searchBox = search;
        rescanRunner = rescan;
        container.addView(search, slp);
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence c, int a, int b, int cc) {
            }

            public void onTextChanged(CharSequence c, int a, int b, int cc) {
                filter = c.toString();
                applyFilter();
            }

            public void afterTextChanged(android.text.Editable e) {
            }
        });

        final DbHelper db = new DbHelper(act);

        /* ==================== 外观 ==================== */
        container.addView(section(act.getString(R.string.settings_ui)));
        container.addView(itemValue(R.drawable.ic_zoom, "主界面弹窗透明度", null,
                Prefs.panelAlphaKind(act, "main") + "%", new View.OnClickListener() {
            public void onClick(View v) {
                showAlphaPicker(act, "主界面弹窗背景透明度", "main", change);
            }
        }));
        container.addView(itemValue(R.drawable.ic_zoom, "播放界面弹窗透明度", null,
                Prefs.panelAlphaKind(act, "player") + "%", new View.OnClickListener() {
            public void onClick(View v) {
                showAlphaPicker(act, "播放界面弹窗背景透明度", "player", change);
            }
        }));
        container.addView(itemValue(R.drawable.ic_zoom, "专项透明度设置", null,
                "分别调整各类弹窗", new View.OnClickListener() {
            public void onClick(View v) {
                showAlphaAll(act, change);
            }
        }));

        container.addView(itemValue(R.drawable.ic_theme, act.getString(R.string.theme), null,
                ThemeEngine.MODE_NAMES[Prefs.themeMode(act)], new View.OnClickListener() {
            public void onClick(View v) {
                Ui.sheet(act, act.getString(R.string.theme), ThemeEngine.MODE_NAMES,
                        Prefs.themeMode(act), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setThemeMode(act, index);
                        change.onChanged();
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_sparkle, act.getString(R.string.accent), null,
                ThemeEngine.ACCENT_NAMES[idx(Prefs.accent(act))], new View.OnClickListener() {
            public void onClick(View v) {
                Ui.sheet(act, act.getString(R.string.accent), ThemeEngine.ACCENT_NAMES,
                        idx(Prefs.accent(act)), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setAccent(act, index);
                        change.onChanged();
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_sort, act.getString(R.string.default_sort), null,
                SortEngine.summary(null, Prefs.sortField(act), Prefs.sortAsc(act)),
                new View.OnClickListener() {
                    public void onClick(View v) {
                        Ui.sortDialog(act, new Ui.SortCb() {
                            public void onApply() {
                                rebuild(rescan);
                                rescan.run();
                            }
                        });
                    }
                }));
        container.addView(itemValue(R.drawable.ic_grid, act.getString(R.string.default_view), null,
                Prefs.gridView(act) ? act.getString(R.string.view_grid)
                        : act.getString(R.string.view_list), new View.OnClickListener() {
            public void onClick(View v) {
                String[] opts = {act.getString(R.string.view_grid), act.getString(R.string.view_list)};
                Ui.sheet(act, act.getString(R.string.default_view), opts,
                        Prefs.gridView(act) ? 0 : 1, new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setGridView(act, index == 0);
                        rebuild(rescan);
                    }
                });
            }
        }));

        /* ==================== 扫描与目录 ==================== */
        container.addView(section(act.getString(R.string.settings_scan)));
        container.addView(itemValue(R.drawable.ic_whitelist, act.getString(R.string.whitelist),
                "仅扫描白名单中的目录；为空则扫描全部",
                db.dirs(DbHelper.TYPE_WHITE).size() + " 个", new View.OnClickListener() {
            public void onClick(View v) {
                showCustomDirs(DbHelper.TYPE_WHITE, "白名单目录", rescan);
            }
        }));
        container.addView(itemValue(R.drawable.ic_blacklist, act.getString(R.string.blacklist),
                "这些目录中的视频将被忽略",
                db.dirs(DbHelper.TYPE_BLACK).size() + " 个", new View.OnClickListener() {
            public void onClick(View v) {
                showCustomDirs(DbHelper.TYPE_BLACK, "黑名单目录", rescan);
            }
        }));
        container.addView(itemValue(R.drawable.ic_timer, act.getString(R.string.min_duration),
                "过滤掉极短的无用片段", Prefs.minDuration(act) + " 秒", new View.OnClickListener() {
            public void onClick(View v) {
                String[] opts = {"不限制", "2 秒", "5 秒", "10 秒", "30 秒", "60 秒"};
                final int[] vals = {0, 2, 5, 10, 30, 60};
                Ui.sheet(act, act.getString(R.string.min_duration), opts,
                        cur(vals, Prefs.minDuration(act)), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setMinDuration(act, vals[index]);
                        rebuild(rescan);
                        rescan.run();
                    }
                });
            }
        }));
        container.addView(itemSwitch(R.drawable.ic_scan, "启动时自动扫描", null,
                Prefs.scanOnStart(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setScanOnStart(act, v);
            }
        }));
        container.addView(item(R.drawable.ic_refresh, "立即重新扫描", "重新读取媒体库",
                new View.OnClickListener() {
                    public void onClick(View v) {
                        rescan.run();
                    }
                }));
        container.addView(item(R.drawable.ic_folder_open, "文件夹浏览",
                "按目录层级查看视频（仅显示含视频的文件夹）", new View.OnClickListener() {
            public void onClick(View v) {
                android.content.Intent in = new android.content.Intent(act, MainActivity.class);
                in.putExtra("mode", 1);
                in.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP);
                act.startActivity(in);
            }
        }));

        /* ==================== 播放 ==================== */
        container.addView(section(act.getString(R.string.settings_play)));
        container.addView(itemValue(R.drawable.ic_pip, "小窗模式", null,
                Prefs.floatWindowMode(act) ? "悬浮窗（可拖动/有进度条）" : "系统画中画",
                new View.OnClickListener() {
            public void onClick(View v) {
                String[] os = {"系统画中画（轻量，系统控制）",
                        "悬浮窗（可拖动、带进度条与播放键，需授权）"};
                Ui.sheet(act, "小窗模式", os, Prefs.floatWindowMode(act) ? 1 : 0,
                        new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setFloatWindowMode(act, index == 1);
                        change.onChanged();
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_volume, "音量放大",
                "视频原声音太小时可放大，最大 200%",
                Prefs.boostVolume(act) + "%", new View.OnClickListener() {
            public void onClick(View v) {
                String[] o = {"100%（原始）", "120%", "140%", "160%", "180%", "200%"};
                final int[] vals = {100, 120, 140, 160, 180, 200};
                int cur = 0;
                for (int i = 0; i < vals.length; i++) {
                    if (vals[i] == Prefs.boostVolume(act)) {
                        cur = i;
                    }
                }
                Ui.sheet(act, "音量放大", o, cur, new Ui.OnPick() {
                    public void onPick(int i) {
                        Prefs.setBoostVolume(act, vals[i]);
                        change.onChanged();
                    }
                });
            }
        }));

        container.addView(itemSwitch(R.drawable.ic_shield, "解码失败自动回退",
                "自研内核出错时切到系统内核", Prefs.fallback(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setFallback(act, v);
                    }
                }));

        container.addView(itemValue(R.drawable.ic_speed, "默认播放速度", null,
                MediaUtils.formatSpeed(Prefs.defaultSpeed(act)), new View.OnClickListener() {
            public void onClick(View v) {
                String[] opts = {"0.25x", "0.5x", "0.75x", "1.0x", "1.25x", "1.5x", "2.0x", "3.0x"};
                final float[] vals = {0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f};
                Ui.sheet(act, act.getString(R.string.speed_title), opts,
                        curF(vals, Prefs.defaultSpeed(act)), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setDefaultSpeed(act, vals[index]);
                        rebuild(rescan);
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_fw, "快进/快退秒数", "拖动与按钮的步长",
                Prefs.skipSec(act) + " 秒", new View.OnClickListener() {
            public void onClick(View v) {
                String[] opts = {"5 秒", "10 秒", "15 秒", "30 秒", "60 秒"};
                final int[] vals = {5, 10, 15, 30, 60};
                Ui.sheet(act, "快进/快退秒数", opts, cur(vals, Prefs.skipSec(act)), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setSkipSec(act, vals[index]);
                        rebuild(rescan);
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_repeat, act.getString(R.string.repeat_mode), null,
                repeatName(Prefs.repeatMode(act)), new View.OnClickListener() {
            public void onClick(View v) {
                String[] opts = {"不循环", "列表循环", "单曲循环"};
                Ui.sheet(act, act.getString(R.string.repeat_mode), opts,
                        Prefs.repeatMode(act), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setRepeatMode(act, index);
                        rebuild(rescan);
                    }
                });
            }
        }));
        container.addView(itemSwitch(R.drawable.ic_history, act.getString(R.string.remember_pos),
                null, Prefs.rememberPos(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setRememberPos(act, v);
            }
        }));
        container.addView(itemSwitch(R.drawable.ic_help, "自动续播上次进度", null,
                Prefs.rememberPos(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setRememberPos(act, v);
            }
        }));
        container.addView(itemSwitch(R.drawable.ic_playlist, act.getString(R.string.auto_next),
                null, Prefs.autoNext(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setAutoNext(act, v);
            }
        }));
        container.addView(itemSwitch(R.drawable.ic_audio, act.getString(R.string.background_play),
                "退出界面后继续播放声音", Prefs.backgroundPlay(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setBackgroundPlay(act, v);
                    }
                }));
        container.addView(itemSwitch(R.drawable.ic_audio, "耳机拔出自动暂停",
                null, Prefs.headphonePause(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setHeadphonePause(act, v);
            }
        }));
        container.addView(itemSwitch(R.drawable.ic_brightness, act.getString(R.string.keep_screen_on),
                null, Prefs.keepScreenOn(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setKeepScreenOn(act, v);
            }
        }));

        /* ==================== 画面与方向 ==================== */
                container.addView(itemSwitch(R.drawable.ic_eye, "显示时长与电量",
                "播放时顶部左侧时长、右侧电量时间", Prefs.statusOverlay(act),
                new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setStatusOverlay(act, v);
            }
        }));
        container.addView(itemValue(R.drawable.ic_timer, "左侧显示内容", "播放时顶部左侧",
                new String[]{"当前 / 总时长", "总时长", "剩余时长"}[Prefs.statusLeftMode(act)],
                new View.OnClickListener() {
            public void onClick(View v) {
                String[] o = {"当前 / 总时长", "总时长", "剩余时长"};
                Ui.sheet(act, "左侧显示内容", o, Prefs.statusLeftMode(act), new Ui.OnPick() {
                    public void onPick(int i) {
                        Prefs.setStatusLeftMode(act, i);
                        change.onChanged();
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_brightness, "右侧显示内容", "播放时顶部右侧",
                new String[]{"电量 + 时间", "仅电量", "仅时间"}[Prefs.statusRightMode(act)],
                new View.OnClickListener() {
            public void onClick(View v) {
                String[] o = {"电量 + 时间", "仅电量", "仅时间"};
                Ui.sheet(act, "右侧显示内容", o, Prefs.statusRightMode(act), new Ui.OnPick() {
                    public void onPick(int i) {
                        Prefs.setStatusRightMode(act, i);
                        change.onChanged();
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_ratio, "左右同步内缩",
                "刘海屏 / 圆角补偿", Prefs.statusInsetX(act) + " dp",
                new View.OnClickListener() {
            public void onClick(View v) {
                String[] o = {"0", "20", "40", "60", "80", "100", "130", "160", "200"};
                final int[] vals = {0, 20, 40, 60, 80, 100, 130, 160, 200};
                int cur = 0;
                for (int i = 0; i < vals.length; i++) {
                    if (vals[i] == Prefs.statusInsetX(act)) {
                        cur = i;
                    }
                }
                Ui.sheet(act, "左右同步内缩", o, cur, new Ui.OnPick() {
                    public void onPick(int i) {
                        Prefs.setStatusInsetX(act, vals[i]);
                        change.onChanged();
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_arrow_up, "距顶部偏移",
                "状态条距屏幕顶部", Prefs.statusInsetY(act) + " dp", new View.OnClickListener() {
            public void onClick(View v) {
                String[] o = {"0", "10", "24", "40", "60", "80", "110", "140", "180"};
                final int[] vals = {0, 10, 24, 40, 60, 80, 110, 140, 180};
                int cur = 0;
                for (int i = 0; i < vals.length; i++) {
                    if (vals[i] == Prefs.statusInsetY(act)) {
                        cur = i;
                    }
                }
                Ui.sheet(act, "距顶部偏移", o, cur, new Ui.OnPick() {
                    public void onPick(int i) {
                        Prefs.setStatusInsetY(act, vals[i]);
                        change.onChanged();
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_screen_rotate, act.getString(R.string.orientation),
                "进入播放时使用的屏幕方向",
                oriName(Prefs.orientation(act)), new View.OnClickListener() {
            public void onClick(View v) {
                String[] opts = {act.getString(R.string.ori_video), act.getString(R.string.ori_auto),
                        act.getString(R.string.ori_landscape), act.getString(R.string.ori_portrait),
                        act.getString(R.string.ori_system)};
                Ui.sheet(act, act.getString(R.string.orientation), opts,
                        Prefs.orientation(act), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setOrientation(act, index);
                        rebuild(rescan);
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_ratio, "默认画面比例", null,
                ratioName(Prefs.defaultRatio(act)), new View.OnClickListener() {
            public void onClick(View v) {
                String[] opts = {"适应屏幕", "16:9", "4:3", "铺满(拉伸)", "原始尺寸", "裁剪填充", "1:1", "21:9"};
                Ui.sheet(act, act.getString(R.string.ratio_title), opts,
                        Prefs.defaultRatio(act), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setDefaultRatio(act, index);
                        rebuild(rescan);
                    }
                });
            }
        }));

        /* ==================== 解码与渲染 ==================== */
        container.addView(itemValue(R.drawable.ic_decode, act.getString(R.string.decode_mode),
                "自研内核可强制软/硬解；系统内核兼容性最好",
                decodeName(Prefs.decodeMode(act)), new View.OnClickListener() {
            public void onClick(View v) {
                String[] opts = {"系统内核 MediaPlayer", "自研内核·硬件解码",
                        "自研内核·软件解码", "自动（先自研后回退）"};
                Ui.sheet(act, act.getString(R.string.decode_mode), opts,
                        Prefs.decodeMode(act), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setDecodeMode(act, index);
                        rebuild(rescan);
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_rotate, "渲染模式",
                "兼容模式最稳定；高级模式支持缩放与裁剪",
                Prefs.renderKind(act) == VideoRenderView.KIND_TEXTURE ? "高级模式" : "兼容模式",
                new View.OnClickListener() {
                    public void onClick(View v) {
                        String[] opts = {"兼容模式（SurfaceView，最稳定）",
                                "高级模式（TextureView，支持缩放裁剪）"};
                        Ui.sheet(act, "渲染模式", opts,
                                Prefs.renderKind(act), new Ui.OnPick() {
                            public void onPick(int index) {
                                Prefs.setRenderKind(act, index);
                                rebuild(rescan);
                            }
                        });
                    }
                }));

        /* ==================== 手势 ==================== */
        container.addView(itemSwitch(R.drawable.ic_fw, act.getString(R.string.g_seek),
                "左右滑动快进/快退", Prefs.gSeek(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setGSeek(act, v);
            }
        }));
        container.addView(itemSwitch(R.drawable.ic_brightness, act.getString(R.string.g_brightness),
                "左半屏上下滑动", Prefs.gBrightness(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setGBrightness(act, v);
                    }
                }));
        container.addView(itemSwitch(R.drawable.ic_volume, act.getString(R.string.g_volume),
                "右半屏上下滑动", Prefs.gVolume(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setGVolume(act, v);
            }
        }));
        container.addView(itemSwitch(R.drawable.ic_zoom, act.getString(R.string.g_zoom),
                "双指捏合缩放画面", Prefs.gZoom(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setGZoom(act, v);
            }
        }));
        container.addView(itemSwitch(R.drawable.ic_speed, act.getString(R.string.g_long_press),
                "按住屏幕临时加速", Prefs.gLongPress(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setGLongPress(act, v);
                    }
                }));
        container.addView(itemSwitch(R.drawable.ic_pause, act.getString(R.string.g_double_tap),
                null, Prefs.gDoubleTap(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setGDoubleTap(act, v);
            }
        }));
        container.addView(itemValue(R.drawable.ic_gesture, "滑动灵敏度",
                "横向滑满屏幕对应的快进秒数", Prefs.seekSensitivity(act) + " 秒",
                new View.OnClickListener() {
                    public void onClick(View v) {
                        String[] opts = {"60 秒", "90 秒", "120 秒", "180 秒", "240 秒"};
                        final int[] vals = {60, 90, 120, 180, 240};
                        Ui.sheet(act, "滑动灵敏度", opts, cur(vals, Prefs.seekSensitivity(act)),
                                new Ui.OnPick() {
                            public void onPick(int index) {
                                Prefs.setSeekSensitivity(act, vals[index]);
                                rebuild(rescan);
                            }
                        });
                    }
                }));
        container.addView(itemValue(R.drawable.ic_speed, "长按倍速",
                "按住屏幕临时加速，松手恢复",
                MediaUtils.formatSpeed(Prefs.longPressSpeed(act)), new View.OnClickListener() {
            public void onClick(View v) {
                String[] opts = {"1.5x", "1.75x", "2x", "2.5x", "3x", "4x"};
                final float[] fv = {1.5f, 1.75f, 2f, 2.5f, 3f, 4f};
                Ui.sheet(act, "长按倍速", opts, lpIdx(), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setLongPressSpeed(act, fv[index]);
                        rebuild(rescan);
                    }
                });
            }
        }));

        /* ==================== 字幕 ==================== */
        container.addView(section(act.getString(R.string.settings_subtitle)));
        container.addView(itemSwitch(R.drawable.ic_subtitle, "默认显示字幕", null,
                Prefs.subtitleOn(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setSubtitleOn(act, v);
            }
        }));
        container.addView(itemValue(R.drawable.ic_subtitle, act.getString(R.string.subtitle_size),
                null, Prefs.subtitleSize(act) + " sp", new View.OnClickListener() {
            public void onClick(View v) {
                String[] opts = {"12 sp", "14 sp", "16 sp", "18 sp", "20 sp", "24 sp", "28 sp"};
                final int[] vals = {12, 14, 16, 18, 20, 24, 28};
                Ui.sheet(act, act.getString(R.string.subtitle_size), opts,
                        cur(vals, Prefs.subtitleSize(act)), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setSubtitleSize(act, vals[index]);
                        rebuild(rescan);
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_timer, act.getString(R.string.subtitle_delay),
                "正数延后，负数提前", Prefs.subtitleDelay(act) + " ms", new View.OnClickListener() {
            public void onClick(View v) {
                String[] opts = {"-3000 ms", "-1500 ms", "-500 ms", "0 ms",
                        "500 ms", "1500 ms", "3000 ms"};
                final int[] vals = {-3000, -1500, -500, 0, 500, 1500, 3000};
                Ui.sheet(act, act.getString(R.string.subtitle_delay), opts,
                        cur(vals, Prefs.subtitleDelay(act)), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setSubtitleDelay(act, vals[index]);
                        rebuild(rescan);
                    }
                });
            }
        }));
        container.addView(itemValue(R.drawable.ic_theme, "字幕颜色", null,
                subColorName(Prefs.subtitleColor(act)), new View.OnClickListener() {
            public void onClick(View v) {
                String[] opts = {"白色", "黄色", "青色", "绿色", "粉色"};
                Ui.sheet(act, "字幕颜色", opts, Prefs.subtitleColor(act), new Ui.OnPick() {
                    public void onPick(int index) {
                        Prefs.setSubtitleColor(act, index);
                        rebuild(rescan);
                    }
                });
            }
        }));

        /* ==================== 音效 ==================== */
        container.addView(itemSwitch(R.drawable.ic_equalizer, "启用音频增强",
                "开启均衡器 / 低音 / 环绕", Prefs.audioFxOn(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        AudioFx.setEnabled(v);
                    }
                }));
        container.addView(item(R.drawable.ic_equalizer, act.getString(R.string.equalizer),
                "十段调节 + 十种预设", new View.OnClickListener() {
            public void onClick(View v) {
                act.startActivity(new android.content.Intent(act, EqualizerActivity.class));
            }
        }));

        /* ==================== 高级 ==================== */
        container.addView(section(act.getString(R.string.settings_adv)));
        container.addView(itemSwitch(R.drawable.ic_eye, "显示调试信息",
                "播放页显示内核与缓冲状态", Prefs.showDebug(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setShowDebug(act, v);
                    }
                }));
        container.addView(itemSwitch(R.drawable.ic_timer, act.getString(R.string.adv_resume_small),
                null, Prefs.hideShort(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setHideShort(act, v);
            }
        }));
        container.addView(item(R.drawable.ic_url, act.getString(R.string.url_title),
                "支持 http / https / rtsp 网络流", new View.OnClickListener() {
            public void onClick(View v) {
                Ui.input(act, act.getString(R.string.url_title), "",
                        act.getString(R.string.url_hint), new Ui.OnText() {
                    public void onText(String text) {
                        if (text.length() == 0) {
                            return;
                        }
                        ArrayList<String> pl = new ArrayList<String>();
                        pl.add(text);
                        android.content.Intent in = new android.content.Intent(act, PlayerActivity.class);
                        in.putExtra("path", text);
                        in.putStringArrayListExtra("list", pl);
                        act.startActivity(in);
                    }
                });
            }
        }));

        /* ==================== 其他 ==================== */
        container.addView(item(R.drawable.ic_bug, "导出诊断报告",
                "把播放问题日志保存到文件，便于定位", new View.OnClickListener() {
            public void onClick(View v) {
                String p = Diagnostics.export(act);
                if (p == null) {
                    Ui.toast(act, "导出失败，请检查存储权限");
                } else {
                    Ui.toast(act, "已导出到：\n" + p);
                }
            }
        }));
        container.addView(item(R.drawable.ic_info, "查看诊断日志", "在应用内查看最近记录",
                new View.OnClickListener() {
            public void onClick(View v) {
                TextView tv = new TextView(act);
                tv.setText(Diagnostics.text());
                tv.setTextSize(11f);
                tv.setTextColor(0xFFE8E8F0);
                tv.setPadding(16, 16, 16, 16);
                tv.setTextIsSelectable(true);
                android.widget.ScrollView sv = new android.widget.ScrollView(act);
                sv.addView(tv);
                Ui.panel(act, "诊断日志", sv, true, null);
            }
        }));

        container.addView(section("关于"));
        container.addView(item(R.drawable.ic_info, act.getString(R.string.settings_about),
                "版本 " + appVersion() + " · 图标手绘", new View.OnClickListener() {
            public void onClick(View v) {
                showAbout();
            }
        }));
        container.addView(item(R.drawable.ic_delete, act.getString(R.string.clear_history),
                "同时清除播放进度与收藏", new View.OnClickListener() {
            public void onClick(View v) {
                Ui.confirm(act, "确定清空所有历史与收藏？", new Runnable() {
                    public void run() {
                        db.clearHistory();
                        Ui.toast(act, "已清空");
                        rescan.run();
                    }
                });
            }
        }));
        container.addView(item(R.drawable.ic_history, "清空播放进度",
                "保留记录，仅把进度归零", new View.OnClickListener() {
            public void onClick(View v) {
                Ui.confirm(act, "确定清除全部播放进度？", new Runnable() {
                    public void run() {
                        db.clearPosition();
                        Ui.toast(act, "已清除");
                        rescan.run();
                    }
                });
            }
        }));
        // 默认全部展开，不再折叠隐藏内容
        collapseAll();
        // 改为两级导航：先选分类，再进入该分类的设置页
        showCategoryIndex();
    }

    /** 分类索引页：列出全部分类，点进去才是设置项（不再用折叠） */
    private void showCategoryIndex() {
        inCategory = false;
        indexMode = true;
        container.removeAllViews();
        if (searchBox != null) {
            container.addView(searchBox);
        }
        buildQuickNav();
        int dp = (int) act.getResources().getDisplayMetrics().density;
        for (int i = 0; i < sectionViews.size(); i++) {
            final View header = sectionViews.get(i);
            String name = ((TextView) header).getText().toString();
            java.util.List<View> items = groupOf.get(header);
            int n = items != null ? items.size() : 0;
            final String nm = name;
            container.addView(item(catIcon(nm), nm, n + " 项",
                    new View.OnClickListener() {
                public void onClick(View v) {
                    openCategory(header, nm);
                }
            }));
        }
        TextView tip = new TextView(act);
        tip.setText("点分类进入对应的设置页");
        tip.setTextSize(11.5f);
        tip.setTextColor(ThemeEngine.sub(act));
        tip.setPadding(16 * dp, 10 * dp, 16 * dp, 14 * dp);
        container.addView(tip);
        indexMode = false;
    }

    private int catIcon(String name) {
        if (name.contains("播放")) {
            return R.drawable.ic_play;
        }
        if (name.contains("字幕")) {
            return R.drawable.ic_subtitle;
        }
        if (name.contains("媒体库")) {
            return R.drawable.ic_folder;
        }
        if (name.contains("界面")) {
            return R.drawable.ic_theme;
        }
        if (name.contains("高级")) {
            return R.drawable.ic_sparkle;
        }
        return R.drawable.ic_info;
    }

    /** 进入某个分类的设置页：顶部有返回，其余全是该分类的设置项 */
    private void openCategory(final View header, String name) {
        inCategory = true;
        container.removeAllViews();
        if (searchBox != null) {
            container.addView(searchBox);
        }
        int dp = (int) act.getResources().getDisplayMetrics().density;

        LinearLayout bar = new LinearLayout(act);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(8 * dp, 6 * dp, 8 * dp, 8 * dp);
        ImageButton back = new ImageButton(act);
        back.setImageResource(R.drawable.ic_back);
        back.setBackgroundResource(android.R.color.transparent);
        back.setColorFilter(ThemeEngine.accent(act));
        back.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        back.setPadding(6 * dp, 6 * dp, 6 * dp, 6 * dp);
        back.setLayoutParams(new LinearLayout.LayoutParams(
                (int) (34 * dp), (int) (34 * dp)));
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showCategoryIndex();
            }
        });
        bar.addView(back);
        TextView t = new TextView(act);
        t.setText(name);
        t.setTextSize(16f);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setTextColor(ThemeEngine.text(act));
        t.setPadding(6 * dp, 0, 0, 0);
        bar.addView(t);
        container.addView(bar);

        java.util.List<View> items = groupOf.get(header);
        if (items != null) {
            for (View v : items) {
                v.setVisibility(View.VISIBLE);
                container.addView(v);
            }
        }
        TextView end = new TextView(act);
        end.setText("— " + name + " 设置结束 —");
        end.setTextSize(11f);
        end.setTextColor(ThemeEngine.sub(act));
        end.setGravity(Gravity.CENTER);
        end.setPadding(0, 14 * dp, 0, 16 * dp);
        container.addView(end);
    }

    /**
     * 顶部横向导航条：点分类名直接滚动到该分组。
     * 相比折叠，既缩短查找路径，又不会把内容藏起来。
     */
    private void buildQuickNav() {
        if (sections.isEmpty()) {
            return;
        }
        int d = (int) act.getResources().getDisplayMetrics().density;
        android.widget.HorizontalScrollView hs =
                new android.widget.HorizontalScrollView(act);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout ll = new LinearLayout(act);
        ll.setOrientation(LinearLayout.HORIZONTAL);
        ll.setPadding(12 * d, 8 * d, 12 * d, 8 * d);
        int acc = ThemeEngine.accent(act);
        for (int i = 0; i < sections.size(); i++) {
            final View target = sections.get(i);
            TextView chip = new TextView(act);
            chip.setText(((TextView) target).getText().toString());
            chip.setTextSize(12.5f);
            chip.setTextColor(acc);
            chip.setGravity(Gravity.CENTER);
            chip.setBackgroundResource(R.drawable.bg_chip);
            chip.setPadding(14 * d, 7 * d, 14 * d, 7 * d);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 8 * d, 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    scrollToSection(target);
                }
            });
            ll.addView(chip);
        }
        hs.addView(ll);
        if (container.getChildCount() > 0) {
            container.addView(hs, 0);
        } else {
            container.addView(hs);
        }
    }

    /** 滚动到指定分组标题（等视图挂载后再执行，确保能取到 ScrollView） */
    private void scrollToSection(final View target) {
        target.post(new Runnable() {
            public void run() {
                android.view.ViewParent vp = container.getParent();
                View p = null;
                while (vp instanceof View) {
                    View cv = (View) vp;
                    if (cv instanceof android.widget.ScrollView) {
                        p = cv;
                        break;
                    }
                    vp = cv.getParent();
                }
                if (p instanceof android.widget.ScrollView) {
                    ((android.widget.ScrollView) p).smoothScrollTo(0, target.getTop());
                }
            }
        });
    }

    private void rebuild(Runnable rescan) {
        build(rescan);
    }

    private int lpIdx() {
        float v = Prefs.longPressSpeed(act);
        float[] fv = {1.5f, 1.75f, 2f, 2.5f, 3f, 4f};
        for (int i = 0; i < fv.length; i++) {
            if (Math.abs(fv[i] - v) < 0.01f) {
                return i;
            }
        }
        return 2;
    }

    private static int idx(int v) {
        return Math.max(0, Math.min(11, v));
    }

    private static int cur(int[] vals, int v) {
        for (int i = 0; i < vals.length; i++) {
            if (vals[i] == v) {
                return i;
            }
        }
        return 0;
    }

    private static int curF(float[] vals, float v) {
        for (int i = 0; i < vals.length; i++) {
            if (Math.abs(vals[i] - v) < 0.01f) {
                return i;
            }
        }
        return 0;
    }

    public static String repeatName(int m) {
        switch (m) {
            case Prefs.REPEAT_ALL:
                return "列表循环";
            case Prefs.REPEAT_ONE:
                return "单曲循环";
            default:
                return "不循环";
        }
    }

    public static String oriName(int o) {
        switch (o) {
            case Prefs.O_AUTO:
                return "自动旋转";
            case Prefs.O_LANDSCAPE:
                return "强制横屏";
            case Prefs.O_PORTRAIT:
                return "强制竖屏";
            case Prefs.O_SYSTEM:
                return "跟随系统";
            default:
                return "跟随视频";
        }
    }

    public static String ratioName(int r) {
        switch (r) {
            case Prefs.RATIO_16_9:
                return "16:9";
            case Prefs.RATIO_4_3:
                return "4:3";
            case Prefs.RATIO_FILL:
                return "铺满";
            case Prefs.RATIO_ORIGINAL:
                return "原始";
            case Prefs.RATIO_CROP:
                return "裁剪";
            case Prefs.RATIO_1_1:
                return "1:1";
            case Prefs.RATIO_21_9:
                return "21:9";
            default:
                return "适应";
        }
    }

    public static String decodeName(int m) {
        switch (m) {
            case Prefs.DECODE_SYSTEM:
                return "系统内核";
            case Prefs.DECODE_HW:
                return "硬件解码";
            case Prefs.DECODE_SW:
                return "软件解码";
            default:
                return "自动";
        }
    }

    public static String subColorName(int c) {
        switch (c) {
            case 1:
                return "黄色";
            case 2:
                return "青色";
            case 3:
                return "绿色";
            case 4:
                return "粉色";
            default:
                return "白色";
        }
    }

    /** 自定义目录管理：浏览选择 / 手动输入 / 删除，改完热加载（不重启界面） */
    private void showCustomDirs(final int type, final String title, final Runnable rescan) {
        final DbHelper db2 = new DbHelper(act);
        int dp = (int) act.getResources().getDisplayMetrics().density;
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(4 * dp, 2 * dp, 4 * dp, 4 * dp);

        final LinearLayout list = new LinearLayout(act);
        list.setOrientation(LinearLayout.VERTICAL);

        final Runnable[] reload = new Runnable[1];
        reload[0] = new Runnable() {
            public void run() {
                list.removeAllViews();
                java.util.List<String> dirs = db2.dirs(type);
                if (dirs.isEmpty()) {
                    TextView empty = new TextView(act);
                    empty.setText("尚未添加目录");
                    empty.setTextSize(12.5f);
                    empty.setTextColor(ThemeEngine.sub(act));
                    empty.setPadding(12 * dp, 14 * dp, 12 * dp, 14 * dp);
                    list.addView(empty);
                }
                int sub = ThemeEngine.sub(act);
                for (final String dir : dirs) {
                    LinearLayout row = new LinearLayout(act);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(android.view.Gravity.CENTER_VERTICAL);
                    row.setBackgroundResource(R.drawable.bg_panel_row);
                    row.setPadding(12 * dp, 10 * dp, 8 * dp, 10 * dp);
                    TextView name = new TextView(act);
                    name.setText(new java.io.File(dir).getName());
                    name.setTextSize(13.5f);
                    name.setTextColor(0xFFF0F0F5);
                    name.setSingleLine(true);
                    name.setLayoutParams(new LinearLayout.LayoutParams(
                            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    TextView path = new TextView(act);
                    path.setText(dir);
                    path.setTextSize(10.5f);
                    path.setTextColor(sub);
                    path.setSingleLine(true);
                    path.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
                    path.setLayoutParams(new LinearLayout.LayoutParams(
                            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f));
                    TextView del = new TextView(act);
                    del.setText("移除");
                    del.setTextSize(12f);
                    del.setTextColor(ThemeEngine.accent(act));
                    del.setPadding(10 * dp, 6 * dp, 4 * dp, 6 * dp);
                    del.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            db2.removeDir(dir, type);
                            reload[0].run();
                            hotReload(rescan);
                        }
                    });
                    row.addView(name);
                    row.addView(path);
                    row.addView(del);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.topMargin = 6 * dp;
                    list.addView(row, lp);
                }
            }
        };
        reload[0].run();
        box.addView(list);

        LinearLayout bar = new LinearLayout(act);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        bar.setPadding(4 * dp, 10 * dp, 4 * dp, 2 * dp);

        TextView browse = new TextView(act);
        browse.setText("＋ 浏览选择目录");
        browse.setTextSize(12.5f);
        browse.setTextColor(0xFFF0F0F5);
        browse.setBackgroundResource(R.drawable.bg_panel_btn);
        browse.setGravity(android.view.Gravity.CENTER);
        browse.setPadding(14 * dp, 9 * dp, 14 * dp, 9 * dp);
        browse.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                DirPicker.pick(act, "选择目录", new DirPicker.OnDir() {
                    public void onDir(String path) {
                        db2.addDir(path, type);
                        reload[0].run();
                        hotReload(rescan);
                    }
                });
            }
        });
        bar.addView(browse);

        TextView manual = new TextView(act);
        manual.setText("手动输入路径");
        manual.setTextSize(12.5f);
        manual.setTextColor(0xFFF0F0F5);
        manual.setBackgroundResource(R.drawable.bg_panel_btn);
        manual.setGravity(android.view.Gravity.CENTER);
        manual.setPadding(14 * dp, 9 * dp, 14 * dp, 9 * dp);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.leftMargin = 8 * dp;
        manual.setLayoutParams(mlp);
        manual.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Ui.input(act, "输入目录路径", "", "/sdcard/...", new Ui.OnText() {
                    public void onText(String text) {
                        String p = text.trim();
                        if (p.length() == 0) {
                            return;
                        }
                        if (!new java.io.File(p).exists()) {
                            Ui.toast(act, "路径不存在，仍已添加");
                        }
                        db2.addDir(p, type);
                        reload[0].run();
                        hotReload(rescan);
                    }
                });
            }
        });
        bar.addView(manual);
        box.addView(bar);

        Ui.panel(act, title, box, true, null);
    }

    /**
     * 热加载：先后台重新扫描，再在下一帧安全地刷新设置页计数。
     * 全程 try-catch + post，避免与正在 dismiss 的弹窗冲突导致闪退。
     */
    private void hotReload(final Runnable rescan) {
        try {
            if (rescan != null) {
                rescan.run();
            }
        } catch (Exception ignored) {
        }
        // 面板内列表已实时刷新，这里只做后台重扫；下次进入设置页即显示新计数，
        // 不重建界面，彻底避免闪退
        if (act != null) {
            act.runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Ui.toast(act, "已生效，正在重新扫描");
                    } catch (Exception ignored) {
                    }
                }
            });
        }
    }

    private void showDirs(final int type, final String title, final Runnable rescan) {
        final DbHelper db = new DbHelper(act);
        List<String> existing = db.dirs(type);
        List<String> all = VideoScanner.commonDirs();
        final List<String> options = new ArrayList<String>();
        java.util.Set<String> set = new java.util.HashSet<String>(existing);
        options.addAll(existing);
        for (String s : all) {
            if (!set.contains(s)) {
                options.add(s);
            }
        }
        Ui.dirPick(act, title + "（点击已选项可移除）", options, new Ui.OnDirs() {
            public void onDirs(List<String> dirs) {
                if (dirs.isEmpty()) {
                    return;
                }
                String d = dirs.get(0);
                if (db.dirs(type).contains(d)) {
                    db.removeDir(d, type);
                    Ui.toast(act, act.getString(R.string.removed));
                } else {
                    db.addDir(d, type);
                    Ui.toast(act, type == DbHelper.TYPE_WHITE
                            ? act.getString(R.string.added_to_whitelist)
                            : act.getString(R.string.added_to_blacklist));
                }
                rebuild(rescan);
                rescan.run();
            }
        });
    }

    private void showAbout() {
        View v = LayoutInflater.from(act).inflate(R.layout.dialog_info, null);
        TextView name = (TextView) v.findViewById(R.id.name);
        name.setText("时尘播放器 Shichen Player");
        name.setTextColor(ThemeEngine.accent(act));
        LinearLayout rows = (LinearLayout) v.findViewById(R.id.rows);
        rows.addView(Ui.row(act, "版本", appVersion()));
        rows.addView(Ui.row(act, "解码内核", "系统 MediaPlayer + 自研 MediaCodec"));
        rows.addView(Ui.row(act, "封装格式", "MP4 MKV WebM AVI MOV TS FLV 3GP M4V"));
        rows.addView(Ui.row(act, "字幕", "SRT VTT ASS SSA LRC"));
        rows.addView(Ui.row(act, "排序字段", "12 种，支持升降序"));
        rows.addView(Ui.row(act, "主题", "3 种模式 × 12 种强调色"));
        rows.addView(Ui.row(act, "图标", "全部手绘矢量生成"));
        new android.app.AlertDialog.Builder(act).setView(v)
                .setPositiveButton(R.string.action_ok, null).show();
    }
}
