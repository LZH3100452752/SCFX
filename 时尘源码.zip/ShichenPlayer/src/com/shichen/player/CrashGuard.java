package com.shichen.player;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Looper;

import java.io.PrintWriter;
import java.io.StringWriter;

/** 崩溃兜底：捕获未处理异常，避免直接闪退，并友好重启 */
public class CrashGuard implements Thread.UncaughtExceptionHandler {

    private static final String FILE = "crash.log";
    private Context ctx;
    private Thread.UncaughtExceptionHandler def;

    public static void install(Context c) {
        Thread.UncaughtExceptionHandler cur = Thread.getDefaultUncaughtExceptionHandler();
        if (cur instanceof CrashGuard) {
            return;
        }
        Thread.setDefaultUncaughtExceptionHandler(new CrashGuard(c, cur));
    }

    private CrashGuard(Context c, Thread.UncaughtExceptionHandler def) {
        ctx = c.getApplicationContext();
        this.def = def;
    }

    public void uncaughtException(Thread t, final Throwable e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        final String stack = sw.toString();
        // 同时写入诊断系统，便于统一导出
        try {
            Diagnostics.log("crash", "thread=" + t.getName());
            Diagnostics.err("crash", e);
            Diagnostics.export(ctx);
        } catch (Throwable ignored) {
        }
        try {
            java.io.File f = new java.io.File(ctx.getExternalFilesDir(null), FILE);
            java.io.FileOutputStream os = new java.io.FileOutputStream(f, true);
            os.write(("\n==== " + new java.util.Date() + " ====\n" + stack + "\n").getBytes("UTF-8"));
            os.close();
        } catch (Exception ignored) {
        }
        // 尝试友好重启到主界面，而不是直接闪退
        try {
            Intent i = new Intent(ctx, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent pi = PendingIntent.getActivity(ctx, 99, i, flags);
            android.app.AlarmManager am =
                    (android.app.AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                am.set(android.app.AlarmManager.RTC, System.currentTimeMillis() + 400, pi);
            }
        } catch (Exception ignored) {
        }
        try {
            if (def != null) {
                // 不调用默认处理器，避免系统"已停止运行"弹窗
            }
        } catch (Exception ignored) {
        }
        try {
            Thread.sleep(200);
        } catch (Exception ignored) {
        }
        android.os.Process.killProcess(android.os.Process.myPid());
    }

    @SuppressWarnings("unused")
    private static boolean onMain() {
        return Looper.getMainLooper() == Looper.myLooper();
    }
}
