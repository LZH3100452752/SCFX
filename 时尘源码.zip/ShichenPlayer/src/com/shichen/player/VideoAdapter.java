package com.shichen.player;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class VideoAdapter extends BaseAdapter {
    private Context ctx;
    private List<VideoItem> data;
    private boolean grid;
    private int accent, sub, text;
    private OnMoreListener more;

    public interface OnMoreListener {
        void onMore(VideoItem item);
    }

    public VideoAdapter(Context c, List<VideoItem> data, boolean grid, OnMoreListener more) {
        this.ctx = c;
        this.data = data;
        this.grid = grid;
        this.more = more;
        refreshColors();
    }

    private void refreshColors() {
        accent = ThemeEngine.accent(ctx);
        sub = ThemeEngine.sub(ctx);
        text = ThemeEngine.text(ctx);
    }

    public void setData(List<VideoItem> d, boolean g) {
        data = d;
        grid = g;
        refreshColors();
        notifyDataSetChanged();
    }

    public int getCount() {
        return data == null ? 0 : data.size();
    }

    public Object getItem(int i) {
        return data.get(i);
    }

    public long getItemId(int i) {
        return i;
    }

    public int getItemViewType(int position) {
        return grid ? 0 : 1;
    }

    public int getViewTypeCount() {
        return 2;
    }

    public View getView(final int position, View v, ViewGroup parent) {
        if (v == null) {
            v = LayoutInflater.from(ctx).inflate(
                    grid ? R.layout.item_video_grid : R.layout.item_video_list, parent, false);
        }
        VideoItem it = data.get(position);
        ImageView thumb = (ImageView) v.findViewById(R.id.thumb);
        TextView title = (TextView) v.findViewById(R.id.title);
        TextView subTv = (TextView) v.findViewById(R.id.sub);
        TextView dur = (TextView) v.findViewById(R.id.duration);
        View prog = v.findViewById(R.id.progress);
        ImageView play = (ImageView) v.findViewById(R.id.play);

        ThumbLoader.load(it, thumb);
        title.setText(it.title);
        title.setTextColor(text);
        if (play != null) {
            play.setColorFilter(Color.WHITE);
        }

        String info = MediaUtils.formatDuration(it.duration) + "  ·  " + MediaUtils.formatSize(it.size);
        if (subTv != null) {
            subTv.setText(info);
            subTv.setTextColor(sub);
        }
        if (dur != null) {
            dur.setText(MediaUtils.formatDuration(it.duration));
        }
        TextView res = (TextView) v.findViewById(R.id.resolution);
        if (res != null) {
            String r = it.resolution();
            if (r.length() == 0) {
                res.setVisibility(View.GONE);
            } else {
                res.setVisibility(View.VISIBLE);
                res.setText(r);
            }
        }
        TextView size = (TextView) v.findViewById(R.id.size);
        if (size != null) {
            size.setText(MediaUtils.formatSize(it.size));
            size.setTextColor(sub);
        }
        TextView fps = (TextView) v.findViewById(R.id.fps);
        if (fps != null) {
            fps.setVisibility(View.GONE);
        }
        ImageView fav = (ImageView) v.findViewById(R.id.fav);
        if (fav != null) {
            if (it.fav) {
                fav.setVisibility(View.VISIBLE);
                fav.setColorFilter(Color.parseColor("#FFFF5C8A"));
            } else {
                fav.setVisibility(View.GONE);
            }
        }
        if (prog != null) {
            if (it.position > 0 && it.duration > 0) {
                prog.setVisibility(View.VISIBLE);
                float p = (float) it.position / (float) it.duration;
                if (p > 1) {
                    p = 1;
                }
                setWidth(prog, p);
            } else {
                prog.setVisibility(View.GONE);
            }
        }
        View moreBtn = v.findViewById(R.id.more);
        if (moreBtn != null) {
            if (more == null) {
                moreBtn.setVisibility(View.INVISIBLE);
            } else {
                moreBtn.setVisibility(View.VISIBLE);
                moreBtn.setClickable(true);
                if (moreBtn instanceof ImageView) {
                    ((ImageView) moreBtn).setColorFilter(Color.WHITE);
                }
                moreBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v2) {
                        if (position >= 0 && position < data.size()) {
                            more.onMore(data.get(position));
                        }
                    }
                });
            }
        }
        return v;
    }

    private void setWidth(final View prog, final float f) {
        prog.post(new Runnable() {
            public void run() {
                View parent = (View) prog.getParent();
                int w = parent.getWidth();
                if (w <= 0) {
                    return;
                }
                ViewGroup.LayoutParams lp = prog.getLayoutParams();
                lp.width = (int) (w * f);
                prog.setLayoutParams(lp);
            }
        });
    }
}
