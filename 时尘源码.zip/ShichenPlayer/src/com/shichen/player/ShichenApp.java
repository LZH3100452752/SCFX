package com.shichen.player;

import android.app.Application;
import android.content.Context;

public class ShichenApp extends Application {
    private static Context ctx;

    public void onCreate() {
        super.onCreate();
        ctx = getApplicationContext();
        ThumbLoader.init(ctx);
        AudioFx.init(ctx);
        CrashGuard.install(ctx);
    }

    public static Context app() {
        return ctx;
    }
}
