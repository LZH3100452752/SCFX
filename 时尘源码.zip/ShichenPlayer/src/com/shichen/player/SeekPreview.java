package com.shichen.player;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 进度条拖动预览气泡：缩略图 + 大号时间 */
public class SeekPreview extends FrameLayout {
    private LinearLayout box;
    private ImageView img;
    private TextView time;
    private int boxW = 160;

    public SeekPreview(Context c) {
        super(c);
        init(c);
    }

    public SeekPreview(Context c, AttributeSet a) {
        super(c, a);
        init(c);
    }

    private void init(Context c) {
        float d = c.getResources().getDisplayMetrics().density;
        boxW = (int) (132 * d);
        setVisibility(GONE);
        box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundResource(R.drawable.bg_preview);
        box.setPadding((int) (5 * d), (int) (5 * d), (int) (5 * d), (int) (5 * d));
        img = new ImageView(c);
        int ih = (int) (74 * d);
        img.setLayoutParams(new LinearLayout.LayoutParams(boxW, ih));
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        time = new TextView(c);
        time.setTextColor(Color.WHITE);
        time.setTextSize(15);
        time.setGravity(Gravity.CENTER);
        time.setLayoutParams(new LinearLayout.LayoutParams(boxW, ViewGroup.LayoutParams.WRAP_CONTENT));
        time.setPadding(0, (int) (4 * d), 0, 0);
        box.addView(img);
        box.addView(time);
        addView(box, new FrameLayout.LayoutParams(boxW, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));
    }

    public void show(Bitmap bm, String text, int centerX, int parentW) {
        if (bm != null) {
            img.setImageBitmap(bm);
        }
        time.setText(text);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) box.getLayoutParams();
        lp.leftMargin = Math.max(0, Math.min(parentW - boxW, centerX - boxW / 2));
        lp.gravity = Gravity.BOTTOM | Gravity.LEFT;
        box.setLayoutParams(lp);
        setVisibility(VISIBLE);
    }

    public void hide() {
        setVisibility(GONE);
    }
}
