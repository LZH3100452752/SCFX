package com.shichen.player;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.List;

/** 文件夹模式下"目录 + 视频"混合列表适配器 */
public class DirVideoAdapter extends BaseAdapter {

    public static class DirEntry {
        public String path;
        public String name;
        public int count;     // 子树内视频总数
        public int direct;    // 本级直属数
        public long size;

        public DirEntry(String path) {
            this.path = path;
            this.name = new File(path).getName();
            if (name.length() == 0) {
                name = path;
            }
        }
    }

    private Context ctx;
    private List<Object> rows;
    private int text, sub, accent;

    public DirVideoAdapter(Context c, List<Object> rows) {
        ctx = c;
        this.rows = rows;
        refresh();
    }

    private void refresh() {
        text = ThemeEngine.text(ctx);
        sub = ThemeEngine.sub(ctx);
        accent = ThemeEngine.accent(ctx);
    }

    public void setData(List<Object> r) {
        rows = r;
        refresh();
        notifyDataSetChanged();
    }

    public int getCount() {
        return rows == null ? 0 : rows.size();
    }

    public Object getItem(int i) {
        return rows.get(i);
    }

    public long getItemId(int i) {
        return i;
    }

    public int getItemViewType(int position) {
        return rows.get(position) instanceof DirEntry ? 0 : 1;
    }

    public int getViewTypeCount() {
        return 2;
    }

    public View getView(int position, View v, ViewGroup parent) {
        Object o = rows.get(position);
        if (o instanceof DirEntry) {
            if (v == null || v.findViewById(R.id.count) == null) {
                v = LayoutInflater.from(ctx).inflate(R.layout.item_folder, parent, false);
            }
            DirEntry d = (DirEntry) o;
            TextView name = (TextView) v.findViewById(R.id.name);
            TextView subTv = (TextView) v.findViewById(R.id.sub);
            TextView count = (TextView) v.findViewById(R.id.count);
            name.setText(d.name);
            name.setTextColor(text);
            subTv.setText(d.direct > 0
                    ? d.path + "  ·  本级 " + d.direct + " 个"
                    : d.path);
            subTv.setTextColor(sub);
            count.setText(String.valueOf(d.count));
            count.setTextColor(accent);
            return v;
        }
        VideoItem it = (VideoItem) o;
        if (v == null || v.findViewById(R.id.title) == null
                || v.findViewById(R.id.duration) == null) {
            v = LayoutInflater.from(ctx).inflate(R.layout.item_history, parent, false);
        }
        ImageView thumb = (ImageView) v.findViewById(R.id.thumb);
        TextView title = (TextView) v.findViewById(R.id.title);
        TextView subTv = (TextView) v.findViewById(R.id.sub);
        TextView sizeTv = (TextView) v.findViewById(R.id.size);
        TextView dur = (TextView) v.findViewById(R.id.duration);
        View prog = v.findViewById(R.id.progress);

        ThumbLoader.load(it, thumb);
        title.setText(it.title);
        title.setTextColor(text);
        subTv.setText(MediaUtils.formatDuration(it.duration) + "  ·  "
                + MediaUtils.formatSize(it.size));
        subTv.setTextColor(sub);
        if (sizeTv != null) {
            sizeTv.setText(it.resolution().length() > 0 ? it.resolution() : it.ext().toUpperCase());
            sizeTv.setTextColor(sub);
        }
        if (dur != null) {
            dur.setText(MediaUtils.formatDuration(it.duration));
        }
        if (prog != null) {
            if (it.position > 0 && it.duration > 0) {
                prog.setVisibility(View.VISIBLE);
                float p = (float) it.position / (float) it.duration;
                if (p > 1) {
                    p = 1;
                }
                final float fp = p;
                prog.post(new Runnable() {
                    public void run() {
                        View par = (View) prog.getParent();
                        int w = par.getWidth();
                        if (w <= 0) {
                            return;
                        }
                        ViewGroup.LayoutParams lp = prog.getLayoutParams();
                        lp.width = (int) (w * fp);
                        prog.setLayoutParams(lp);
                    }
                });
            } else {
                prog.setVisibility(View.GONE);
            }
        }
        View moreBtn = v.findViewById(R.id.more);
        if (moreBtn != null) {
            moreBtn.setVisibility(View.GONE);
        }
        return v;
    }
}
