# 时尘播放器 · 源码包（UI 与界面部分）

本包只含**播放器自身的源码**（主界面、播放界面、各类设置面板与弹窗、图标资源、构建脚本）。
解码器核心 `com.hwdecoder` 与原生库 `libhwdecoder.so` 未包含（见下方"编译说明"）。

版本：v1.6.3　包名：`com.shichen.player`
源码规模：37 个 Java 文件，约 1.69 万行

---

## 一、目录结构

```
ShichenPlayer/
├── AndroidManifest.xml       应用清单（权限、Activity、主题）
├── build.py                  手工构建脚本：aapt2 → javac → d8 → zip → zipalign → apksigner
├── gen_icons.py              启动图标生成（渐变沙漏 + 播放三角 + 星尘）
├── gen_icons2.py             品牌图标生成
├── gen_icons3.py             ★ 应用内 95 个线性图标生成（8 倍超采样手绘矢量）
├── res/
│   ├── layout/               19 个竖屏布局
│   ├── layout-land/          横屏布局
│   ├── drawable*/            95 个手绘图标 × 5 档密度 + 形状/背景 XML
│   ├── mipmap*/              启动图标（含自适应图标前景/背景）
│   └── values/               颜色 / 主题 / 字符串
└── src/com/shichen/player/   播放器源码（37 个）
```

---

## 二、源码清单

| 文件 | 行数 | 分类 | 说明 |
|---|---|---|---|
| `PlayerActivity.java` | 3465 | 界面 | 播放界面主 Activity：控制条、手势、比例、字幕、悬浮窗、解码调度 |
| `SettingsPage.java` | 1491 | 设置页 | 主设置页：分类索引 → 分类详情页两级导航 + 搜索 |
| `PlayToolsPanel.java` | 1345 | 面板/弹窗 | 播放工具面板：可排序/可隐藏的功能图标网格 |
| `CodecEngine.java` | 1246 | 播放内核 | 自研解码内核 v2（MediaCodec），本项目早期自研内核 |
| `MainActivity.java` | 1041 | 界面 | 主界面：视频库 / 历史 / 设置三个页签，文件夹与视频模式切换 |
| `Ui.java` | 1006 | UI 基础库 | UI 基础库：半透明弹窗、面板、行、开关、滑杆、芯片等通用构件 |
| `PlaySettingsPanel.java` | 826 | 面板/弹窗 | 播放内设置面板：播放/声音/字幕/解码/界面/高级六组 |
| `Prefs.java` | 796 | 数据/工具 | 全部偏好设置的读写（主题、解码、手势、透明度等） |
| `FloatWindow.java` | 555 | 视图组件 | 悬浮窗小窗：按视频比例、可拖动、带进度条与播放控制 |
| `HwEngine.java` | 433 | 播放内核 | 时尘解码内核适配层（唯一 import com.hwdecoder 的文件） |
| `VideoRenderView.java` | 386 | 视图组件 | 视频渲染视图：矩阵变换实现比例与缩放，尺寸不变化 |
| `EqualizerPanel.java` | 308 | 面板/弹窗 | 均衡器弹窗：预设 + 频段滑杆，支持系统与内置双通道 |
| `PlaylistPanel.java` | 303 | 面板/弹窗 | 播放列表面板：封面、时长、清晰度、实时高亮当前项、上下移排序 |
| `SystemEngine.java` | 291 | 播放内核 | 系统内核：MediaPlayer 封装 |
| `MediaUtils.java` | 267 | 数据/工具 | 格式化、扫描、排序辅助 |
| `AudioFx.java` | 263 | 数据/工具 | 系统音效：Equalizer / BassBoost / Virtualizer |
| `VideoScanner.java` | 244 | 数据/工具 | 媒体库扫描与黑白名单过滤 |
| `DirPicker.java` | 210 | 数据/工具 | 目录选择器：逐级下钻 + 手动输入路径 |
| `SubtitleParser.java` | 198 | 数据/工具 | 字幕解析：SRT / VTT / ASS / SSA / LRC |
| `PlaybackService.java` | 194 | 数据/工具 | 后台播放服务 |
| `SlimSeekBar.java` | 189 | 视图组件 | 细长进度条：静止 2dp，按下加粗，带拖动预览 |
| `SortEngine.java` | 184 | 播放内核 | 排序引擎：12 个字段 × 升/降序 |
| `VideoAdapter.java` | 170 | 数据/工具 | 视频列表适配器（网格/列表两种布局） |
| `EqualizerActivity.java` | 162 | 界面 | 均衡器独立页（旧版保留） |
| `DbHelper.java` | 157 | 数据/工具 | 播放记录数据库：进度、收藏、历史 |
| `DirVideoAdapter.java` | 150 | 数据/工具 | 文件夹模式列表适配器 |
| `ThemeEngine.java` | 150 | 播放内核 | 主题引擎：深色/纯黑/浅色 × 12 种强调色 |
| `SubtitleView.java` | 135 | 视图组件 | 字幕渲染视图 |
| `HistoryAdapter.java` | 121 | 数据/工具 |  |
| `ThumbLoader.java` | 117 | 数据/工具 |  |
| `FlowLayout.java` | 90 | 数据/工具 |  |
| `CrashGuard.java` | 84 | 数据/工具 |  |
| `PlayerEngine.java` | 84 | 播放内核 | 播放内核接口定义 |
| `Diagnostics.java` | 81 | 数据/工具 | 诊断日志：写入文件并可导出报告 |
| `VideoItem.java` | 77 | 数据/工具 | 视频数据模型 |
| `SeekPreview.java` | 70 | 数据/工具 |  |
| `ShichenApp.java` | 20 | 数据/工具 |  |

---

## 三、播放器源码与解码器源码的边界

| 属于本包（播放器 UI） | 不属于本包（解码器核心） |
|---|---|
| 主界面 / 播放界面 / 设置页 | `com.hwdecoder.*`（40 个类） |
| 播放工具面板、播放设置面板 | `libhwdecoder.so`（OpenSL ES 原生音频引擎） |
| 排序面板、播放列表面板、均衡器面板 | |
| 悬浮窗小窗、渲染视图、图标资源 | |

**唯一跨越边界的文件**：`HwEngine.java`
它是播放器侧的**适配层**——把 `com.hwdecoder.HWDecoder` 接到本项目自己的
`PlayerEngine` 接口上，负责毫秒↔微秒换算、倍速映射、音量放大映射、错误过滤。
它本身不是解码器，但 `import com.hwdecoder.*`。

---

## 四、编译说明

直接编译会因缺少 `com.hwdecoder` 而报"找不到符号"，两种处理方式：

**方式 A（拿到完整可编译工程）**：把 `com.hwdecoder` 源码放回
`src/com/hwdecoder/`，并把 `libhwdecoder.so` 放回 `lib/<abi>/`，然后：

```bash
python3 build.py --proj . --out shichen.apk
```

**方式 B（只要 UI 部分浏览/参考）**：删除 `HwEngine.java`，并在
`PlayerActivity.java` 中把 `HwEngine` 的分支去掉（保留 `SystemEngine` 即可）。
这样是纯系统内核播放器，界面与功能照常，只是少了"时尘硬件解码"选项。

构建依赖：`aapt2`、`javac`（JDK 11+）、`d8`（build-tools 37）、`apksigner`。
脚本内 SDK 路径默认指向 `/data/workspace/sdk`，按你的实际环境调整。

---

## 五、重新生成图标

```bash
python3 gen_icons3.py     # 应用内图标 → res/drawable-*
python3 gen_icons.py      # 启动图标 → res/mipmap-*
```

需要 Pillow。图标全部由代码绘制：统一 2dp 线宽、圆头圆角、8 倍超采样后
LANCZOS 缩小，所以边缘平滑。想改某个图标，改 `ICONS` 字典里对应的绘制函数即可。
