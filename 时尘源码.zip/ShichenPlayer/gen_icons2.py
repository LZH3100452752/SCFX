#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""时尘播放器 v2 —— 精致图标生成器
风格：24dp 网格，2dp 统一线宽，圆头圆角，关键控件填充式
输出：drawable-* (白色线性图标) + mipmap-* (品牌图标)
"""
import os, math
from PIL import Image, ImageDraw

RES = "/data/workspace/shichen/res"
W = (255, 255, 255, 255)
SS = 4
DENS = {"mdpi": 1.0, "hdpi": 1.5, "xhdpi": 2.0, "xxhdpi": 3.0, "xxxhdpi": 4.0}


class P:
    """画笔：所有坐标以 dp 为单位（基于 24dp 网格）"""

    def __init__(self, d, px):
        self.d = d
        self.px = px
        self.w = 2.0 * px

    def P(self, x, y):
        return (x * self.px, y * self.px)

    def _cap(self, x, y, r):
        self.d.ellipse([x - r, y - r, x + r, y + r], fill=W)

    def line(self, x1, y1, x2, y2, w=None):
        w = self.w if w is None else w * self.px
        a, b = self.P(x1, y1), self.P(x2, y2)
        self.d.line([a, b], fill=W, width=int(round(w)))
        r = w / 2.0
        self._cap(a[0], a[1], r)
        self._cap(b[0], b[1], r)

    def poly(self, pts, close=False, w=None):
        w = self.w if w is None else w * self.px
        p = [self.P(*q) for q in pts]
        if close:
            p.append(p[0])
        self.d.line(p, fill=W, width=int(round(w)))
        r = w / 2.0
        for q in p:
            self._cap(q[0], q[1], r)

    def rect(self, x1, y1, x2, y2, r=2.5, w=None):
        w = self.w if w is None else w * self.px
        self.d.rounded_rectangle([x1 * self.px, y1 * self.px, x2 * self.px, y2 * self.px],
                                 radius=r * self.px, outline=W, width=int(round(w)))

    def frect(self, x1, y1, x2, y2, r=1.5):
        self.d.rounded_rectangle([x1 * self.px, y1 * self.px, x2 * self.px, y2 * self.px],
                                 radius=r * self.px, fill=W)

    def circle(self, cx, cy, r, w=None):
        w = self.w if w is None else w * self.px
        c, R = self.P(cx, cy), r * self.px
        self.d.ellipse([c[0] - R, c[1] - R, c[0] + R, c[1] + R],
                       outline=W, width=int(round(w)))

    def fcircle(self, cx, cy, r):
        c, R = self.P(cx, cy), r * self.px
        self.d.ellipse([c[0] - R, c[1] - R, c[0] + R, c[1] + R], fill=W)

    def arc(self, cx, cy, r, a0, a1, w=None):
        w = self.w if w is None else w * self.px
        c, R = self.P(cx, cy), r * self.px
        self.d.arc([c[0] - R, c[1] - R, c[0] + R, c[1] + R], a0, a1,
                   fill=W, width=int(round(w)))

    def fill(self, pts):
        self.d.polygon([self.P(*q) for q in pts], fill=W)

    def dot(self, cx, cy, r=1.5):
        self.fcircle(cx, cy, r)


def ring(cx, cy, r, a0, a1, step=5):
    out = []
    a = a0
    while a <= a1:
        out.append((cx + r * math.cos(math.radians(a)), cy + r * math.sin(math.radians(a))))
        a += step
    return out


# ================================================== 图标库
def i_library(p):
    p.rect(2.5, 4, 21.5, 20, r=3)
    p.fill([(9.5, 8.5), (16, 12), (9.5, 15.5)])


def i_folder(p):
    p.poly([(2.5, 6), (8.5, 6), (10.8, 8.6), (21.5, 8.6), (21.5, 19.5), (2.5, 19.5)], close=True)


def i_folder_open(p):
    p.poly([(2.5, 6), (8.5, 6), (10.8, 8.6), (21.5, 8.6), (21.5, 20), (2.5, 20)], close=True)
    p.line(2.5, 12.5, 21.5, 12.5, w=1.6)


def i_history(p):
    p.arc(12, 12.5, 8, 40, 330)
    p.line(12, 12.5, 12, 7)
    p.line(12, 12.5, 15.8, 10.5)


def i_settings(p):
    p.fcircle(12, 12, 2.6)
    p.arc(12, 12, 7.4, 0, 360, w=1.7)
    for k in range(6):
        a = math.radians(k * 60 + 30)
        p.line(12 + 3.9 * math.cos(a), 12 + 3.9 * math.sin(a),
               12 + 7.4 * math.cos(a), 12 + 7.4 * math.sin(a), w=1.7)


def i_search(p):
    p.circle(10.6, 10.6, 6.8)
    p.line(15.5, 15.5, 20.5, 20.5)


def i_sort(p):
    p.line(3.5, 6.5, 14, 6.5)
    p.line(3.5, 12, 11, 12)
    p.line(3.5, 17.5, 8, 17.5)
    p.line(20.5, 6.5, 20.5, 18.5)
    p.fill([(17.5, 9.5), (20.5, 6), (23, 9.5)])


def i_grid(p):
    for x, y in ((3, 3), (13.2, 3), (3, 13.2), (13.2, 13.2)):
        p.frect(x, y, x + 7.8, y + 7.8, r=2.2)


def i_list(p):
    for y in (4, 10.2, 16.4):
        p.frect(3, y, 7.5, y + 5.4, r=1.8)
        p.line(10, y + 2.7, 21, y + 2.7)


def i_refresh(p):
    p.arc(12, 12, 8, 45, 315)
    p.fill([(20.6, 2.4), (21.6, 9.2), (14.8, 7)])


def i_back(p):
    p.line(20.5, 12, 5, 12)
    p.poly([(11.5, 6), (5, 12), (11.5, 18)])


def i_close(p):
    p.line(5.5, 5.5, 18.5, 18.5)
    p.line(18.5, 5.5, 5.5, 18.5)


def i_check(p):
    p.poly([(4, 12.5), (9.5, 18), (20, 6.5)])


def i_more_v(p):
    p.fcircle(12, 5.2, 1.9)
    p.fcircle(12, 12, 1.9)
    p.fcircle(12, 18.8, 1.9)


def i_more_h(p):
    p.fcircle(5.2, 12, 1.9)
    p.fcircle(12, 12, 1.9)
    p.fcircle(18.8, 12, 1.9)


def i_add(p):
    p.line(12, 4.5, 12, 19.5)
    p.line(4.5, 12, 19.5, 12)


def i_delete(p):
    p.poly([(5, 7), (5, 20.5), (19, 20.5), (19, 7)], close=True)
    p.line(3, 7, 21, 7)
    p.line(9.2, 4, 9.2, 7)
    p.line(14.8, 4, 14.8, 7)
    p.line(9, 11, 9, 17, w=1.6)
    p.line(15, 11, 15, 17, w=1.6)


def i_fav(p):
    p.poly([(12, 20.4), (3.6, 12), (3.6, 8), (6.4, 5.2), (9.6, 5.2),
            (12, 8.2), (14.4, 5.2), (17.6, 5.2), (20.4, 8), (20.4, 12)], close=True)


def i_fav_fill(p):
    p.fill([(12, 20.4), (3.6, 12), (3.6, 8), (6.4, 5.2), (9.6, 5.2),
            (12, 8.2), (14.4, 5.2), (17.6, 5.2), (20.4, 8), (20.4, 12)])


def i_info(p):
    p.circle(12, 12, 8.6)
    p.line(12, 11.2, 12, 17)
    p.dot(12, 7.6, 1.3)


def i_shuffle(p):
    p.poly([(3, 6.5), (13, 6.5), (17.4, 10.6)])
    p.poly([(13, 10.2), (17.4, 10.6), (16.8, 14.6)])
    p.poly([(21, 17.5), (11, 17.5), (6.6, 13.4)])
    p.poly([(11, 13.8), (6.6, 13.4), (7.2, 9.4)])


def i_repeat(p):
    p.arc(12, 12, 8, 55, 305)
    p.fill([(20.4, 8), (21, 13.6), (15.4, 11.4)])


def i_repeat_one(p):
    p.arc(12, 12, 8, 55, 305)
    p.fill([(20.4, 8), (21, 13.6), (15.4, 11.4)])
    p.line(10.4, 10, 13.6, 10, w=1.6)
    p.line(10.4, 10, 10.4, 14.6, w=1.6)
    p.line(10.4, 14.6, 13.6, 14.6, w=1.6)


def i_play(p):
    p.fill([(7.5, 4.5), (19.5, 12), (7.5, 19.5)])


def i_pause(p):
    p.frect(7, 4.5, 10.6, 19.5, r=1.4)
    p.frect(13.4, 4.5, 17, 19.5, r=1.4)


def i_prev(p):
    p.frect(18.6, 5, 21, 19, r=1)
    p.fill([(16.5, 5), (16.5, 19), (5, 12)])


def i_next(p):
    p.frect(3, 5, 5.4, 19, r=1)
    p.fill([(7.5, 5), (7.5, 19), (19, 12)])


def i_rew(p):
    p.fill([(11.5, 5.5), (11.5, 18.5), (3.5, 12)])
    p.fill([(20.5, 5.5), (20.5, 18.5), (12.5, 12)])


def i_ff(p):
    p.fill([(3.5, 5.5), (3.5, 18.5), (11.5, 12)])
    p.fill([(12.5, 5.5), (12.5, 18.5), (20.5, 12)])


def i_lock(p):
    p.rect(4.8, 10.4, 19.2, 20.4, r=3)
    p.arc(12, 10.4, 4.6, 180, 360)
    p.line(8.4, 15.2, 15.6, 15.2, w=1.7)


def i_unlock(p):
    p.rect(4.8, 10.4, 19.2, 20.4, r=3)
    p.arc(12, 10.4, 4.6, 205, 335)
    p.line(8.4, 15.2, 15.6, 15.2, w=1.7)


def i_speed(p):
    p.fill([(3.5, 4.5), (11.6, 12), (3.5, 19.5)])
    p.fill([(12.4, 4.5), (20.5, 12), (12.4, 19.5)])


def i_subtitle(p):
    p.rect(2.5, 4.5, 21.5, 19.5, r=3)
    p.line(6, 9.5, 11.5, 9.5, w=1.7)
    p.line(13.5, 9.5, 18, 9.5, w=1.7)
    p.line(6, 14.5, 15, 14.5, w=1.7)


def i_audio(p):
    p.line(8.5, 17.5, 8.5, 5.5)
    p.line(8.5, 5.5, 18, 8.4)
    p.fcircle(6.4, 17.8, 2.7)
    p.fcircle(16, 15.8, 2.7)


def i_track(p):
    p.line(5, 10, 5, 14)
    p.line(9.6, 6, 9.6, 18)
    p.line(14.2, 8, 14.2, 16)
    p.line(18.8, 10.5, 18.8, 13.5)


def i_ratio(p):
    p.rect(2.5, 5, 21.5, 19, r=2.6)
    p.rect(6.5, 8, 17.5, 16, r=1.4, w=1.6)


def i_screenshot(p):
    p.rect(2.6, 6, 21.4, 20.4, r=3)
    p.poly([(9, 6), (12, 3), (15, 6)])
    p.fcircle(12, 13.2, 3.6)
    p.arc(12, 13.2, 3.6, 0, 360, w=1.6)


def i_pip(p):
    p.rect(2.5, 4.5, 21.5, 19.5, r=3)
    p.frect(12, 12, 20, 18.5, r=1.6)


def i_sleep(p):
    outer = ring(12.4, 12.6, 8.6, 60, 300, 5)
    inner = [(16.6 + 7.5 * math.cos(math.radians(a)), 10.4 + 7.5 * math.sin(math.radians(a)))
             for a in [300 + k * (420 / 42.0) for k in range(43)]]
    p.fill(outer + list(reversed(inner)))
    p.dot(19.8, 5.2, 1.2)
    p.dot(6.2, 18.8, 1.0)


def i_brightness(p):
    p.fcircle(12, 12, 4.2)
    for k in range(8):
        a = math.radians(k * 45)
        p.line(12 + 6.6 * math.cos(a), 12 + 6.6 * math.sin(a),
               12 + 9.4 * math.cos(a), 12 + 9.4 * math.sin(a))


def i_volume(p):
    p.fill([(3, 9.2), (7, 9.2), (11.8, 4.6), (11.8, 19.4), (7, 14.8), (3, 14.8)])
    p.arc(11.8, 12, 5.2, -52, 52)
    p.arc(11.8, 12, 8.4, -55, 55)


def i_mute(p):
    p.fill([(3, 9.2), (7, 9.2), (11.8, 4.6), (11.8, 19.4), (7, 14.8), (3, 14.8)])
    p.line(15.4, 9.4, 20.6, 14.6)
    p.line(20.6, 9.4, 15.4, 14.6)


def i_fullscreen(p):
    p.poly([(3, 9.5), (3, 3), (9.5, 3)])
    p.poly([(14.5, 3), (21, 3), (21, 9.5)])
    p.poly([(21, 14.5), (21, 21), (14.5, 21)])
    p.poly([(9.5, 21), (3, 21), (3, 14.5)])


def i_fullscreen_exit(p):
    p.poly([(9.5, 3), (3, 3), (3, 9.5)])
    p.poly([(21, 9.5), (21, 3), (14.5, 3)])
    p.poly([(14.5, 21), (21, 21), (21, 14.5)])
    p.poly([(3, 14.5), (3, 21), (9.5, 21)])


def i_equalizer(p):
    for x, y in ((5.6, 8.4), (12, 14.8), (18.4, 6.8)):
        p.line(x, 4, x, 20, w=1.7)
        p.fcircle(x, y, 2.1)


def i_url(p):
    p.circle(12, 12, 8.6)
    p.line(3.4, 12, 20.6, 12)
    c, R = p.P(12, 12), 8.6 * p.px
    p.d.ellipse([c[0] - 4.2 * p.px, c[1] - R, c[0] + 4.2 * p.px, c[1] + R],
                outline=W, width=int(round(p.w)))


def i_timer(p):
    p.circle(12, 13.2, 8)
    p.line(12, 13.2, 12, 8.2)
    p.line(12, 13.2, 15.6, 15.2)
    p.line(9, 3, 15, 3)
    p.line(12, 3, 12, 5.2)


def i_ab(p):
    p.arc(12, 12, 8.6, 45, 315)
    p.poly([(6.4, 16.6), (9, 9.4), (11.6, 16.6)])
    p.line(7.4, 14, 10.2, 14, w=1.5)
    p.line(14, 9.4, 14, 16.6)
    p.arc(14, 12.6, 3.5, -90, 90, w=1.7)
    p.arc(14, 12.6, 1.7, -90, 90, w=1.7)


def i_whitelist(p):
    p.poly([(2.5, 6), (8.5, 6), (10.8, 8.6), (21.5, 8.6), (21.5, 19.5), (2.5, 19.5)], close=True)
    p.poly([(7.5, 14.5), (11, 18), (17, 11)])


def i_blacklist(p):
    p.poly([(2.5, 6), (8.5, 6), (10.8, 8.6), (21.5, 8.6), (21.5, 19.5), (2.5, 19.5)], close=True)
    p.line(9, 12.5, 15, 18)
    p.line(15, 12.5, 9, 18)


def i_theme(p):
    p.circle(12, 12, 8.6)
    p.dot(9, 9)
    p.dot(15, 9.6)
    p.dot(10.5, 15.5)
    p.dot(15.5, 15)


def i_decode(p):
    p.rect(6.5, 6.5, 17.5, 17.5, r=2)
    p.rect(9.8, 9.8, 14.2, 14.2, r=1.2, w=1.5)
    for k in range(3):
        y = 9.5 + k * 3.2
        p.line(2.6, y, 6.5, y, w=1.3)
        p.line(17.5, y, 21.4, y, w=1.3)
        p.line(y, 2.6, y, 6.5, w=1.3)
        p.line(y, 17.5, y, 21.4, w=1.3)


def i_storage(p):
    p.poly([(6, 3), (16, 3), (19.5, 6.5), (19.5, 21), (4.5, 21), (4.5, 6)], close=True)
    p.line(8, 10, 16, 10)
    p.line(8, 14, 13, 14)


def i_sparkle(p):
    p.fill([(12, 2.5), (13.8, 9.4), (20.5, 11), (13.8, 12.8), (12, 20),
            (10.2, 12.8), (3.5, 11), (10.2, 9.4)])
    p.dot(19, 4.5, 1.3)
    p.dot(5, 18.5, 1.0)


def i_scan(p):
    p.poly([(3, 8.5), (3, 3.5), (8, 3.5)])
    p.poly([(16, 3.5), (21, 3.5), (21, 8.5)])
    p.poly([(21, 15.5), (21, 20.5), (16, 20.5)])
    p.poly([(8, 20.5), (3, 20.5), (3, 15.5)])
    p.line(6, 12, 18, 12)


def i_video_file(p):
    p.poly([(4, 3.5), (13, 3.5), (16, 6.5), (20, 6.5), (20, 20.5), (4, 20.5)], close=True)
    p.fill([(9.5, 11), (15.5, 14.2), (9.5, 17.5)])


def i_eye(p):
    up = [(12 + 9.2 * math.cos(math.radians(a)), 12 + 5.6 * math.sin(math.radians(a)))
          for a in range(0, 181, 8)]
    dn = [(12 + 9.2 * math.cos(math.radians(a)), 12 - 5.6 * math.sin(math.radians(a)))
          for a in range(180, -1, -8)]
    p.poly(up + dn, w=1.8)
    p.circle(12, 12, 3.2)


def i_rotate(p):
    p.arc(12, 12, 8.4, 30, 300)
    p.fill([(19.8, 6.2), (21.6, 11.8), (16, 10.4)])
    p.dot(12, 12, 1.7)


def i_playlist(p):
    p.line(8.5, 6.5, 20, 6.5)
    p.line(8.5, 12, 20, 12)
    p.line(8.5, 17.5, 20, 17.5)
    p.fill([(3.5, 4.8), (7.2, 6.9), (3.5, 9)])
    p.dot(4, 12, 1.2)
    p.dot(4, 17.5, 1.2)


def i_arrow_up(p):
    p.line(12, 20, 12, 5)
    p.poly([(6.5, 10.5), (12, 4.8), (17.5, 10.5)])


def i_minus(p):
    p.line(5, 12, 19, 12)


def i_fw(p):
    p.arc(12, 12, 7.6, 60, 300)
    p.fill([(10.5, 6.5), (10.5, 17.5), (4, 12)])


def i_arrow_down(p):
    p.line(12, 4, 12, 19)
    p.poly([(6.5, 13.5), (12, 19.2), (17.5, 13.5)])


def i_chevron_right(p):
    p.poly([(9.5, 5), (16.5, 12), (9.5, 19)])


def i_chevron_left(p):
    p.poly([(14.5, 5), (7.5, 12), (14.5, 19)])


def i_chevron_up(p):
    p.poly([(5, 14.5), (12, 7.5), (19, 14.5)])


def i_chevron_down(p):
    p.poly([(5, 9.5), (12, 16.5), (19, 9.5)])


def i_crop(p):
    p.line(3, 21, 15.5, 21)
    p.line(21, 21, 21, 8.5)
    p.line(3, 8.5, 3, 21, w=0)
    p.poly([(3, 8.5), (15.5, 8.5), (15.5, 21)], close=False, w=1.7)
    p.line(15.5, 8.5, 21, 3)


def i_zoom(p):
    p.circle(10.6, 10.6, 6.8)
    p.line(15.5, 15.5, 20.5, 20.5)
    p.line(8, 10.6, 13.2, 10.6, w=1.7)
    p.line(10.6, 8, 10.6, 13.2, w=1.7)


def i_gesture(p):
    p.fcircle(12, 8, 2.4)
    p.arc(8.4, 13.6, 3.4, 90, 250, w=1.7)
    p.arc(15.6, 13.6, 3.4, -70, 90, w=1.7)
    p.line(12, 11, 12, 16, w=1.7)


def i_screen_rotate(p):
    p.rect(3, 7, 15, 17, r=2.2)
    p.arc(18, 12, 4.2, -90, 90)
    p.fill([(18, 5.6), (18, 10), (22, 8.6)])


def i_screen_lock(p):
    p.rect(2.5, 5, 21.5, 15, r=2.4)
    p.line(9, 20, 15, 20)
    p.fcircle(12, 12.5, 2.2)


def i_network(p):
    p.arc(12, 17, 3.2, 180, 360)
    p.arc(12, 17, 6.4, 180, 360)
    p.arc(12, 17, 9.4, 180, 360)
    p.dot(12, 9.5, 1.8)


def i_folder_add(p):
    p.poly([(2.5, 6), (8.5, 6), (10.8, 8.6), (21.5, 8.6), (21.5, 19.5), (2.5, 19.5)], close=True)
    p.line(10, 12.5, 10, 17)
    p.line(7.8, 14.7, 12.2, 14.7)


def i_stats(p):
    p.frect(4, 13, 8, 20, r=1.2)
    p.frect(10.5, 8, 14.5, 20, r=1.2)
    p.frect(17, 4, 21, 20, r=1.2)


def i_shield(p):
    p.fill([(12, 3), (20.5, 6.2), (20.5, 12.4), (20.5, 17), (12, 21), (3.5, 17),
            (3.5, 12.4), (3.5, 6.2)])
    p.poly([(12, 3), (20.5, 6.2), (20.5, 12.4), (20.5, 17), (12, 21), (3.5, 17),
            (3.5, 12.4), (3.5, 6.2)], close=True)


def i_bug(p):
    p.rect(8, 8, 16, 19, r=4)
    p.line(8, 12.5, 5, 12.5)
    p.line(16, 12.5, 19, 12.5)
    p.line(8, 16, 4.6, 18)
    p.line(16, 16, 19.4, 18)
    p.arc(12, 7, 3.4, 180, 360)


def i_help(p):
    p.circle(12, 12, 8.6)
    p.arc(9.2, 9.6, 2.6, 200, 40, w=1.7)
    p.dot(13.6, 8.2, 1.2)


ICONS = {
    "ic_library": i_library, "ic_folder": i_folder, "ic_folder_open": i_folder_open,
    "ic_history": i_history, "ic_settings": i_settings, "ic_search": i_search,
    "ic_sort": i_sort, "ic_grid": i_grid, "ic_list": i_list, "ic_refresh": i_refresh,
    "ic_back": i_back, "ic_close": i_close, "ic_check": i_check, "ic_more": i_more_v,
    "ic_more_h": i_more_h, "ic_add": i_add, "ic_delete": i_delete, "ic_fav": i_fav,
    "ic_fav_filled": i_fav_fill, "ic_info": i_info, "ic_shuffle": i_shuffle,
    "ic_repeat": i_repeat, "ic_repeat_one": i_repeat_one, "ic_play": i_play,
    "ic_pause": i_pause, "ic_prev": i_prev, "ic_next": i_next, "ic_rew": i_rew,
    "ic_ff": i_ff, "ic_lock": i_lock, "ic_unlock": i_unlock, "ic_speed": i_speed,
    "ic_subtitle": i_subtitle, "ic_audio": i_audio, "ic_track": i_track,
    "ic_ratio": i_ratio, "ic_screenshot": i_screenshot, "ic_pip": i_pip,
    "ic_sleep": i_sleep, "ic_brightness": i_brightness, "ic_volume": i_volume,
    "ic_mute": i_mute, "ic_fullscreen": i_fullscreen, "ic_fullscreen_exit": i_fullscreen_exit,
    "ic_equalizer": i_equalizer, "ic_url": i_url, "ic_timer": i_timer, "ic_ab": i_ab,
    "ic_whitelist": i_whitelist, "ic_blacklist": i_blacklist, "ic_theme": i_theme,
    "ic_decode": i_decode, "ic_storage": i_storage, "ic_sparkle": i_sparkle,
    "ic_scan": i_scan, "ic_video_file": i_video_file, "ic_eye": i_eye,
    "ic_rotate": i_rotate, "ic_playlist": i_playlist, "ic_arrow_up": i_arrow_up,
    "ic_minus": i_minus, "ic_fw": i_fw, "ic_arrow_down": i_arrow_down,
    "ic_chevron_right": i_chevron_right, "ic_chevron_left": i_chevron_left,
    "ic_chevron_up": i_chevron_up, "ic_chevron_down": i_chevron_down,
    "ic_crop": i_crop, "ic_zoom": i_zoom, "ic_gesture": i_gesture,
    "ic_screen_rotate": i_screen_rotate, "ic_screen_lock": i_screen_lock,
    "ic_network": i_network, "ic_folder_add": i_folder_add, "ic_stats": i_stats,
    "ic_shield": i_shield, "ic_bug": i_bug, "ic_help": i_help,
}


def make(fn, size):
    S = size * SS
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    fn(P(ImageDraw.Draw(img), S / 24.0))
    return img.resize((size, size), Image.LANCZOS)


def build_icons():
    for name, fn in ICONS.items():
        for dens, mult in DENS.items():
            d = os.path.join(RES, "drawable-" + dens)
            os.makedirs(d, exist_ok=True)
            make(fn, int(round(24 * mult))).save(os.path.join(d, name + ".png"))
    print("icons:", len(ICONS))


# ================================================== 品牌图标
def build_launcher():
    for dens, mult in DENS.items():
        mip = os.path.join(RES, "mipmap-" + dens)
        os.makedirs(mip, exist_ok=True)
        F = int(round(108 * mult)) * SS          # foreground 画布
        cx = cy = F / 2.0
        U = F / 108.0

        def u(v):
            return v * U

        # ---------- 渐变沙漏 ----------
        grad = Image.new("RGBA", (F, F), (0, 0, 0, 0))
        gd = ImageDraw.Draw(grad)
        top, bot = (168, 130, 255), (58, 226, 214)
        y0, y1 = int(cy - u(31)), int(cy + u(31))
        for y in range(y0, y1):
            t = (y - y0) / float(max(1, y1 - y0))
            gd.line([(0, y), (F, y)],
                    fill=tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(3)) + (255,))
        w, neck = u(27), u(5.6)
        glass = [(cx - w, cy - u(31)), (cx + w, cy - u(31)), (cx + neck, cy),
                 (cx + w, cy + u(31)), (cx - w, cy + u(31)), (cx - neck, cy)]
        mask = Image.new("L", (F, F), 0)
        ImageDraw.Draw(mask).polygon(glass, fill=255)
        grad.putalpha(mask)
        fg = Image.new("RGBA", (F, F), (0, 0, 0, 0))
        fg = Image.alpha_composite(fg, grad)
        d = ImageDraw.Draw(fg)
        d.line(glass + [glass[0]], fill=(255, 255, 255, 235), width=int(round(u(2.6))))
        d.rounded_rectangle([cx - w - u(4), cy - u(35.5), cx + w + u(4), cy - u(29.5)],
                            radius=u(3.2), fill=(255, 255, 255, 245))
        d.rounded_rectangle([cx - w - u(4), cy + u(29.5), cx + w + u(4), cy + u(35.5)],
                            radius=u(3.2), fill=(255, 255, 255, 245))
        d.polygon([(cx - u(6.5), cy - u(9.5)), (cx + u(10.5), cy), (cx - u(6.5), cy + u(9.5))],
                  fill=(255, 255, 255, 255))
        for sx, sy, sr in ((u(20), u(24), u(2.8)), (u(86), u(28), u(2.2)),
                           (u(82), u(80), u(2.8)), (u(24), u(82), u(2.0)), (u(54), u(13), u(1.7))):
            d.ellipse([sx - sr, sy - sr, sx + sr, sy + sr], fill=(255, 255, 255, 225))
        fg.resize((int(F / SS), int(F / SS)), Image.LANCZOS).save(
            os.path.join(mip, "ic_launcher_foreground.png"))

        # ---------- 方形图标 ----------
        L = int(round(48 * mult)) * SS
        base = Image.new("RGBA", (L, L), (0, 0, 0, 0))
        bd = ImageDraw.Draw(base)
        rad = L * 0.235
        bd.rounded_rectangle([0, 0, L - 1, L - 1], radius=rad, fill=(22, 20, 34, 255))
        g2 = Image.new("RGBA", (L, L), (0, 0, 0, 0))
        g2d = ImageDraw.Draw(g2)
        for y in range(L):
            t = y / float(L)
            g2d.line([(0, y), (L, y)],
                     fill=(int(38 + 34 * t), int(28 + 22 * t), int(78 + 96 * t), 255))
        m2 = Image.new("L", (L, L), 0)
        ImageDraw.Draw(m2).rounded_rectangle([0, 0, L - 1, L - 1], radius=rad, fill=255)
        g2.putalpha(m2)
        base = Image.alpha_composite(base, g2)
        inner = fg.resize((int(L * 0.76), int(L * 0.76)), Image.LANCZOS)
        base.alpha_composite(inner, ((L - inner.size[0]) // 2, (L - inner.size[1]) // 2))
        base.resize((int(L / SS), int(L / SS)), Image.LANCZOS).save(
            os.path.join(mip, "ic_launcher.png"))
    print("launcher ok")


if __name__ == "__main__":
    build_icons()
    build_launcher()
