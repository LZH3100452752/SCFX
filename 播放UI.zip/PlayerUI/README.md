# 时尘播放器 · 播放界面 UI 源码包

只含**播放视频界面**及其直接相关的 UI 代码与资源。
主界面（视频库/历史/设置页）、文件夹浏览等界面源码不在本包内。

版本：v1.6.3

---

## 一、目录结构

```
PlayerUI/
├── AndroidManifest.xml          应用清单（含播放 Activity 声明与权限）
├── build.py                     构建脚本（已改为以自身目录为工程根）
├── gen_icons3.py                ★ 应用内图标生成脚本（8 倍超采样手绘矢量）
├── res/
│   ├── layout/
│   │   ├── activity_player.xml  ★ 竖屏播放界面（顶栏 / 渲染容器 / 状态 / 底栏）
│   │   ├── dialog_panel.xml     面板弹窗容器（透明底 + 圆角 + 限高）
│   │   ├── dialog_compact.xml   紧凑面板（倍速等，限宽不占半屏）
│   │   ├── dialog_input.xml     输入弹窗
│   │   ├── dialog_list.xml      列表面板
│   │   └── dialog_info.xml      信息面板
│   ├── layout-land/
│   │   └── activity_player.xml  ★ 横屏播放界面（工具面板贴右侧）
│   ├── drawable/                形状 / 背景 / 进度条 XML
│   ├── drawable-*/              播放界面用到的图标 × 5 档密度
│   └── values/                  colors / strings / themes
└── src/com/shichen/player/      27 个 Java 文件
```

---

## 二、源码清单

| 文件 | 行数 | 分类 | 说明 |
|---|---|---|---|
| `PlayerActivity.java` | 3465 | ★ 界面核心 | ★ 播放界面主控：控制条、手势、比例、字幕、悬浮窗、解码调度、生命周期 |
| `PlayToolsPanel.java` | 1345 | ★ 界面核心 | ★ 播放工具面板：功能图标网格，可长按排序、可隐藏、右上编辑 |
| `Ui.java` | 1006 | ★ 界面核心 | ★ UI 构件库：半透明弹窗、面板、行、开关、滑杆、chip 全部由此生成 |
| `PlaySettingsPanel.java` | 826 | ★ 界面核心 | ★ 播放内设置：播放/声音/字幕/解码/界面/高级六组，顶部有分类导航 |
| `FloatWindow.java` | 555 | ★ 界面核心 | ★ 悬浮窗小窗：按视频原始比例、可拖动、带进度条与播放/暂停 |
| `VideoRenderView.java` | 386 | ★ 界面核心 | ★ 渲染视图：矩阵变换实现 8 种比例与缩放，尺寸恒定不重建 surface |
| `EqualizerPanel.java` | 308 | ★ 界面核心 | 均衡器弹窗：10 种预设 + 频段滑杆（系统音效 / 内置 EQ 双通道） |
| `PlaylistPanel.java` | 303 | ★ 界面核心 | ★ 播放列表面板：封面 + 时长 + 清晰度，实时高亮当前项，上下移排序 |
| `SlimSeekBar.java` | 189 | ★ 界面核心 | ★ 细长进度条：静止 2dp / 按下加粗，拖动带缩略图预览气泡 |
| `ThemeEngine.java` | 150 | ★ 界面核心 | 主题引擎：深色 / 纯黑 AMOLED / 浅色 × 12 种强调色 |
| `SubtitleView.java` | 135 | ★ 界面核心 | 字幕渲染视图（描边、字号、位置、延迟） |
| `Prefs.java` | 796 | 支撑/数据 | 全部偏好读写：主题、解码、手势、透明度、音量放大等 |
| `SystemEngine.java` | 291 | 支撑/数据 | 系统内核：MediaPlayer 封装（默认内核） |
| `MediaUtils.java` | 267 | 支撑/数据 | 时间/大小格式化、扫描与排序辅助 |
| `AudioFx.java` | 263 | 支撑/数据 | 系统音效：Equalizer / BassBoost / Virtualizer |
| `VideoScanner.java` | 244 | 支撑/数据 | 媒体库扫描与黑白名单过滤 |
| `SubtitleParser.java` | 198 | 支撑/数据 | 字幕解析：SRT / VTT / ASS / SSA / LRC |
| `PlaybackService.java` | 194 | 支撑/数据 | 后台播放服务 |
| `SortEngine.java` | 184 | 支撑/数据 | 排序引擎：12 字段 × 升降序 |
| `DbHelper.java` | 157 | 支撑/数据 | 播放记录数据库：进度、收藏、历史 |
| `ThumbLoader.java` | 117 | 支撑/数据 | 缩略图异步加载 |
| `FlowLayout.java` | 90 | 支撑/数据 | 芯片流式布局（倍速档位、排序字段用） |
| `PlayerEngine.java` | 84 | 支撑/数据 | 播放内核接口定义（毫秒制），所有内核都实现它 |
| `Diagnostics.java` | 81 | 支撑/数据 | 诊断日志：写入文件并可导出报告 |
| `VideoItem.java` | 77 | 支撑/数据 | 视频数据模型 |
| `CodecEngine.java` | 1246 | 解码相关·可选 | 自研内核 v2（MediaCodec）—— 属于解码部分，可选 |
| `HwEngine.java` | 433 | 解码相关·可选 | 时尘内核适配层 —— 依赖 com.hwdecoder，可选 |

---

## 三、播放界面的 UI 结构（竖屏）

```
activity_player.xml
├── 顶栏          返回 / 标题 / 收藏 / 旋转 / 设置齿轮
│   └── 状态胶囊  左侧视频时长 · 右侧电量+时间（可调位置、刘海补偿）
├── 渲染容器      恒定全屏，比例与缩放全部由矩阵实现
│   ├── 字幕视图
│   ├── 锁定按钮（透明底，锁定后点屏才浮现）
│   └── 重播按钮（半透明底 + 蓝色字，5 秒后消失）
└── 底栏
    ├── 进度条行  当前时间 · 细长进度条 · 总时长
    └── 按钮行   上一集 快退 播放 快进 下一集 | 自定义快捷键（最多 5 个，从右往左）
```

**横屏**为独立布局：工具面板与设置面板贴在屏幕右侧（左侧圆角、占约 42% 宽），
播放控制、倍速、截图、小窗排成一行。

---

## 四、编译说明

包内 `CodecEngine.java` 与 `HwEngine.java` 属于解码内核，不是 UI：
- `CodecEngine` 是自研 MediaCodec 内核，**无外部依赖，可直接编译**
- `HwEngine` 依赖 `com.hwdecoder.*`（解码器核心），**单独编译会报找不到符号**

三种处理方式：

**A. 完整编译**：把 `com.hwdecoder` 源码放回 `src/com/`，`libhwdecoder.so` 放回 `lib/<abi>/`
```bash
python3 build.py --proj . --out player.apk
```

**B. 纯 UI 参考（推荐用于改界面）**：删除 `HwEngine.java`，并在
`PlayerActivity.java` 中删掉两处 `HwEngine` 分支（搜索 `HwEngine` 即可定位）。
此时只剩"系统内核 + 自研内核"，界面与全部 UI 功能完全不受影响。

**C. 最小编译**：只保留 `SystemEngine`，删除 `CodecEngine` / `HwEngine`
并去掉 `PlayerActivity` 中对应分支。

---

## 五、重新生成图标

```bash
python3 gen_icons3.py     # → res/drawable-*（需 Pillow）
```

图标全部由代码绘制：统一 2dp 线宽、圆头圆角、8 倍超采样后 LANCZOS 缩小。
改某个图标只需修改 `ICONS` 字典里对应的绘制函数。

---

## 六、UI 修改常见入口

| 想改什么 | 改哪里 |
|---|---|
| 进度条粗细、预览气泡 | `SlimSeekBar.java` |
| 画面比例、缩放、翻转 | `VideoRenderView.java` |
| 弹窗/面板透明度与样式 | `Ui.java` |
| 底部按钮大小与排列 | `res/layout/activity_player.xml` |
| 播放工具图标与顺序 | `PlayToolsPanel.java` |
| 播放内设置项分组 | `PlaySettingsPanel.java` |
| 主题与强调色 | `ThemeEngine.java` + `res/values/colors.xml` |
