#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""时尘播放器 v3 —— 播放器专用精细图标
分辨率提高（8x 超采样），细节更丰富，重点覆盖播放工具面板与播放界面。
旋转屏幕图标与全屏图标明确区分。
"""
import os, math
from PIL import Image, ImageDraw

RES = "/data/workspace/shichen/res"
W = (255, 255, 255, 255)
SS = 8                      # 超采样倍数（更平滑）
DENS = {"mdpi": 1.0, "hdpi": 1.5, "xhdpi": 2.0, "xxhdpi": 3.0, "xxxhdpi": 4.0}


class P:
    def __init__(self, d, px):
        self.d = d
        self.px = px
        self.w = 1.9 * px

    def P(self, x, y):
        return (x * self.px, y * self.px)

    def _cap(self, x, y, r):
        self.d.ellipse([x - r, y - r, x + r, y + r], fill=W)

    def line(self, x1, y1, x2, y2, w=None):
        w = self.w if w is None else w * self.px
        a, b = self.P(x1, y1), self.P(x2, y2)
        self.d.line([a, b], fill=W, width=int(round(w)))
        r = w / 2.0
        self._cap(a[0], a[1], r)
        self._cap(b[0], b[1], r)

    def poly(self, pts, close=False, w=None):
        w = self.w if w is None else w * self.px
        p = [self.P(*q) for q in pts]
        if close:
            p.append(p[0])
        self.d.line(p, fill=W, width=int(round(w)))
        r = w / 2.0
        for q in p:
            self._cap(q[0], q[1], r)

    def rect(self, x1, y1, x2, y2, r=2.5, w=None):
        w = self.w if w is None else w * self.px
        self.d.rounded_rectangle([x1 * self.px, y1 * self.px, x2 * self.px, y2 * self.px],
                                 radius=r * self.px, outline=W, width=int(round(w)))

    def frect(self, x1, y1, x2, y2, r=1.5):
        self.d.rounded_rectangle([x1 * self.px, y1 * self.px, x2 * self.px, y2 * self.px],
                                 radius=r * self.px, fill=W)

    def circle(self, cx, cy, r, w=None):
        w = self.w if w is None else w * self.px
        c, R = self.P(cx, cy), r * self.px
        self.d.ellipse([c[0] - R, c[1] - R, c[0] + R, c[1] + R],
                       outline=W, width=int(round(w)))

    def fcircle(self, cx, cy, r):
        c, R = self.P(cx, cy), r * self.px
        self.d.ellipse([c[0] - R, c[1] - R, c[0] + R, c[1] + R], fill=W)

    def dot(self, cx, cy, r):
        self.fcircle(cx, cy, r)

    def fill(self, pts):
        self.d.polygon([self.P(*q) for q in pts], fill=W)

    def arc(self, cx, cy, r, a0, a1, step=2, w=None):
        """角度制，顺时针"""
        w = self.w if w is None else w * self.px
        pts = []
        a = a0
        while a <= a1:
            ra = math.radians(a)
            pts.append(((cx + r * math.cos(ra)) * self.px,
                        (cy + r * math.sin(ra)) * self.px))
            a += step
        if len(pts) >= 2:
            self.d.line(pts, fill=W, width=int(round(w)), joint="curve")
        rcap = w / 2.0
        if pts:
            self._cap(pts[0][0], pts[0][1], rcap)
            self._cap(pts[-1][0], pts[-1][1], rcap)
        return pts


# ================================================== 播放工具面板图标

def i_playlist(p):
    """播放列表：左侧播放三角 + 三条曲目线"""
    p.fill([(4.2, 6.2), (9.4, 9.2), (4.2, 12.2)])
    p.line(11.4, 6.6, 20, 6.6, w=1.7)
    p.line(11.4, 12, 20, 12, w=1.7)
    p.line(11.4, 17.4, 20, 17.4, w=1.7)
    p.dot(4.6, 17.4, 1.35)


def i_ratio(p):
    """长宽比：屏幕框 + 双向箭头"""
    p.rect(3.2, 5.4, 20.8, 18.6, r=2.2, w=1.8)
    p.line(6.6, 12, 17.4, 12, w=1.6)
    p.fill([(6.2, 10.2), (8.6, 12), (6.2, 13.8)])
    p.fill([(17.8, 10.2), (15.4, 12), (17.8, 13.8)])
    p.line(12, 8.2, 12, 15.8, w=1.6)
    p.fill([(10.2, 8.6), (12, 6.6), (13.8, 8.6)])
    p.fill([(10.2, 15.4), (12, 17.4), (13.8, 15.4)])


def i_zoom(p):
    """显示设置：屏幕 + 放大镜"""
    p.rect(2.8, 4.4, 14.6, 14.2, r=2.0, w=1.8)
    p.line(5.6, 8.6, 11.8, 8.6, w=1.5)
    p.line(5.6, 11.4, 9.6, 11.4, w=1.5)
    p.circle(16.6, 16.6, 5.0, w=1.8)
    p.line(20.2, 20.2, 22.6, 22.4, w=2.0)
    p.line(14.8, 16.6, 18.4, 16.6, w=1.5)
    p.line(16.6, 14.8, 16.6, 18.4, w=1.5)


def i_audio(p):
    """音轨：扬声器 + 双层声波"""
    p.fill([(3.4, 9.6), (7.4, 9.6), (11.6, 5.6), (11.6, 18.4), (7.4, 14.4), (3.4, 14.4)])
    p.arc(13.4, 12, 3.4, -58, 58, w=1.7)
    p.arc(13.4, 12, 6.4, -56, 56, w=1.7)


def i_subtitle(p):
    """字幕：屏幕 + 底部字幕条"""
    p.rect(2.8, 4.2, 21.2, 15.6, r=2.2, w=1.8)
    p.frect(5.6, 13.0, 11.4, 14.6, r=0.9)
    p.frect(13.2, 13.0, 18.4, 14.6, r=0.9)
    p.line(6.4, 18.6, 12.2, 18.6, w=1.8)
    p.line(14.6, 18.6, 17.8, 18.6, w=1.8)


def i_ab(p):
    """A-B 循环：书签轮廓 + A/B 文字线"""
    p.poly([(6.6, 3.6), (17.4, 3.6), (17.4, 20.4), (12.0, 16.9), (6.6, 20.4)], close=True, w=1.8)
    # A
    p.line(9.2, 13.4, 11.0, 8.2, w=1.6)
    p.line(11.0, 8.2, 12.8, 13.4, w=1.6)
    p.line(9.6, 11.6, 12.4, 11.6, w=1.5)
    # B
    p.line(14.0, 8.2, 14.0, 13.4, w=1.6)
    p.arc(14.0, 10.0, 1.7, -90, 90, w=1.5)
    p.arc(14.0, 12.1, 1.4, -90, 90, w=1.5)


def i_fav(p):
    """收藏：精细心形"""
    cx, cy, s = 12, 12.4, 8.4
    pts = []
    for i in range(121):
        t = math.radians(i * 3)
        x = 16 * (math.sin(t) ** 3)
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t)
              - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((cx + x * s / 17.0, cy + y * s / 17.0))
    p.d.line([p.P(*q) for q in pts], fill=W, width=int(round(p.w)), joint="curve")


def i_fav_filled(p):
    """收藏（已收藏）：实心心形"""
    cx, cy, s = 12, 12.4, 8.6
    pts = []
    for i in range(121):
        t = math.radians(i * 3)
        x = 16 * (math.sin(t) ** 3)
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t)
              - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((cx + x * s / 17.0, cy + y * s / 17.0))
    p.d.polygon([p.P(*q) for q in pts], fill=W)


def i_add(p):
    """加入列表：列表 + 加号"""
    p.line(10.2, 7.0, 20.4, 7.0, w=1.7)
    p.line(10.2, 12.4, 20.4, 12.4, w=1.7)
    p.line(10.2, 17.8, 20.4, 17.8, w=1.7)
    p.line(4.0, 12.4, 8.2, 12.4, w=1.9)
    p.line(6.1, 10.3, 6.1, 14.5, w=1.9)


def i_speed(p):
    """倍速：播放三角 + 速度线"""
    p.fill([(3.6, 5.8), (13.4, 12), (3.6, 18.2)])
    for x0, x1, y in ((15.0, 20.4, 7.6), (16.6, 20.4, 12.0), (15.0, 20.4, 16.4)):
        p.line(x0, y, x1, y, w=1.8)


def i_repeat(p):
    """循环：环形双向箭头"""
    p.arc(12, 12, 8.2, 42, 300, w=1.9)
    p.fill([(17.9, 4.6), (20.8, 9.0), (16.2, 9.9)])
    p.arc(12, 12, 8.2, 222, 480, w=1.9)
    p.fill([(6.1, 19.4), (3.2, 15.0), (7.8, 14.1)])


def i_decode(p):
    """解码：芯片 + 引脚"""
    p.rect(6.6, 6.6, 17.4, 17.4, r=2.0, w=1.8)
    p.rect(9.8, 9.8, 14.2, 14.2, r=1.4, w=1.5)
    for x in (9.0, 12.0, 15.0):
        p.line(x, 3.4, x, 6.6, w=1.5)
        p.line(x, 17.4, x, 20.6, w=1.5)
    for y in (9.0, 12.0, 15.0):
        p.line(3.4, y, 6.6, y, w=1.5)
        p.line(17.4, y, 20.6, y, w=1.5)


def i_equalizer(p):
    """均衡器：三条带滑块的竖线"""
    for x, y in ((5.8, 8.2), (12, 14.6), (18.2, 6.6)):
        p.line(x, 3.8, x, 20.2, w=1.7)
    p.fcircle(5.8, 8.2, 2.2)
    p.fcircle(12, 14.6, 2.2)
    p.fcircle(18.2, 6.6, 2.2)


def i_info(p):
    """信息：圆圈 + i"""
    p.circle(12, 12, 8.6, w=1.9)
    p.dot(12, 7.6, 1.5)
    p.line(12, 10.8, 12, 16.8, w=1.9)


def i_url(p):
    """网络串流：地球 + 经纬线"""
    p.circle(12, 12, 8.6, w=1.9)
    p.line(3.4, 12, 20.6, 12, w=1.6)
    p.arc(12, 12, 8.6, -90, 90, w=1.6)
    p.arc(12, 12, 4.4, -90, 90, w=1.5)


def i_sleep(p):
    """睡眠定时：月亮 + 星"""
    p.fill([(15.4, 3.2), (10.6, 8.4), (12.6, 9.0), (10.4, 14.4),
            (18.6, 10.4), (16.2, 9.6), (19.4, 4.6)])
    p.fcircle(6.2, 16.8, 1.5)
    p.fcircle(9.6, 19.2, 1.1)


def i_screenshot(p):
    """截图：屏幕 + 取景框四角"""
    p.rect(2.8, 4.6, 21.2, 19.4, r=2.2, w=1.8)
    # 取景框四角
    p.poly([(6.4, 11.6), (6.4, 8.4), (9.6, 8.4)], w=1.7)
    p.poly([(14.4, 8.4), (17.6, 8.4), (17.6, 11.6)], w=1.7)
    p.poly([(17.6, 12.4), (17.6, 15.6), (14.4, 15.6)], w=1.7)
    p.poly([(9.6, 15.6), (6.4, 15.6), (6.4, 12.4)], w=1.7)


def i_lock(p):
    """锁定：闭合挂锁"""
    p.rect(5.4, 10.6, 18.6, 20.4, r=2.4, w=1.9)
    p.arc(12, 10.6, 4.6, 180, 360, w=1.9)
    p.dot(12, 14.4, 1.5)
    p.line(12, 15.8, 12, 17.6, w=1.8)


def i_unlock(p):
    """解锁：打开挂锁"""
    p.rect(5.4, 10.6, 18.6, 20.4, r=2.4, w=1.9)
    p.arc(12.6, 10.6, 4.6, 180, 330, w=1.9)
    p.dot(12, 14.4, 1.5)
    p.line(12, 15.8, 12, 17.6, w=1.8)


def i_screen_rotate(p):
    """屏幕旋转：横屏机身 + 环绕旋转箭头（明显区别于全屏图标）"""
    # 横屏机身
    p.rect(3.6, 9.0, 15.4, 15.6, r=2.4, w=1.9)
    p.line(6.4, 12.3, 12.6, 12.3, w=1.5)
    p.dot(14.2, 12.3, 1.1)
    # 环绕旋转箭头（右侧弧线 + 箭头）
    p.arc(12.0, 12.3, 9.4, -34, 78, w=1.9)
    p.fill([(19.4, 4.6), (21.6, 8.6), (17.4, 9.2)])


def i_brightness(p):
    """亮度：太阳 + 光芒"""
    p.circle(12, 12, 4.6, w=1.9)
    for a in range(0, 360, 45):
        ra = math.radians(a)
        x0, y0 = 12 + 7.0 * math.cos(ra), 12 + 7.0 * math.sin(ra)
        x1, y1 = 12 + 9.6 * math.cos(ra), 12 + 9.6 * math.sin(ra)
        p.line(x0, y0, x1, y1, w=1.7)


def i_pip(p):
    """画中画：小窗叠在大窗右下"""
    p.rect(2.8, 4.4, 21.2, 15.4, r=2.0, w=1.8)
    p.frect(11.0, 11.2, 20.4, 19.6, r=1.6)


def i_scan(p):
    """扫描：取景框 + 扫描线"""
    p.rect(3.0, 5.0, 21.0, 19.0, r=2.2, w=1.8)
    p.line(6.0, 11.0, 18.0, 11.0, w=1.8)
    p.line(6.0, 14.6, 13.0, 14.6, w=1.6)


def i_share(p):
    """分享：三点连线"""
    p.fcircle(17.6, 6.0, 2.3)
    p.fcircle(6.4, 12.0, 2.3)
    p.fcircle(17.6, 18.0, 2.3)
    p.line(8.6, 10.9, 15.4, 7.1, w=1.8)
    p.line(8.6, 13.1, 15.4, 16.9, w=1.8)


def i_bgplay(p):
    """后台播放：播放三角 + 后台窗口轮廓"""
    p.rect(2.8, 4.6, 21.2, 19.4, r=2.4, w=1.8)
    p.line(2.8, 9.0, 21.2, 9.0, w=1.7)
    p.fcircle(5.4, 6.8, 1.15)
    p.fcircle(8.2, 6.8, 1.15)
    p.fill([(9.6, 12.2), (17.4, 16.4), (9.6, 20.6)])


def i_wake(p):
    """屏幕常亮：太阳 + 常亮标记（环形箭头）"""
    p.circle(12, 11.4, 4.4, w=1.9)
    for a in range(0, 360, 60):
        ra = math.radians(a)
        p.line(12 + 6.4 * math.cos(ra), 11.4 + 6.4 * math.sin(ra),
               12 + 8.4 * math.cos(ra), 11.4 + 8.4 * math.sin(ra), w=1.6)
    # 下方"常亮"横条
    p.line(6.6, 20.4, 17.4, 20.4, w=1.9)


def i_statusbar(p):
    """顶部状态显示：顶部横条 + 左右内容块"""
    p.rect(2.6, 5.0, 21.4, 12.4, r=2.2, w=1.8)
    p.frect(5.0, 8.2, 9.6, 9.6, r=0.9)
    p.frect(14.4, 8.2, 19.0, 9.6, r=0.9)
    p.line(12.0, 6.4, 12.0, 11.0, w=1.6)
    p.line(6.4, 15.8, 17.6, 15.8, w=1.7)
    p.line(6.4, 18.8, 13.6, 18.8, w=1.7)


def i_statuspos(p):
    """状态栏位置：顶部条 + 上下左右移动箭头"""
    p.rect(3.0, 5.4, 21.0, 9.8, r=2.0, w=1.8)
    p.frect(5.4, 7.4, 9.2, 8.0, r=0.8)
    p.frect(14.8, 7.4, 18.6, 8.0, r=0.8)
    # 双向移动箭头
    p.line(12.0, 12.6, 12.0, 19.6, w=1.8)
    p.fill([(9.4, 15.4), (12.0, 12.4), (14.6, 15.4)])
    p.fill([(9.4, 17.2), (12.0, 20.2), (14.6, 17.2)])


def i_avsync(p):
    """音画同步：声波 + 时钟指针"""
    p.arc(7.6, 12, 4.2, -60, 60, w=1.8)
    p.arc(7.6, 12, 7.4, -58, 58, w=1.7)
    p.fill([(3.4, 10.2), (6.6, 10.2), (9.0, 7.6), (9.0, 16.4), (6.6, 13.8), (3.4, 13.8)])
    # 时钟
    p.circle(16.4, 12, 5.2, w=1.8)
    p.line(16.4, 12, 16.4, 8.8, w=1.6)
    p.line(16.4, 12, 18.8, 13.4, w=1.6)


def i_jump(p):
    """跳转到：目标点 + 定位箭头"""
    p.circle(11.4, 12, 7.4, w=1.9)
    p.circle(11.4, 12, 3.4, w=1.7)
    p.line(17.8, 18.4, 21.4, 22.0, w=2.0)
    p.dot(11.4, 12, 1.5)


def i_share2(p):
    """分享：节点连线"""
    p.fcircle(17.8, 5.8, 2.4)
    p.fcircle(6.2, 12.0, 2.4)
    p.fcircle(17.8, 18.2, 2.4)
    p.line(8.5, 10.9, 15.5, 7.0, w=1.9)
    p.line(8.5, 13.1, 15.5, 17.0, w=1.9)


def i_flip(p):
    """视频翻转：左右镜像箭头 + 中轴"""
    p.line(12.0, 4.2, 12.0, 19.8, w=1.7)
    # 左半三角
    p.fill([(3.2, 12.0), (9.4, 8.0), (9.4, 16.0)])
    # 右半三角（镜像）
    p.fill([(20.8, 12.0), (14.6, 8.0), (14.6, 16.0)])


def i_rotate90(p):
    """旋转 90°：弧线箭头带 90 标记"""
    p.arc(12, 12, 7.6, 20, 340, w=1.9)
    p.fill([(19.2, 11.0), (22.4, 12.6), (19.6, 15.0)])
    p.dot(12, 12, 1.7)


def i_quickedit(p):
    """快捷键编辑：一排方块 + 铅笔"""
    p.frect(3.0, 4.6, 7.2, 8.8, r=1.2)
    p.frect(8.6, 4.6, 12.8, 8.8, r=1.2)
    p.frect(14.2, 4.6, 18.4, 8.8, r=1.2)
    p.frect(3.0, 11.0, 7.2, 15.2, r=1.2)
    p.frect(14.2, 11.0, 18.4, 15.2, r=1.2)
    p.line(9.0, 17.4, 17.4, 17.4, w=1.8)
    p.fill([(17.4, 14.8), (21.6, 19.6), (15.4, 19.6)])


def i_balance(p):
    """声道平衡：中轴 + 左右滑块"""
    p.line(12.0, 4.6, 12.0, 19.4, w=1.7)
    p.rect(3.0, 9.4, 21.0, 14.6, r=2.0, w=1.7)
    p.frect(9.6, 10.4, 14.4, 13.6, r=0.8)
    p.line(6.0, 7.0, 6.0, 12.0, w=1.8)
    p.line(18.0, 7.0, 18.0, 12.0, w=1.8)


def i_reset(p):
    """重置排序：环形逆时针箭头"""
    p.arc(12, 12, 7.4, 40, 320, w=1.9)
    p.fill([(4.8, 9.6), (8.2, 11.4), (5.6, 14.2)])


def i_bookmark2(p):
    """书签：书签轮廓 + 加号"""
    p.fill([(6.4, 4.8), (17.6, 4.8), (17.6, 20.6), (12.0, 16.8), (6.4, 20.6)])
    p.line(9.6, 10.4, 14.4, 10.4, w=1.9)
    p.line(12.0, 8.0, 12.0, 12.8, w=1.9)


def i_abclear(p):
    """清除 A-B：A-B 标记 + 斜线"""
    p.line(4.6, 8.2, 12.0, 8.2, w=1.9)
    p.line(4.6, 15.8, 12.0, 15.8, w=1.9)
    p.line(12.0, 8.2, 19.4, 15.8, w=1.9)
    p.line(12.0, 15.8, 19.4, 8.2, w=1.9)


def i_tooledit(p):
    """工具按钮编辑：网格方块 + 勾选"""
    p.rect(2.8, 4.4, 21.2, 19.6, r=2.2, w=1.8)
    p.line(2.8, 9.2, 21.2, 9.2, w=1.6)
    p.line(2.8, 14.8, 21.2, 14.8, w=1.6)
    p.line(12.0, 9.2, 12.0, 19.6, w=1.6)
    p.frect(4.4, 5.6, 7.2, 8.0, r=0.8)
    p.frect(13.6, 10.4, 16.4, 13.2, r=0.8)


def i_drag(p):
    """拖拽手柄：两列圆点"""
    for y in (6.4, 12.0, 17.6):
        p.fcircle(9.4, y, 1.55)
        p.fcircle(14.6, y, 1.55)


def i_more(p):
    """更多：三点"""
    for y in (5.6, 12, 18.4):
        p.fcircle(12, y, 1.7)


def i_more_h(p):
    """更多（横向）"""
    for x in (5.6, 12, 18.4):
        p.fcircle(x, 12, 1.7)


# ================================================== 播放界面控件

def i_play(p):
    p.fill([(7.2, 5.0), (19.0, 12.0), (7.2, 19.0)])


def i_pause(p):
    p.frect(7.4, 5.2, 10.4, 18.8, r=1.3)
    p.frect(13.6, 5.2, 16.6, 18.8, r=1.3)


def i_prev(p):
    p.line(4.6, 6.0, 4.6, 18.0, w=1.9)
    p.fill([(19.4, 6.0), (10.8, 12.0), (19.4, 18.0)])


def i_next(p):
    p.fill([(4.6, 6.0), (13.2, 12.0), (4.6, 18.0)])
    p.line(19.4, 6.0, 19.4, 18.0, w=1.9)


def i_rew(p):
    p.fill([(11.6, 7.2), (4.4, 12.0), (11.6, 16.8)])
    p.fill([(20.0, 7.2), (12.8, 12.0), (20.0, 16.8)])


def i_ff(p):
    p.fill([(4.0, 7.2), (11.2, 12.0), (4.0, 16.8)])
    p.fill([(12.4, 7.2), (19.6, 12.0), (12.4, 16.8)])


def i_fullscreen(p):
    """全屏：四角括号"""
    p.poly([(3.2, 9.6), (3.2, 3.2), (9.6, 3.2)], w=1.9)
    p.poly([(14.4, 3.2), (20.8, 3.2), (20.8, 9.6)], w=1.9)
    p.poly([(20.8, 14.4), (20.8, 20.8), (14.4, 20.8)], w=1.9)
    p.poly([(9.6, 20.8), (3.2, 20.8), (3.2, 14.4)], w=1.9)


def i_back(p):
    p.poly([(11.0, 5.6), (4.6, 12.0), (11.0, 18.4)], w=1.9)
    p.line(4.6, 12.0, 19.6, 12.0, w=1.9)


def i_settings(p):
    """工具：齿轮"""
    p.circle(12, 12, 3.4, w=1.9)
    for a in range(0, 360, 45):
        ra = math.radians(a)
        p.line(12 + 5.2 * math.cos(ra), 12 + 5.2 * math.sin(ra),
               12 + 8.8 * math.cos(ra), 12 + 8.8 * math.sin(ra), w=1.9)
    p.circle(12, 12, 8.0, w=1.6)


def i_aspect(p):
    """画面比例：可变形的画框 + 调节箭头"""
    p.rect(3.0, 6.4, 21.0, 17.6, r=2.2, w=1.8)
    p.line(7.4, 12.0, 16.6, 12.0, w=1.5)
    p.fill([(7.0, 10.3), (9.2, 12.0), (7.0, 13.7)])
    p.fill([(17.0, 10.3), (14.8, 12.0), (17.0, 13.7)])


def i_volume(p):
    """音量：扬声器 + 中声波"""
    p.fill([(3.2, 9.4), (7.2, 9.4), (11.4, 5.4), (11.4, 18.6), (7.2, 14.6), (3.2, 14.6)])
    p.arc(13.6, 12, 4.0, -56, 56, w=1.8)


def i_crop(p):
    """裁剪：交叉角标"""
    p.poly([(6.4, 3.4), (6.4, 17.6), (20.6, 17.6)], w=1.8)
    p.poly([(17.6, 20.6), (17.6, 6.4), (3.4, 6.4)], w=1.8)


def i_gesture(p):
    """手势：手掌点击"""
    p.rect(6.0, 8.6, 18.0, 19.4, r=2.6, w=1.8)
    p.line(9.6, 8.6, 9.6, 4.6, w=1.7)
    p.line(12.4, 8.6, 12.4, 3.4, w=1.7)
    p.line(15.2, 8.6, 15.2, 4.2, w=1.7)


def i_network(p):
    """网络流：信号塔"""
    p.line(6.0, 14.0, 6.0, 20.0, w=1.8)
    p.line(12.0, 8.0, 12.0, 20.0, w=1.8)
    p.line(18.0, 11.0, 18.0, 20.0, w=1.8)


def i_timer(p):
    """定时：时钟"""
    p.circle(12, 12.4, 8.4, w=1.9)
    p.line(12, 12.4, 12, 6.8, w=1.8)
    p.line(12, 12.4, 16.6, 14.8, w=1.8)


def i_eye(p):
    p.arc(12, 12.6, 8.6, 200, 340, w=1.8)
    p.arc(12, 12.6, 8.6, 20, 160, w=1.8)
    p.fcircle(12, 12.6, 2.6)


ICONS = {
    "ic_playlist": i_playlist, "ic_ratio": i_ratio, "ic_zoom": i_zoom,
    "ic_audio": i_audio, "ic_subtitle": i_subtitle, "ic_ab": i_ab,
    "ic_fav": i_fav, "ic_fav_filled": i_fav_filled, "ic_add": i_add, "ic_speed": i_speed, "ic_repeat": i_repeat,
    "ic_decode": i_decode, "ic_equalizer": i_equalizer, "ic_info": i_info,
    "ic_url": i_url, "ic_sleep": i_sleep, "ic_screenshot": i_screenshot,
    "ic_lock": i_lock, "ic_unlock": i_unlock, "ic_screen_rotate": i_screen_rotate,
    "ic_brightness": i_brightness, "ic_more": i_more, "ic_more_h": i_more_h,
    "ic_play": i_play, "ic_pause": i_pause, "ic_prev": i_prev, "ic_next": i_next,
    "ic_rew": i_rew, "ic_ff": i_ff, "ic_fullscreen": i_fullscreen,
    "ic_back": i_back, "ic_settings": i_settings, "ic_aspect": i_aspect,
    "ic_volume": i_volume, "ic_crop": i_crop, "ic_gesture": i_gesture,
    "ic_network": i_network, "ic_timer": i_timer, "ic_eye": i_eye,
    "ic_pip": i_pip, "ic_scan": i_scan,
    "ic_drag": i_drag, "ic_share": i_share2,
    "ic_bookmark": i_bookmark2, "ic_abclear": i_abclear,
    "ic_tooledit": i_tooledit,
    "ic_balance": i_balance, "ic_reset": i_reset,
    "ic_flip": i_flip, "ic_rotate90": i_rotate90, "ic_quickedit": i_quickedit,
    "ic_bgplay": i_bgplay, "ic_wake": i_wake, "ic_statusbar": i_statusbar,
    "ic_statuspos": i_statuspos, "ic_avsync": i_avsync, "ic_jump": i_jump,
}


def make(fn, size):
    S = size * SS
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    fn(P(ImageDraw.Draw(img), S / 24.0))
    return img.resize((size, size), Image.LANCZOS)


def build():
    for name, fn in ICONS.items():
        for dens, mult in DENS.items():
            d = os.path.join(RES, "drawable-" + dens)
            os.makedirs(d, exist_ok=True)
            make(fn, int(round(24 * mult))).save(os.path.join(d, name + ".png"))
    print("icons redrawn:", len(ICONS))


if __name__ == "__main__":
    build()
