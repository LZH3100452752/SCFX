#!/usr/bin/env python3
"""手工 Android APK 构建管线：aapt2 -> javac -> d8 -> zip -> zipalign -> apksigner"""
import os, sys, glob, zipfile, subprocess, shutil, argparse

SDK = "/data/workspace/sdk"
BT = os.path.join(SDK, "build-tools/android-37.0")
PLATFORM = os.path.join(SDK, "platform/android-34-ext12/android.jar")
JAVA11 = "/usr/lib/jvm/java-11-openjdk-amd64/bin/java"
KEYTOOL = "/usr/lib/jvm/java-11-openjdk-amd64/bin/keytool"

LOCAL_JDK = "/data/workspace/jdk25/bin/java"


def java25():
    if os.path.exists(LOCAL_JDK):
        return LOCAL_JDK
    try:
        import jdk4py, os as _o
        return os.path.dirname(jdk4py.JAVA) + "/java"
    except Exception:
        return JAVA11

def run(cmd, cwd=None, env=None):
    txt = " ".join(str(c) for c in cmd)
    if len(txt) > 600:
        txt = txt[:600] + " ...(%d args)" % len(cmd)
    print(">>", txt)
    p = subprocess.run(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    out = p.stdout.decode("utf-8", "replace")
    if p.returncode != 0:
        print(out[-6000:])
        raise SystemExit("FAILED: " + str(cmd[0]))
    return out

def build(proj, out_apk, min_sdk=24, target_sdk=34):
    b = os.path.join(proj, "build")
    if os.path.isdir(b):
        shutil.rmtree(b)
    for d in ("res_zip", "gen", "classes", "dex"):
        os.makedirs(os.path.join(b, d), exist_ok=True)

    res = os.path.join(proj, "res")
    manifest = os.path.join(proj, "AndroidManifest.xml")
    src = os.path.join(proj, "src")
    assets = os.path.join(proj, "assets")

    # 1. aapt2 compile
    reszip = os.path.join(b, "res.zip")
    run([os.path.join(BT, "aapt2"), "compile", "--dir", res, "-o", reszip])

    # 2. aapt2 link (with assets if present)
    unaligned = os.path.join(b, "unaligned.apk")
    cmd = [os.path.join(BT, "aapt2"), "link", "-I", PLATFORM,
           "--manifest", manifest, "-o", unaligned,
           "--java", os.path.join(b, "gen"),
           "--min-sdk-version", str(min_sdk), "--target-sdk-version", str(target_sdk),
           "--auto-add-overlay", "-v"]
    if os.path.isdir(assets):
        cmd += ["-A", assets]
    run(cmd + [reszip])

    # 3. javac
    sources = []
    for root, _, files in os.walk(src):
        sources += [os.path.join(root, f) for f in files if f.endswith(".java")]
    for root, _, files in os.walk(os.path.join(b, "gen")):
        sources += [os.path.join(root, f) for f in files if f.endswith(".java")]
    sources.sort()
    with open(os.path.join(b, "sources.txt"), "w") as f:
        f.write("\n".join(sources))
    run([JAVA11, "-m", "jdk.compiler/com.sun.tools.javac.Main",
         "-source", "8", "-target", "8", "-encoding", "UTF-8", "-nowarn",
         "-XDignore.symbol.file",
         "-classpath", PLATFORM,
         "-d", os.path.join(b, "classes"), "@" + os.path.join(b, "sources.txt")],
        cwd=proj)

    # 4. d8
    classes = []
    for root, _, files in os.walk(os.path.join(b, "classes")):
        classes += [os.path.join(root, f) for f in files if f.endswith(".class")]
    run([java25(), "-Xmx2g", "-cp", os.path.join(BT, "lib", "d8.jar"),
         "com.android.tools.r8wrappers.D8Wrapper", "--lib", PLATFORM,
         "--min-api", str(min_sdk), "--output", os.path.join(b, "dex")] + classes)

    # 5. merge dex + native libs into apk
    dexes = sorted(glob.glob(os.path.join(b, "dex", "classes*.dex")))
    print("dex files:", [os.path.basename(d) for d in dexes])
    z = zipfile.ZipFile(unaligned, "a", zipfile.ZIP_DEFLATED)
    for d in dexes:
        z.write(d, os.path.basename(d))
    # 原生库：必须以 STORED（不压缩）方式放进 lib/<abi>/，否则系统无法直接 mmap 加载
    native = os.path.join(proj, "lib")
    if os.path.isdir(native):
        n = 0
        for abi in sorted(os.listdir(native)):
            adir = os.path.join(native, abi)
            if not os.path.isdir(adir):
                continue
            for f in sorted(os.listdir(adir)):
                if f.endswith(".so"):
                    z.write(os.path.join(adir, f), "lib/%s/%s" % (abi, f),
                            zipfile.ZIP_STORED)
                    n += 1
        print("native libs packed:", n)
    z.close()

    # 6. zipalign
    aligned = os.path.join(b, "aligned.apk")
    run([os.path.join(BT, "zipalign"), "-p", "-f", "4", unaligned, aligned])

    # 7. sign
    ks = "/data/workspace/shichen.keystore"
    if not os.path.exists(ks):
        run([KEYTOOL, "-genkeypair", "-v", "-keystore", ks, "-alias", "shichen",
             "-keyalg", "RSA", "-keysize", "2048", "-validity", "10950",
             "-storepass", "shichen2026", "-keypass", "shichen2026",
             "-dname", "CN=Shichen Player, OU=App, O=Shichen, L=Chengdu, ST=SC, C=CN"])
    if os.path.exists(out_apk):
        os.remove(out_apk)
    tmp = "/tmp/shichen_signed.apk"
    if os.path.exists(tmp):
        os.remove(tmp)
    run([java25(), "--enable-native-access=ALL-UNNAMED", "-Xmx1g", "-cp",
         os.path.join(BT, "lib", "apksigner.jar"),
         "com.android.apksigner.ApkSignerTool", "sign",
         "--ks", ks, "--ks-pass", "pass:shichen2026", "--key-pass", "pass:shichen2026",
         "--out", tmp, aligned])
    shutil.copyfile(tmp, out_apk)
    print("APK OK:", out_apk, os.path.getsize(out_apk), "bytes")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--proj", default=os.path.dirname(os.path.abspath(__file__)))
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    out = a.out or os.path.join(a.proj, "build", "shichen.apk")
    build(a.proj, out)
