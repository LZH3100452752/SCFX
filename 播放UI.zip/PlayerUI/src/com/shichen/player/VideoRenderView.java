package com.shichen.player;

import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.view.Gravity;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

/**
 * 视频渲染视图。
 *
 * 关键设计：容器尺寸与 TextureView 尺寸始终保持不变（match_parent），
 * 画面比例与缩放一律通过 Matrix 变换实现。
 *
 * 原因：早期实现通过改变容器尺寸来实现比例适配，而 SurfaceView/TextureView
 * 尺寸一旦变化，底层 surface 会被销毁重建，解码器仍绑定在旧 surface 上，
 * 画面随即消失 —— 这正是"能跳转但一直黑屏"的根因。
 */
public class VideoRenderView {

    private final FrameLayout container;
    private TextureView textureView;
    private int videoW = 0;
    private int videoH = 0;
    private int rotation = 0;
    private int ratio = 0;
    private float zoom = 1.0f;
    private final Matrix transform = new Matrix();
    private boolean highQuality = true;
    private SurfaceHolder holder;

    public interface SurfaceHolder {
        void onSurfaceReady(android.view.Surface surface);

        void onSurfaceDestroyed();
    }

    /** 兼容模式：SurfaceView 全屏，由解码器自行适配比例（最可靠） */
    public static final int KIND_SURFACE = 0;
    /** 高级模式：TextureView + 矩阵变换，支持缩放/裁剪/原始比例 */
    public static final int KIND_TEXTURE = 1;

    private int kind;

    public VideoRenderView(FrameLayout container, SurfaceHolder holder, int kind) {
        this.container = container;
        this.holder = holder;
        this.kind = kind;
        create();
    }

    private void create() {
        container.removeAllViews();
        if (kind == KIND_SURFACE) {
            createSurface();
            return;
        }
        textureView = new TextureView(container.getContext());
        // 容器与视图始终全屏，绝不因比例或缩放而改变尺寸
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER);
        container.addView(textureView, lp);
        textureView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                applyBufferSize(st);
                if (holder != null) {
                    holder.onSurfaceReady(new android.view.Surface(st));
                }
                updateTransform();
            }

            public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
                applyBufferSize(st);
                updateTransform();
            }

            public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                if (holder != null) {
                    holder.onSurfaceDestroyed();
                }
                return true;
            }

            public void onSurfaceTextureUpdated(SurfaceTexture st) {
            }
        });
    }

    /**
     * 兼容模式：SurfaceView 全程 MATCH_PARENT，尺寸永不变化，
     * 画面比例交给解码器自行适配（系统内核用 VIDEO_SCALING_MODE）。
     * 这是最不容易黑屏的路径，因为 surface 从创建到销毁都不会重建。
     */
    private void createSurface() {
        android.view.SurfaceView sv = new android.view.SurfaceView(container.getContext());
        sv.getHolder().setFormat(android.graphics.PixelFormat.OPAQUE);
        try {
            sv.setZOrderMediaOverlay(true);
        } catch (Exception ignored) {
        }
        sv.getHolder().addCallback(new android.view.SurfaceHolder.Callback() {
            public void surfaceCreated(android.view.SurfaceHolder h) {
                if (holder != null) {
                    holder.onSurfaceReady(h.getSurface());
                }
            }

            public void surfaceChanged(android.view.SurfaceHolder h, int f, int w, int hh) {
            }

            public void surfaceDestroyed(android.view.SurfaceHolder h) {
                if (holder != null) {
                    holder.onSurfaceDestroyed();
                }
            }
        });
        container.addView(sv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER));
    }

    /** 高清渲染：缓冲尺寸用视频原始分辨率（更清晰，略耗资源） */
    public void setHighQuality(boolean on) {
        highQuality = on;
        if (textureView != null && textureView.getSurfaceTexture() != null) {
            applyBufferSize(textureView.getSurfaceTexture());
        }
    }

    /** 把缓冲尺寸设为视频原始分辨率，使 MediaCodec 以原生精度渲染 */
    private void applyBufferSize(SurfaceTexture st) {
        if (videoW > 0 && videoH > 0 && highQuality) {
            try {
                int w = videoW;
                int h = videoH;
                if (rotation == 90 || rotation == 270) {
                    w = videoH;
                    h = videoW;
                }
                st.setDefaultBufferSize(w, h);
            } catch (Exception ignored) {
            }
        }
    }

    public void setVideoSize(int w, int h, int rotation) {
        videoW = w;
        if (kind == KIND_SURFACE) {
            return;
        }
        videoH = h;
        this.rotation = rotation;
        if (textureView != null && textureView.getSurfaceTexture() != null) {
            applyBufferSize(textureView.getSurfaceTexture());
        }
        updateTransform();
    }

    public void setRatio(int ratio) {
        this.ratio = ratio;
        updateTransform();
    }

    /**
     * 从悬浮窗返回后重新把解码输出接回本视图。
     * TextureView 在页面被遮挡期间可能已销毁 SurfaceTexture，
     * 这里主动重新取一次并回调给外部重新 setSurface。
     */
    public void rebind() {
        if (kind == KIND_SURFACE) {
            if (holder == null) {
                return;
            }
            // 从容器中取回 SurfaceView 并重新上报 Surface
            for (int i = 0; i < container.getChildCount(); i++) {
                View v = container.getChildAt(i);
                if (v instanceof android.view.SurfaceView) {
                    android.view.SurfaceView sv = (android.view.SurfaceView) v;
                    android.view.SurfaceHolder sh = sv.getHolder();
                    if (sh != null && sh.getSurface() != null) {
                        holder.onSurfaceReady(sh.getSurface());
                    }
                    return;
                }
            }
            return;
        }
        if (textureView != null) {
            android.graphics.SurfaceTexture st = textureView.getSurfaceTexture();
            if (st != null && holder != null) {
                holder.onSurfaceReady(new android.view.Surface(st));
            }
        }
        updateTransform();
    }

    /** 用户翻转：0 无 / 1 水平镜像 / 2 垂直翻转 / 3 旋转 180° */
    private int flip = 0;
    /** 用户额外旋转：0 / 90 / 180 / 270 度 */
    private int userRotate = 0;

    public void setFlip(int f) {
        flip = f;
        updateTransform();
    }

    public void setUserRotate(int r) {
        userRotate = r;
        updateTransform();
    }

    public int flip() {
        return flip;
    }

    public int userRotate() {
        return userRotate;
    }

    public void setZoom(float z) {
        zoom = z;
        updateTransform();
    }

    /** 依据画面比例与缩放计算变换矩阵 */
    private boolean pendingTransform = false;

    public void updateTransform() {
        if (kind == KIND_SURFACE) {
            return;   // 兼容模式由解码器适配，无需矩阵
        }
        if (textureView == null) {
            return;
        }
        final int vw = textureView.getWidth();
        final int vh = textureView.getHeight();
        if (vw <= 0 || vh <= 0) {
            // 视图尚未完成布局。这里绝不能无条件 post 自身 —— 那会无限往
            // 主线程消息队列塞任务，把 UI 彻底卡死（返回键也会失效）。
            // 改为监听一次布局完成，且用标志位保证只挂一个监听。
            if (!pendingTransform) {
                pendingTransform = true;
                textureView.addOnLayoutChangeListener(
                        new android.view.View.OnLayoutChangeListener() {
                    public void onLayoutChange(android.view.View v, int l, int t, int r, int b,
                                               int ol, int ot, int or_, int ob) {
                        if (v.getWidth() > 0 && v.getHeight() > 0) {
                            v.removeOnLayoutChangeListener(this);
                            pendingTransform = false;
                            updateTransform();
                        }
                    }
                });
            }
            return;
        }
        if (videoW <= 0 || videoH <= 0) {
            // 尺寸未知时绝不能 reset 成单位矩阵 —— 那会把视频原始像素直接铺满
            // 全屏纹理，表现就是"被拉伸、没有黑边"。用 16:9 兜底并保持比例。
            float far = 16f / 9f;
            float fva = vw / (float) vh;
            float fdh;
            float fdw;
            if (far > fva) {
                fdw = vw;
                fdh = vw / far;
            } else {
                fdh = vh;
                fdw = vh * far;
            }
            transform.reset();
            transform.setScale(fdw / vw, fdh / vh, vw / 2f, vh / 2f);
textureView.setTransform(transform);
            return;
        }

        // 视频有效宽高（考虑元数据旋转 + 用户额外旋转）
        float srcW = videoW;
        float srcH = videoH;
        int effRot = (rotation + userRotate) % 360;
        if (effRot == 90 || effRot == 270) {
            srcW = videoH;
            srcH = videoW;
        }
        float ar = srcW / srcH;
        float viewAr = vw / (float) vh;

        // 目标显示宽高比。默认（RATIO_FIT）严格保持视频原始比例，
        // 横屏看竖屏视频、竖屏看横屏视频都不会被拉伸变形。
        boolean stretch = false;   // 强制拉伸填满（仅用户明确选择时）
        boolean cover = false;     // 裁剪填满（仅用户明确选择时）
        switch (ratio) {
            case Prefs.RATIO_16_9:
                ar = 16f / 9f;
                break;
            case Prefs.RATIO_4_3:
                ar = 4f / 3f;
                break;
            case Prefs.RATIO_1_1:
                ar = 1f;
                break;
            case Prefs.RATIO_21_9:
                ar = 21f / 9f;
                break;
            case Prefs.RATIO_FILL:
                stretch = true;
                break;
            case Prefs.RATIO_CROP:
                cover = true;
                break;
            default:
                break;
        }

        float dw;
        float dh;
        if (stretch) {
            // 仅当用户明确选择"铺满(拉伸)"时才改变形状
            dw = vw;
            dh = vh;
        } else if (ratio == Prefs.RATIO_ORIGINAL) {
            // 原始像素 1:1 显示
            dw = srcW;
            dh = srcH;
        } else if (cover) {
            if (ar > viewAr) {
                dh = vh;
                dw = vh * ar;
            } else {
                dw = vw;
                dh = vw / ar;
            }
        } else {
            if (ar > viewAr) {
                dw = vw;
                dh = vw / ar;
            } else {
                dh = vh;
                dw = vh * ar;
            }
        }

        dw *= zoom;
        dh *= zoom;

        float sx = dw / vw;
        float sy = dh / vh;
        transform.reset();
        transform.setScale(sx, sy, vw / 2f, vh / 2f);
        // 用户额外旋转（用于录制方向错误的视频）：旋转后按新比例重算，保证不拉伸
        if (userRotate != 0) {
            float na = (userRotate == 90 || userRotate == 270)
                    ? (srcH / srcW) : (srcW / srcH);
            float rw;
            float rh;
            if (na > viewAr) {
                rw = vw;
                rh = vw / na;
            } else {
                rh = vh;
                rw = vh * na;
            }
            rw *= zoom;
            rh *= zoom;
            transform.reset();
            transform.setScale(rw / vw, rh / vh, vw / 2f, vh / 2f);
            transform.postRotate(userRotate, vw / 2f, vh / 2f);
        }
        // 用户翻转 / 镜像
        if (flip == 1) {
            transform.postScale(-1, 1, vw / 2f, vh / 2f);
        } else if (flip == 2) {
            transform.postScale(1, -1, vw / 2f, vh / 2f);
        } else if (flip == 3) {
            transform.postRotate(180, vw / 2f, vh / 2f);
        }
        textureView.setTransform(transform);
    }

    public TextureView view() {
        return textureView;
    }
}
