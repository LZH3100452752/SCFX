package com.shichen.player;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;

import java.util.List;

public class SubtitleView extends View {
    private List<SubtitleParser.Cue> cues;
    private long position;
    private TextPaint paint;
    private float sizeSp = 16;
    private int color = Color.WHITE;
    private int delayMs = 0;
    private int bottomMarginPx = 0;
    private int outlinePx = 2;

    public SubtitleView(Context c) {
        super(c);
        init();
    }

    public SubtitleView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    public SubtitleView(Context c, AttributeSet a, int s) {
        super(c, a, s);
        init();
    }

    private void init() {
        paint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(color);
        paint.setTextSize(sizeSp * getResources().getDisplayMetrics().scaledDensity);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextAlign(Paint.Align.CENTER);
        setWillNotDraw(false);
    }

    public void setCues(List<SubtitleParser.Cue> c) {
        cues = c;
        invalidate();
    }

    public void setPosition(long ms) {
        position = ms;
        invalidate();
    }

    public void setSizeSp(int sp) {
        sizeSp = sp;
        paint.setTextSize(sizeSp * getResources().getDisplayMetrics().scaledDensity);
        invalidate();
    }

    public void setColor(int c) {
        color = c;
        paint.setColor(c);
        invalidate();
    }

    public void setDelayMs(int d) {
        delayMs = d;
        invalidate();
    }

    /** 字幕描边粗细（px）：用阴影模拟，稳定可靠 */
    public void setOutline(int px) {
        outlinePx = px;
        if (outlinePx <= 0) {
            if (paint != null) {
                paint.setShadowLayer(0, 0, 0, Color.TRANSPARENT);
            }
        } else {
            if (paint != null) {
                paint.setShadowLayer(outlinePx, 0, 0, 0xCC000000);
            }
        }
        invalidate();
    }

    public void setBottomMargin(int px) {
        bottomMarginPx = px;
        invalidate();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (cues == null || cues.isEmpty()) {
            return;
        }
        int idx = SubtitleParser.indexAt(cues, position - delayMs);
        if (idx < 0) {
            return;
        }
        String text = cues.get(idx).text;
        if (text == null || text.length() == 0) {
            return;
        }
        int w = getWidth() - (int) (24 * getResources().getDisplayMetrics().density);
        if (w <= 0) {
            return;
        }
        StaticLayout sl = new StaticLayout(text, paint, w, Layout.Alignment.ALIGN_CENTER, 1.2f, 0f, true);
        int h = sl.getHeight();
        int pad = (int) (10 * getResources().getDisplayMetrics().density);
        int left = (getWidth() - w) / 2;
        int top = getHeight() - h - pad - bottomMarginPx;
        if (top < 0) {
            top = 0;
        }
        canvas.save();
        canvas.translate(left, top);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(Color.argb(200, 0, 0, 0));
        paint.setShadowLayer(6f, 0, 0, Color.BLACK);
        sl.draw(canvas);
        paint.setShadowLayer(0, 0, 0, Color.TRANSPARENT);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        sl.draw(canvas);
        canvas.restore();
    }
}
