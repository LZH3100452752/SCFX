package com.shichen.player;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SubtitleParser {

    public static class Cue {
        public long start;
        public long end;
        public String text;

        public Cue(long s, long e, String t) {
            start = s;
            end = e;
            text = t;
        }
    }

    private static final Pattern TIME = Pattern.compile("(\\d+):(\\d+):(\\d+)[,.](\\d+)");

    public static List<Cue> parse(InputStream in, String name) {
        String lower = (name == null ? "" : name).toLowerCase(Locale.US);
        try {
            if (lower.endsWith(".ass") || lower.endsWith(".ssa")) {
                return parseAss(in);
            }
            if (lower.endsWith(".lrc")) {
                return parseLrc(in);
            }
            return parseSrt(in);
        } catch (Exception e) {
            return new ArrayList<Cue>();
        }
    }

    private static long toMs(String s) {
        Matcher m = TIME.matcher(s);
        if (m.find()) {
            long h = Long.parseLong(m.group(1));
            long mi = Long.parseLong(m.group(2));
            long se = Long.parseLong(m.group(3));
            String ms = m.group(4);
            while (ms.length() < 3) {
                ms += "0";
            }
            long msec = Long.parseLong(ms.substring(0, 3));
            return h * 3600000L + mi * 60000L + se * 1000L + msec;
        }
        return 0;
    }

    private static List<Cue> parseSrt(InputStream in) throws Exception {
        List<Cue> cues = new ArrayList<Cue>();
        BufferedReader r = new BufferedReader(new InputStreamReader(in, detect(in)));
        String line;
        StringBuilder text = new StringBuilder();
        long start = -1, end = -1;
        while ((line = r.readLine()) != null) {
            line = line.replace("\uFEFF", "").trim();
            if (line.length() == 0) {
                if (start >= 0 && text.length() > 0) {
                    cues.add(new Cue(start, end, text.toString().trim()));
                }
                start = -1;
                end = -1;
                text.setLength(0);
                continue;
            }
            if (start < 0 && line.contains("-->")) {
                String[] p = line.split("-->");
                if (p.length >= 2) {
                    start = toMs(p[0]);
                    end = toMs(p[1]);
                }
                continue;
            }
            if (start >= 0) {
                if (text.length() > 0) {
                    text.append("\n");
                }
                text.append(clean(line));
            }
        }
        if (start >= 0 && text.length() > 0) {
            cues.add(new Cue(start, end, text.toString().trim()));
        }
        r.close();
        return cues;
    }

    private static List<Cue> parseAss(InputStream in) throws Exception {
        List<Cue> cues = new ArrayList<Cue>();
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        String line;
        while ((line = r.readLine()) != null) {
            line = line.trim();
            if (!line.startsWith("Dialogue:")) {
                continue;
            }
            String[] p = line.split(",", 10);
            if (p.length < 10) {
                continue;
            }
            long start = toMs(p[1]);
            long end = toMs(p[2]);
            String txt = clean(p[9].replace("\\N", "\n").replace("\\n", "\n"));
            if (txt.length() > 0) {
                cues.add(new Cue(start, end, txt));
            }
        }
        r.close();
        Collections.sort(cues, new Comparator<Cue>() {
            public int compare(Cue a, Cue b) {
                return a.start < b.start ? -1 : (a.start > b.start ? 1 : 0);
            }
        });
        return cues;
    }

    private static List<Cue> parseLrc(InputStream in) throws Exception {
        List<Cue> cues = new ArrayList<Cue>();
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        Pattern p = Pattern.compile("\\[(\\d+):(\\d+)(?:[.,](\\d+))?\\]");
        String line;
        List<long[]> times = new ArrayList<long[]>();
        while ((line = r.readLine()) != null) {
            Matcher m = p.matcher(line);
            times.clear();
            int last = 0;
            while (m.find()) {
                long mi = Long.parseLong(m.group(1));
                long se = Long.parseLong(m.group(2));
                long ms = m.group(3) == null ? 0 : Long.parseLong(m.group(3));
                times.add(new long[]{mi * 60000L + se * 1000L + ms, 0});
                last = m.end();
            }
            if (times.isEmpty()) {
                continue;
            }
            String txt = clean(line.substring(Math.min(last, line.length())));
            if (txt.length() == 0) {
                continue;
            }
            for (int i = 0; i < times.size(); i++) {
                long st = times.get(i)[0];
                long en = i + 1 < times.size() ? times.get(i + 1)[0] : st + 5000;
                cues.add(new Cue(st, en, txt));
            }
        }
        r.close();
        Collections.sort(cues, new Comparator<Cue>() {
            public int compare(Cue a, Cue b) {
                return a.start < b.start ? -1 : (a.start > b.start ? 1 : 0);
            }
        });
        return cues;
    }

    private static String clean(String s) {
        return s.replaceAll("\\{[^}]*\\}", "")
                .replaceAll("<[^>]*>", "")
                .replace("&nbsp;", " ")
                .trim();
    }

    private static String detect(InputStream in) {
        return "UTF-8";
    }

    public static int indexAt(List<Cue> cues, long ms) {
        if (cues == null || cues.isEmpty()) {
            return -1;
        }
        int lo = 0, hi = cues.size() - 1, res = -1;
        while (lo <= hi) {
            int mid = (lo + hi) / 2;
            Cue c = cues.get(mid);
            if (c.start <= ms && ms < c.end) {
                return mid;
            }
            if (c.start > ms) {
                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        }
        return res;
    }
}
