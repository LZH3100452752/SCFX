package com.shichen.player;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** 细长进度条：静止 2dp 细线，拖动时加粗到 4dp 并放大滑块 */
public class SlimSeekBar extends View {

    private int max = 1000;
    private int progress = 0;
    private int secondary = 0;
    private boolean dragging = false;
    private boolean enabled = true;

    private Paint pBg, pSec, pPro, pThumb;
    private int accent, accent2;
    private float density;
    private OnSeekListener listener;
    private float anim = 0f;   // 0=细 1=粗

    public interface OnSeekListener {
        void onProgressChanged(int progress, boolean fromUser);

        void onStart(int progress);

        void onStop(int progress);
    }

    public SlimSeekBar(Context c) {
        super(c);
        init(c);
    }

    public SlimSeekBar(Context c, AttributeSet a) {
        super(c, a);
        init(c);
    }

    private void init(Context c) {
        density = c.getResources().getDisplayMetrics().density;
        accent = ThemeEngine.accent(c);
        accent2 = ThemeEngine.attr(c, R.attr.scAccent2);
        pBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        pBg.setColor(0x33FFFFFF);
        pSec = new Paint(Paint.ANTI_ALIAS_FLAG);
        pSec.setColor(0x66FFFFFF);
        pPro = new Paint(Paint.ANTI_ALIAS_FLAG);
        pThumb = new Paint(Paint.ANTI_ALIAS_FLAG);
        pThumb.setColor(0xFFFFFFFF);
    }

    public void setAccent(int a, int a2) {
        accent = a;
        accent2 = a2;
        invalidate();
    }

    public void setOnSeekListener(OnSeekListener l) {
        listener = l;
    }

    public void setMax(int m) {
        max = m > 0 ? m : 1;
        invalidate();
    }

    public void setProgress(int p) {
        progress = Math.max(0, Math.min(max, p));
        invalidate();
    }

    public void setSecondaryProgress(int p) {
        secondary = Math.max(0, Math.min(max, p));
        invalidate();
    }

    public int getProgress() {
        return progress;
    }

    public int getMax() {
        return max;
    }

    public void setSeekEnabled(boolean e) {
        enabled = e;
        invalidate();
    }

    protected void onMeasure(int wSpec, int hSpec) {
        // 触摸区加高：手指上下微移也不会滑出，避免拖动被打断导致进度回弹
        int h = (int) (30 * density);
        setMeasuredDimension(resolveSize((int) (200 * density), wSpec), resolveSize(h, hSpec));
    }

    protected void onDraw(Canvas c) {
        int w = getWidth();
        int h = getHeight();
        float cy = h / 2f;
        float barH = (2 + 2 * anim) * density;
        float inset = (6 + 4 * anim) * density;
        float left = inset;
        float right = w - inset;
        float trackW = right - left;
        if (trackW <= 0) {
            return;
        }
        float r = barH / 2f;

        c.drawRoundRect(new RectF(left, cy - barH / 2, right, cy + barH / 2), r, r, pBg);
        if (secondary > 0) {
            float sx = left + trackW * secondary / (float) max;
            c.drawRoundRect(new RectF(left, cy - barH / 2, sx, cy + barH / 2), r, r, pSec);
        }
        float px = left + trackW * progress / (float) max;
        pPro.setColor(enabled ? accent : 0x88FFFFFF);
        c.drawRoundRect(new RectF(left, cy - barH / 2, px, cy + barH / 2), r, r, pPro);

        if (enabled) {
            float tr = (4 + 4 * anim) * density;
            pThumb.setColor(accent2);
            c.drawCircle(px, cy, tr, pThumb);
            pThumb.setColor(0xFFFFFFFF);
            c.drawCircle(px, cy, tr * 0.45f, pThumb);
        }
    }

    private float lastX;

    public boolean onTouchEvent(MotionEvent e) {
        if (!enabled) {
            return false;
        }
        int w = getWidth();
        if (w <= 0) {
            return false;
        }
        float inset = (6 + 4 * anim) * density;
        float trackW = w - inset * 2;
        float x = Math.max(inset, Math.min(w - inset, e.getX()));
        int p = (int) ((x - inset) / trackW * max);
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                lastX = x;
                getParent().requestDisallowInterceptTouchEvent(true);
                anim = 1f;
                invalidate();
                if (listener != null) {
                    listener.onStart(p);
                }
                setProgress(p);
                if (listener != null) {
                    listener.onProgressChanged(p, true);
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (Math.abs(x - lastX) > 0.3f) {
                    lastX = x;
                    setProgress(p);
                    if (listener != null) {
                        listener.onProgressChanged(p, true);
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                anim = 0f;
                setProgress(p);
                invalidate();
                if (listener != null) {
                    // 只回调 onStop：再触发一次 onProgressChanged 会造成重复 seek
                    listener.onStop(p);
                }
                return true;
        }
        return true;
    }

    public boolean isDragging() {
        return dragging;
    }
}
