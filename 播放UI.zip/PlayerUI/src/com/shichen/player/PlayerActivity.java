package com.shichen.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Rational;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class PlayerActivity extends Activity implements PlayerEngine.Callback,
        PlaySettingsPanel.PlayControl {

    private FrameLayout root;
    private FrameLayout surfaceContainer;
    private View gestureLayer;
    private View topBar;
    private View bottomBar;
    private View hint;
    private SubtitleView subtitleView;
    private TextView titleView, pathView, timeCur, timeTotal, boostHint;
    private SlimSeekBar seek;
    private ImageButton btnPlay, btnLock, btnUnlock, btnFullscreen, btnAb, btnFav;
    private ImageButton btnRepeat, btnEq, btnTrack, btnSubtitle;
    private TextView btnSpeed;
    private ImageButton btnAspect, btnPip;
    private SeekPreview seekPreview;
    private ProgressBar loading, hintBar;
    private android.widget.ImageView hintIcon;
    private TextView hintText;

    private Surface surface;
    private VideoRenderView renderView;
    private PlaylistPanel playlistPanel;
    private AlertDialog currentPanel;
    private View statusOverlay;
    private TextView statusLeft, statusRight;
    private BroadcastReceiver batteryReceiver;

    private PlayerEngine engine;
    private int engineMode;
    private DbHelper db;
    private Handler main = new Handler(Looper.getMainLooper());
    private AudioManager am;

    private String path = "";
    private String title = "";
    private ArrayList<String> playlist = new ArrayList<String>();
    private int index = -1;

    private long duration = 0;
    private boolean prepared = false;
    private boolean userSeeking = false;
    /** 松手后目标位置；引擎位置未追上前不回写进度条，避免"拖过去又弹回" */
    private long pendingSeekMs = -1;
    private long pendingSeekAt = 0;
    /** 正在拖动进度条：期间禁止控制条自动隐藏，否则拖动会被打断并回弹 */
    private boolean seekDragging = false;
    private boolean locked = false;
    private boolean controlsVisible = false;
    private float speed = 1.0f;
    private int videoW = 0, videoH = 0, rotation = 0;
    private int ratio;
    private long resumePos = 0;
    private boolean waitingSurface = false;
    private long pendingStartMs = 0;
    private long lastProgressSave = 0;

    private long abA = -1, abB = -1;
    private int repeatMode;
    private long sleepAt = 0;
    private float zoomScale = 1.0f;

    private List<SubtitleParser.Cue> cues;
    private boolean subtitleOn;
    private boolean isFav = false;

    private GestureDetector detector;
    private ScaleGestureDetector scaleDetector;
    private float startX, startY;
    private long seekStart;
    private int gestureMode = 0;   // 0 none 1 seek 2 bright 3 volume
    private int screenW, screenH;
    private long pendingSeek = 0;
    private float gestureBase = 0f;
    private TextView btnRestart;
    private volatile boolean released = false;
    private Runnable longPressRun;
    private boolean boosting = false;
    private float savedSpeed = 1.0f;

    protected void onCreate(Bundle b) {
        Diagnostics.clear();
        Diagnostics.log("boot", "onCreate start");
        setTheme(ThemeEngine.playerThemeRes(this));
        super.onCreate(b);
        try {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        applyImmersive();
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        setContentView(R.layout.activity_player);
        db = new DbHelper(this);
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        bindViews();
        parseIntent();
        speed = Prefs.defaultSpeed(this);
        ratio = Prefs.defaultRatio(this);
        subtitleOn = Prefs.subtitleOn(this);
        repeatMode = Prefs.repeatMode(this);
        createSurfaceView();
        applyOrientation();
        setupControls();
        setupGestures();
        engineMode = Prefs.decodeMode(this);
        // 等渲染视图 attach 到窗口后再打开，确保 SurfaceTexture 已就绪
        surfaceContainer.post(new Runnable() {
            public void run() {
                if (!released) {
                    open(Prefs.rememberPos(PlayerActivity.this) ? resumePos : 0);
                }
            }
        });
        main.post(updateRunnable);
        // Android 13(API 33)+ 动态注册广播必须显式声明是否导出，
        // 否则直接抛 SecurityException 导致 Activity 在 onCreate 阶段崩溃
        // —— 表现就是"一进去就黑屏、按键无响应"。
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(headsetReceiver,
                        new IntentFilter(Intent.ACTION_HEADSET_PLUG),
                        Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(headsetReceiver,
                        new IntentFilter(Intent.ACTION_HEADSET_PLUG));
            }
            Diagnostics.log("boot", "headset receiver ok");
        } catch (Throwable t) {
            Diagnostics.err("boot", t);
        }
        } catch (Throwable t) {
            Diagnostics.err("boot", t);
            showFatal(t);
            return;
        }
        Diagnostics.log("boot", "onCreate done");
    }

    /** 致命错误时显示醒目的红色覆盖层，避免只剩黑屏无从判断 */
    private void showFatal(Throwable t) {
        try {
            TextView tv = new TextView(this);
            tv.setTextColor(0xFFFFFFFF);
            tv.setBackgroundColor(0xCCB00020);
            tv.setTextSize(12f);
            tv.setPadding(24, 24, 24, 24);
            tv.setText("播放界面启动失败：" + t.getClass().getSimpleName() + " / " + String.valueOf(t.getMessage()) + "  [点此导出诊断报告]");
            tv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String p = Diagnostics.export(PlayerActivity.this);
                    Ui.toast(PlayerActivity.this, p == null ? "导出失败" : "已导出：" + p);
                }
            });
            addContentView(tv, new android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT));
        } catch (Exception ignored) {
        }
    }

    /** 沉浸式全屏：隐藏状态栏与导航栏，播放时默认进入 */
    private void applyImmersive() {
        try {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        } catch (Exception ignored) {
        }
        // 完整全屏：内容延伸到刘海/挖孔区域，不做避让
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                getWindow().setAttributes(lp);
            }
        } catch (Exception ignored) {
        }
    }

    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applyImmersive();
        }
    }

    /** 顶部状态显示：左侧视频时长，右侧电量与时间 */
    private void applyStatusOverlay() {
        if (statusOverlay == null) {
            return;
        }
        if (!Prefs.statusOverlay(this)) {
            statusOverlay.setVisibility(View.GONE);
            return;
        }
        if (Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode()) {
            statusOverlay.setVisibility(View.GONE);
            return;
        }
        statusOverlay.setVisibility(View.VISIBLE);
        float dm = getResources().getDisplayMetrics().density;
        int ix = Math.round(Prefs.statusInsetX(this) * dm);
        int iy = Math.round(Prefs.statusInsetY(this) * dm);
        // 用 margin 并强制重新布局。中间是 weight=1 的弹性 spacer，
        // 两侧同时内缩时 spacer 会被压缩到 0，两个胶囊可以一直靠到挨在一起。
        statusOverlay.setPadding(0, iy, 0, 0);
        if (statusLeft != null) {
            LinearLayout.LayoutParams lp =
                    (LinearLayout.LayoutParams) statusLeft.getLayoutParams();
            lp.leftMargin = ix;
            lp.rightMargin = 0;
            lp.weight = 0;
            statusLeft.setLayoutParams(lp);
        }
        if (statusRight != null) {
            LinearLayout.LayoutParams lp =
                    (LinearLayout.LayoutParams) statusRight.getLayoutParams();
            lp.rightMargin = ix;
            lp.leftMargin = 0;
            lp.weight = 0;
            statusRight.setLayoutParams(lp);
        }
        statusOverlay.requestLayout();
        updateStatusLeft();
        updateStatusRight();
    }

    private void updateStatusLeft() {
        if (statusLeft == null) {
            return;
        }
        long pos = engine == null ? 0 : engine.position();
        switch (Prefs.statusLeftMode(this)) {
            case 0:
                statusLeft.setText(MediaUtils.formatDuration(duration));
                break;
            case 1:
                statusLeft.setText("-" + MediaUtils.formatDuration(
                        Math.max(0, duration - pos)));
                break;
            default:
                statusLeft.setText(MediaUtils.formatDuration(pos) + " / "
                        + MediaUtils.formatDuration(duration));
                break;
        }
    }

    private void updateStatusRight() {
        if (statusRight == null) {
            return;
        }
        int mode = Prefs.statusRightMode(this);
        String t = new java.text.SimpleDateFormat("HH:mm",
                java.util.Locale.getDefault()).format(new java.util.Date());
        if (mode == 1) {
            statusRight.setText(batteryText());
        } else if (mode == 2) {
            statusRight.setText(t);
        } else {
            statusRight.setText(batteryText() + "  " + t);
        }
    }

    private int batteryPct = 100;

    private String batteryText() {
        return batteryPct + "%";
    }

    private void registerBattery() {
        try {
            IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            batteryReceiver = new BroadcastReceiver() {
                public void onReceive(Context c, Intent i) {
                    int level = i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
                    int scale = i.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1);
                    if (level >= 0 && scale > 0) {
                        batteryPct = level * 100 / scale;
                        updateStatusRight();
                    }
                }
            };
            android.content.Intent sticky = registerReceiver(batteryReceiver, f);
            if (sticky != null) {
                batteryReceiver.onReceive(this, sticky);
            }
        } catch (Exception ignored) {
        }
    }

    private void bindViews() {
        root = (FrameLayout) findViewById(R.id.root);
        surfaceContainer = (FrameLayout) findViewById(R.id.surface_container);
        gestureLayer = findViewById(R.id.gesture_layer);
        topBar = findViewById(R.id.top_bar);
        bottomBar = findViewById(R.id.bottom_bar);
        hint = findViewById(R.id.hint);
        hintIcon = (android.widget.ImageView) findViewById(R.id.hint_icon);
        hintText = (TextView) findViewById(R.id.hint_text);
        hintBar = (ProgressBar) findViewById(R.id.hint_bar);
        subtitleView = (SubtitleView) findViewById(R.id.subtitle_view);
        titleView = (TextView) findViewById(R.id.title);
        pathView = (TextView) findViewById(R.id.subtitle_path);
        timeCur = (TextView) findViewById(R.id.time_cur);
        timeTotal = (TextView) findViewById(R.id.time_total);
        seek = (SlimSeekBar) findViewById(R.id.seek);
        btnPlay = (ImageButton) findViewById(R.id.btn_play);
        btnLock = (ImageButton) findViewById(R.id.btn_lock);
        btnUnlock = (ImageButton) findViewById(R.id.btn_unlock);
        btnFullscreen = (ImageButton) findViewById(R.id.btn_fullscreen);
        btnAb = (ImageButton) findViewById(R.id.btn_ab);
        btnFav = (ImageButton) findViewById(R.id.btn_fav);
        btnRepeat = (ImageButton) findViewById(R.id.btn_repeat);
        btnEq = (ImageButton) findViewById(R.id.btn_eq);
        btnTrack = (ImageButton) findViewById(R.id.btn_track);
        ImageButton btnPlaylist = (ImageButton) findViewById(R.id.btn_playlist);
        if (btnPlaylist != null) {
            btnPlaylist.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    showPlaylist();
                }
            });
        }
        btnSubtitle = (ImageButton) findViewById(R.id.btn_subtitle);
        ImageButton btnSet = (ImageButton) findViewById(R.id.btn_settings);
        if (btnSet != null) {
            btnSet.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    openTools();
                }
            });
        }
        if (seek != null) {
            seek.setAccent(ThemeEngine.accent(PlayerActivity.this),
                    ThemeEngine.attr(PlayerActivity.this, R.attr.scAccent2));
        }
        loading = (ProgressBar) findViewById(R.id.loading);
        boostHint = (TextView) findViewById(R.id.boost_hint);
        btnRestart = (TextView) findViewById(R.id.btn_restart);
        if (btnRestart != null) {
            // 半透明深色底 + 明亮蓝字：低调但看得清
            btnRestart.setBackgroundResource(R.drawable.bg_restart_btn);
            btnRestart.setTextColor(0xFF7FD0FF);
            btnRestart.setAlpha(0.92f);
            btnRestart.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    restartFromStart();
                }
            });
        }
        statusOverlay = findViewById(R.id.status_overlay);
        statusLeft = (TextView) findViewById(R.id.status_left);
        statusRight = (TextView) findViewById(R.id.status_right);
        applyStatusOverlay();
        registerBattery();
        rebuildActionBar();
        seekPreview = (SeekPreview) findViewById(R.id.seek_preview);
        measureScreen();
    }

    private void measureScreen() {
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
    }

    private void parseIntent() {
        Intent i = getIntent();
        path = i.getStringExtra("path");
        title = i.getStringExtra("title");
        ArrayList<String> l = i.getStringArrayListExtra("list");
        if (l != null && !l.isEmpty()) {
            playlist = l;
        }
        if ((path == null || path.length() == 0) && i.getData() != null) {
            Uri u = i.getData();
            if ("file".equals(u.getScheme()) && u.getPath() != null) {
                path = u.getPath();
            } else {
                path = u.toString();
            }
        }
        if ((path == null || path.length() == 0) && !playlist.isEmpty()) {
            path = playlist.get(0);
        }
        if (path == null) {
            path = "";
        }
        if (title == null || title.length() == 0) {
            int k = path.lastIndexOf('/');
            title = k >= 0 ? path.substring(k + 1) : path;
        }
        if (!playlist.contains(path)) {
            playlist.add(0, path);
        }
        index = playlist.indexOf(path);
        titleView.setText(title);
        if (pathView != null) {
            pathView.setText(path);
        }

        VideoItem saved = db.find(path);
        isFav = saved != null && saved.fav;
        updateFavIcon();
        if (saved != null && Prefs.rememberPos(this) && saved.duration > 10000
                && saved.position > 3000 && saved.position < saved.duration - 5000) {
            resumePos = saved.position;

        }
    }



    /* ==================== 屏幕方向 ==================== */
    private void applyOrientation() {
        switch (Prefs.orientation(this)) {
            case Prefs.O_AUTO:
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
                break;
            case Prefs.O_LANDSCAPE:
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                break;
            case Prefs.O_PORTRAIT:
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                break;
            case Prefs.O_SYSTEM:
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                break;
            default:
                setRequestedOrientation(videoLandscape()
                        ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                break;
        }
    }

    private boolean videoLandscape() {
        int w = videoW, h = videoH;
        if (rotation == 90 || rotation == 270) {
            int t = w;
            w = h;
            h = t;
        }
        return w > h;
    }

    private void toggleFullscreen() {
        int o = getResources().getConfiguration().orientation;
        if (o == Configuration.ORIENTATION_LANDSCAPE) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        }
    }

    /* ==================== Surface ==================== */
    /**
     * 创建渲染视图。
     * 容器与视图尺寸全程保持不变，画面比例与缩放由 VideoRenderView 内部
     * 的 Matrix 完成。切勿在此处或切换比例时改变容器尺寸，否则 surface
     * 会被销毁重建，解码器绑定失效 —— 这正是此前持续黑屏的根因。
     */
    private void createSurfaceView() {
        final int kind = Prefs.renderKind(PlayerActivity.this);
        Diagnostics.log("render", "create kind=" + kind);
        renderView = new VideoRenderView(surfaceContainer,
                new VideoRenderView.SurfaceHolder() {
            public void onSurfaceReady(android.view.Surface sf) {
                pageSurface = sf;
                Diagnostics.log("render", "page surface ready");
                if (useFloat) {
                    // 正在投到悬浮窗：不要把画面抢回播放页，否则小窗会黑屏
                    return;
                }
                surface = sf;
                if (waitingSurface) {
                    open(pendingStartMs);
                } else if (engine != null) {
                    engine.setSurface(surface);
                }
                if (videoW > 0) {
                    renderView.setVideoSize(videoW, videoH, rotation);
                }
            }

            public void onSurfaceDestroyed() {
                pageSurface = null;
                if (!useFloat) {
                    surface = null;
                }
            }
        }, kind);
        renderView.setHighQuality(Prefs.renderMode(PlayerActivity.this) == Prefs.RENDER_TEXTURE);
        renderView.setRatio(ratio);
        renderView.setZoom(zoomScale);
    }

    /* ==================== 控件 ==================== */
    private void setupControls() {
        onClick(R.id.btn_back, new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        if (btnPlay != null) {
            btnPlay.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    togglePlay();
                }
            });
        }
        onClick(R.id.btn_prev, new View.OnClickListener() {
            public void onClick(View v) {
                playOffset(-1);
            }
        });
        onClick(R.id.btn_next, new View.OnClickListener() {
            public void onClick(View v) {
                playOffset(1);
            }
        });
        onClick(R.id.btn_rew, new View.OnClickListener() {
            public void onClick(View v) {
                seekDelta(-Prefs.skipSec(PlayerActivity.this) * 1000);
            }
        });
        onClick(R.id.btn_ff, new View.OnClickListener() {
            public void onClick(View v) {
                seekDelta(Prefs.skipSec(PlayerActivity.this) * 1000);
            }
        });
        if (btnSpeed != null) {
            btnSpeed.setText(MediaUtils.formatSpeed(speed));
            btnSpeed.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    showSpeedPanel();
                }
            });
        }
        if (btnAb != null) {
            btnAb.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    toggleAb();
                }
            });
        }
        if (btnFav != null) {
            btnFav.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    isFav = !isFav;
                    db.setFav(path, isFav);
                    updateFavIcon();
                    Ui.toast(PlayerActivity.this, isFav ? "已收藏" : "已取消收藏");
                }
            });
        }
        if (btnRepeat != null) {
            btnRepeat.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    repeatMode = (repeatMode + 1) % 3;
                    Prefs.setRepeatMode(PlayerActivity.this, repeatMode);
                    updateRepeatIcon();
                    Ui.toast(PlayerActivity.this, SettingsPage.repeatName(repeatMode));
                }
            });
        }
        updateRepeatIcon();
        if (btnEq != null) {
            btnEq.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    openEqualizer();
                }
            });
        }
        if (btnTrack != null) {
            btnTrack.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    showTracks();
                }
            });
        }
        if (btnSubtitle != null) {
            btnSubtitle.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    showSubtitleMenu();
                }
            });
        }
        if (btnFullscreen != null) {
            btnFullscreen.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    toggleFullscreen();
                }
            });
        }
        if (btnLock != null) {
            btnLock.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    setLocked(true);
                }
            });
        }
        if (btnUnlock != null) {
            btnUnlock.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    setLocked(false);
                }
            });
        }
        if (seek != null) {
            seek.setOnSeekListener(new SlimSeekBar.OnSeekListener() {
                public void onProgressChanged(int p, boolean fromUser) {
                    if (fromUser && duration > 0) {
                        long ms = p * duration / 1000;
                        timeCur.setText(MediaUtils.formatDuration(ms));
                        showSeekPreview(p, ms);
                        // 实时跳转：拖动过程中画面跟着走（带最小间隔节流，避免拖垮解码器）
                        realtimeSeek(ms);
                    }
                }

                public void onStart(int p) {
                    userSeeking = true;
                    seekDragging = true;
                    // 拖动期间保持控制条常亮：一旦自动隐藏，seek 会被移除，
                    // 后续 MOVE/UP 丢失，进度条就会跳回旧位置
                    keepControls();
                    cancelHidePreview();
                    if (duration > 0) {
                        showSeekPreview(p, p * duration / 1000);
                    }
                }

                public void onStop(int p) {
                    userSeeking = false;
                    seekDragging = false;
                    hideSeekPreview();
                    scheduleHideControls();
                    if (engine != null && duration > 0) {
                        long target = p * duration / 1000;
                        pendingSeekMs = target;
                        pendingSeekAt = System.nanoTime();
                        lastSeekNano = 0;
                        engine.seekTo(target);
                        // 立即把进度条与时间钉在目标位置，不让它先跳回旧值
                        if (seek != null) {
                            seek.setProgress(p);
                        }
                        timeCur.setText(MediaUtils.formatDuration(target));
                    }
                }
            });
        }
        // 长按进度条进入精调：显示预览但不立即跳转
        seek.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                if (duration <= 0) {
                    return false;
                }
                fineSeek = !fineSeek;
                Ui.toast(PlayerActivity.this,
                        fineSeek ? "精调模式：开（拖动更细腻）" : "精调模式：关");
                return true;
            }
        });
        subtitleView.setSizeSp(Prefs.subtitleSize(this));
        subtitleView.setOutline(Prefs.subtitleOutline(this));
        subtitleView.setBottomMargin(Prefs.subtitleBottom(this));
        subtitleView.setDelayMs(Prefs.subtitleDelay(this));
        subtitleView.setColor(subtitleColor());
        setControlsVisible(false);
    }

    private volatile boolean fineSeek = false;
    private long lastSeekNano = 0;

    /**
     * 拖动进度条时实时跳转，画面随手指即时更新。
     * 用最小间隔节流（约 70ms），既保证跟手又不让解码器被 seek 淹没。
     */
    private void realtimeSeek(long ms) {
        if (engine == null || duration <= 0) {
            return;
        }
        long now = System.nanoTime();
        if (now - lastSeekNano < 45000000L) {
            return;
        }
        lastSeekNano = now;
        try {
            engine.seekTo(ms);
        } catch (Exception ignored) {
        }
    }
    private long lastPreviewMs = -1;
    private Runnable hidePreviewRun;

    private void showSeekPreview(int progress, long ms) {
        if (seekPreview == null || duration <= 0) {
            return;
        }
        long bucket = fineSeek ? ms : (ms / 1000) * 1000;
        if (bucket == lastPreviewMs) {
            updatePreviewPos(progress);
            return;
        }
        lastPreviewMs = bucket;
        final long target = ms;
        final int prog = progress;
        int[] loc = new int[2];
        seek.getLocationOnScreen(loc);
        int x = loc[0] + (int) (seek.getWidth() * (progress / 1000f));
        updatePreviewPos(prog);
        new Thread(new Runnable() {
            public void run() {
                final android.graphics.Bitmap bm = ThumbLoader.frameAt(path, target);
                main.post(new Runnable() {
                    public void run() {
                        if (seekPreview == null || !userSeeking) {
                            return;
                        }
                        seekPreview.show(bm, MediaUtils.formatDuration(target), previewX, screenW);
                    }
                });
            }
        }).start();
    }

    private int previewX = 0;

    private void updatePreviewPos(int progress) {
        int[] loc = new int[2];
        seek.getLocationOnScreen(loc);
        previewX = loc[0] + (int) (seek.getWidth() * (progress / 1000f));
        if (seekPreview != null && userSeeking) {
            seekPreview.show(null, MediaUtils.formatDuration(progress * duration / 1000),
                    previewX, screenW);
        }
    }

    private void hideSeekPreview() {
        lastPreviewMs = -1;
        if (seekPreview != null) {
            seekPreview.hide();
        }
    }

    private void cancelHidePreview() {
        if (hidePreviewRun != null) {
            main.removeCallbacks(hidePreviewRun);
        }
    }

    private int subtitleColor() {
        switch (Prefs.subtitleColor(this)) {
            case 1:
                return Color.parseColor("#FFFFE066");
            case 2:
                return Color.parseColor("#FF5CE1FF");
            case 3:
                return Color.parseColor("#FF7BE495");
            case 4:
                return Color.parseColor("#FFFF9EC4");
            default:
                return Color.WHITE;
        }
    }

    private void updateFavIcon() {
        if (btnFav == null) {
            return;
        }
        btnFav.setImageResource(isFav ? R.drawable.ic_fav_filled : R.drawable.ic_fav);
        if (isFav) {
            btnFav.setColorFilter(Color.parseColor("#FFFF5C8A"));
        } else {
            btnFav.clearColorFilter();
        }
    }

    /** 分享当前视频 */
    public void shareCurrent() {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("video/*");
            java.io.File f = new java.io.File(path);
            android.net.Uri u = android.net.Uri.fromFile(f);
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "分享视频"));
        } catch (Exception e) {
            Ui.toast(this, "无法分享该文件");
        }
    }

    /** 重新扫描视频库 */
    public void rescanLibrary() {
        try {
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                    android.net.Uri.fromFile(new java.io.File(path))));
            Ui.toast(this, "已触发重新扫描");
        } catch (Exception ignored) {
        }
    }

    /** 跳转到指定毫秒 */
    public void seekToMs(long ms) {
        if (engine != null && duration > 0) {
            if (ms > duration) {
                ms = duration;
            }
            engine.seekTo(ms);
        }
    }















    public void updateRepeatIcon() {

        if (btnRepeat == null) {
            return;
        }
        switch (repeatMode) {
            case Prefs.REPEAT_ONE:
                btnRepeat.setImageResource(R.drawable.ic_repeat_one);
                btnRepeat.setAlpha(1f);
                break;
            case Prefs.REPEAT_ALL:
                btnRepeat.setImageResource(R.drawable.ic_repeat);
                btnRepeat.setAlpha(1f);
                break;
            default:
                btnRepeat.setImageResource(R.drawable.ic_repeat);
                btnRepeat.setAlpha(0.5f);
                break;
        }
    }

    /* ==================== 手势 ==================== */
    private void setupGestures() {
        detector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            public boolean onDoubleTap(MotionEvent e) {
                boolean dtOk = !locked || Prefs.lockDoubleTap(PlayerActivity.this);
                if (Prefs.gDoubleTap(PlayerActivity.this) && dtOk) {
                    togglePlay();
                    return true;
                }
                return false;
            }

            public boolean onSingleTapConfirmed(MotionEvent e) {
                // 锁定状态下点击屏幕也要显示控制条，否则解锁按钮永远看不到
                toggleControls();
                return true;
            }
        });
        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            public boolean onScale(ScaleGestureDetector d) {
                if (!Prefs.gZoom(PlayerActivity.this)) {
                    return false;
                }
                if (locked && !Prefs.lockZoom(PlayerActivity.this)) {
                    return false;
                }
                zoomScale *= d.getScaleFactor();
                if (zoomScale < 0.5f) {
                    zoomScale = 0.5f;
                }
                if (zoomScale > 5f) {
                    zoomScale = 5f;
                }
                applyZoom();
                return true;
            }

            public boolean onScaleBegin(ScaleGestureDetector d) {
                if (!Prefs.gZoom(PlayerActivity.this)) {
                    return false;
                }
                return !locked || Prefs.lockZoom(PlayerActivity.this);
            }
        });

        gestureLayer.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                scaleDetector.onTouchEvent(e);
                if (scaleDetector.isInProgress()) {
                    return true;
                }
                detector.onTouchEvent(e);
                if (locked) {
                    // 锁定后按用户设置在"锁定可用手势"里放行的项继续响应
                    boolean anyLock = Prefs.lockSeek(PlayerActivity.this)
                            || Prefs.lockBrightness(PlayerActivity.this)
                            || Prefs.lockVolume(PlayerActivity.this)
                            || Prefs.lockZoom(PlayerActivity.this)
                            || Prefs.lockLongPress(PlayerActivity.this);
                    if (!anyLock) {
                        return true;
                    }
                }
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = e.getX();
                        startY = e.getY();
                        seekStart = engine == null ? 0 : engine.position();
                        gestureMode = 0;
                        if (Prefs.gLongPress(PlayerActivity.this)) {
                            longPressRun = new Runnable() {
                                public void run() {
                                    if (gestureMode == 0 && engine != null && prepared) {
                                        boosting = true;
                                        savedSpeed = speed;
                                        float bs = Prefs.longPressSpeed(PlayerActivity.this);
                                        speed = bs;
                                        engine.setSpeed(bs);
                                        btnSpeed.setText(MediaUtils.formatSpeed(bs));
                                        boostHint.setVisibility(View.VISIBLE);
                                        boostHint.setText("×" + MediaUtils.trimSpeed(bs));
                                    }
                                }
                            };
                            main.postDelayed(longPressRun, 500);
                        }
                        break;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getX() - startX;
                        float dy = e.getY() - startY;
                        if (gestureMode == 0) {
                            // 锁定状态下只有用户放行的手势才生效
                            boolean allowSeek = Prefs.gSeek(PlayerActivity.this)
                                    && (!locked || Prefs.lockSeek(PlayerActivity.this));
                            boolean allowBright = Prefs.gBrightness(PlayerActivity.this)
                                    && (!locked || Prefs.lockBrightness(PlayerActivity.this));
                            boolean allowVol = Prefs.gVolume(PlayerActivity.this)
                                    && (!locked || Prefs.lockVolume(PlayerActivity.this));
                            if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 36) {
                                if (allowSeek) {
                                    gestureMode = 1;
                                    cancelLongPress();
                                }
                            } else if (Math.abs(dy) > 36) {
                                boolean left = startX < screenW / 2f;
                                if (left && allowBright) {
                                    gestureMode = 2;
                                    gestureBase = brightness();
                                    cancelLongPress();
                                } else if (!left && allowVol) {
                                    gestureMode = 3;
                                    gestureBase = volume();
                                    cancelLongPress();
                                }
                            }
                        }
                        if (gestureMode == 1 && duration > 0) {
                            float sens = Prefs.seekSensitivity(PlayerActivity.this) * 1000f;
                            long target = seekStart + (long) (dx / screenW * sens);
                            if (target < 0) {
                                target = 0;
                            }
                            if (target > duration) {
                                target = duration;
                            }
                            pendingSeek = target;
                            showHint(R.drawable.ic_fw,
                                    MediaUtils.formatDuration(target) + " / "
                                            + MediaUtils.formatDuration(duration), 0);
                        } else if (gestureMode == 2) {
                            // 基于手势起点值做线性映射，避免逐帧累加
                            float b = gestureBase - dy / (screenH * 1.15f);
                            if (b < 0) {
                                b = 0;
                            }
                            if (b > 1) {
                                b = 1;
                            }
                            setBrightness(b);
                            showHint(R.drawable.ic_brightness,
                                    getString(R.string.brightness, (int) (b * 100)), (int) (b * 100));
                        } else if (gestureMode == 3) {
                            float vol = gestureBase - dy / (screenH * 1.15f);
                            if (vol < 0) {
                                vol = 0;
                            }
                            if (vol > 1) {
                                vol = 1;
                            }
                            setVolume(vol);
                            showHint(R.drawable.ic_volume,
                                    getString(R.string.volume, (int) (vol * 100)), (int) (vol * 100));
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        cancelLongPress();
                        if (boosting) {
                            boosting = false;
                            speed = savedSpeed;
                            if (engine != null) {
                                engine.setSpeed(speed);
                            }
                            btnSpeed.setText(MediaUtils.formatSpeed(speed));
                            boostHint.setVisibility(View.GONE);
                        }
                        if (gestureMode == 1 && engine != null) {
                            engine.seekTo(pendingSeek);
                        }
                        if (gestureMode != 0) {
                            hideHint();
                        }
                        gestureMode = 0;
                        break;
                }
                return true;
            }
        });
    }

    private void cancelLongPress() {
        if (longPressRun != null) {
            main.removeCallbacks(longPressRun);
            longPressRun = null;
        }
    }

    private void applyZoom() {
        if (renderView == null) {
            return;
        }
        renderView.setZoom(zoomScale);
    }

    public float brightness() {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        float b = lp.screenBrightness;
        return b < 0 ? 0.5f : b;
    }

    private void setBrightness(float b) {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = b;
        getWindow().setAttributes(lp);
    }

    public float volume() {
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        return max == 0 ? 0 : (float) am.getStreamVolume(AudioManager.STREAM_MUSIC) / max;
    }

    private void setVolume(float v) {
        if (v > 1f) {
            v = 1f;
        }
        if (v < 0f) {
            v = 0f;
        }
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (int) (v * max), 0);
    }

    private void showHint(int icon, String text, int percent) {
        hint.setVisibility(View.VISIBLE);
        hintIcon.setImageResource(icon);
        hintText.setText(text);
        if (percent > 0) {
            hintBar.setVisibility(View.VISIBLE);
            hintBar.setProgress(percent);
        } else {
            hintBar.setVisibility(View.GONE);
        }
    }

    private void hideHint() {
        main.postDelayed(new Runnable() {
            public void run() {
                hint.setVisibility(View.GONE);
            }
        }, 350);
    }

    /* ==================== 播放核心 ==================== */
    private void open(final long startMs) {
        // 切换播放源：先关掉可能残留的面板（横屏侧边面板在竖屏下位置会错乱）
        closePanel();
        if (surface == null) {
            // surface 还没就绪：等 VideoRenderView 回调再走 open，
            // 绝不在这里重建渲染视图（重建会销毁 surface，反而制造黑屏）
            waitingSurface = true;
            pendingStartMs = startMs;
            if (loading != null) {
                loading.setVisibility(View.VISIBLE);
            }
            Diagnostics.log("open", "waiting surface, path=" + path);
            main.postDelayed(new Runnable() {
                public void run() {
                    if (!released && surface == null) {
                        if (loading != null) {
                            loading.setVisibility(View.GONE);
                        }
                    }
                }
            }, 2500);
            return;
        }
        waitingSurface = false;
        // 本地文件有效性校验，避免无效路径导致黑屏
        if (!path.startsWith("content://") && !path.startsWith("http")
                && !path.startsWith("rtsp") && !path.startsWith("rtmp")) {
            java.io.File f = new java.io.File(path);
            if (!f.exists() || !f.canRead()) {
                if (loading != null) {
                    loading.setVisibility(View.GONE);
                }
                Ui.toast(this, "文件不存在或无法读取");
                return;
            }
        }
        if (loading != null) {
            loading.setVisibility(View.VISIBLE);
        }
        prepared = false;
        cues = null;
        subtitleView.setCues(null);
        releaseEngine();
        titleView.setText(title);
        if (pathView != null) {
            pathView.setText(path);
        }
        VideoItem saved = db.find(path);
        isFav = saved != null && saved.fav;
        updateFavIcon();
        engineMode = Prefs.decodeMode(this);
        if (engineMode == Prefs.DECODE_SYSTEM) {
            engine = new SystemEngine();
        } else {
            // 时尘解码内核（com.hwdecoder）：硬件优先 / 软解优先 / 自动
            boolean hwOnly = engineMode == Prefs.DECODE_HW;
            boolean swFirst = engineMode == Prefs.DECODE_SW;
            engine = new HwEngine(this, hwOnly, swFirst);
        }
        engine.setCallback(this);
        if (renderView != null) {
            renderView.setFlip(Prefs.videoFlip(this));
            renderView.setUserRotate(Prefs.videoRotate(this));
        }
        if (engine instanceof SystemEngine) {
            ((SystemEngine) engine).setFillMode(ratio == Prefs.RATIO_FILL
                    || ratio == Prefs.RATIO_CROP);
            ((SystemEngine) engine).setBoost(Prefs.boostVolume(this) / 100f);
        } else if (engine instanceof HwEngine) {
            ((HwEngine) engine).setBoost(Prefs.boostVolume(this) / 100f);
        } else if (engine instanceof CodecEngine) {
            ((CodecEngine) engine).setBoost(Prefs.boostVolume(this) / 100f);
        }
        engine.setSurface(surface);
        startWatchdog();
        Diagnostics.log("open", "prepare start, surface="
                + (surface == null ? "null" : "ok") + " engine=" + engine.engineName());
        doPrepare(startMs);
    }

    /**
     * 执行 prepare：
     * - 系统内核（MediaPlayer）在主线程执行，符合官方规范，回调一定可达
     * - 自研内核（MediaCodec）在子线程执行，避免阻塞 UI
     * 任何异常都明确提示，并自动回退另一种内核，不再静默黑屏
     */
    private void doPrepare(final long startMs) {
        final boolean sys = (engine instanceof SystemEngine);
        Runnable task = new Runnable() {
            public void run() {
                if (released) {
                    return;
                }
                try {
                    engine.prepare(PlayerActivity.this, path, startMs);
                    // 探测分辨率是耗时 IO：系统内核跑在主线程时绝不能同步执行，
                    // 交给子线程去做，避免卡顿甚至 ANR
                    if (videoW == 0) {
                        new Thread(new Runnable() {
                            public void run() {
                                try {
                                    long[] sz = MediaUtils.probeVideoSize(path);
                                    videoW = (int) sz[0];
                                    videoH = (int) sz[1];
                                    rotation = (int) sz[2];
                                    main.post(new Runnable() {
                                        public void run() {
                                            applyRatio();
                                        }
                                    });
                                } catch (Exception ignored) {
                                }
                            }
                        }).start();
                    }
                } catch (final Exception e) {
                    main.post(new Runnable() {
                        public void run() {
                            if (released) {
                                return;
                            }
                            String msg = e.getMessage() == null ? "未知错误" : e.getMessage();
                            Diagnostics.err("prepare", e);
                            if (sys) {
                                // 系统内核失败 → 改自研内核（软解兜底）
                                Ui.toast(PlayerActivity.this, "系统内核失败：" + msg + "，改用自研内核");
                                releaseEngine();
                                CodecEngine ce = new CodecEngine();
                                ce.setPreferHw(false);
                                engine = ce;
                                engine.setCallback(PlayerActivity.this);
                                engine.setSurface(surface);
                                new Thread(new Runnable() {
                                    public void run() {
                                        try {
                                            engine.prepare(PlayerActivity.this, path, startMs);
                                        } catch (final Exception e2) {
                                            main.post(new Runnable() {
                                                public void run() {
                                                    if (loading != null) {
                                                        loading.setVisibility(View.GONE);
                                                    }
                                                    Ui.toast(PlayerActivity.this,
                                                            "无法播放：" + e2.getMessage());
                                                }
                                            });
                                        }
                                    }
                                }).start();
                            } else {
                                if (loading != null) {
                                    loading.setVisibility(View.GONE);
                                }
                                Ui.toast(PlayerActivity.this, "无法播放：" + msg);
                            }
                        }
                    });
                }
            }
        };
        if (sys) {
            main.post(task);
        } else {
            new Thread(task).start();
        }
    }

    /** 诊断文本：默认显示 6 秒，便于定位黑屏原因 */


    /* ---- 播放看门狗：防止解码卡死导致永久黑屏 ---- */
    private Runnable watchdogRun;

    private void startWatchdog() {
        cancelWatchdog();
        watchdogRun = new Runnable() {
            public void run() {
                if (released) {
                    return;
                }
                if (!prepared) {
                    Ui.toast(PlayerActivity.this, "解码超时，正在重试");
                    if (!(engine instanceof SystemEngine)) {
                        fallbackToSystem();
                    } else {
                        releaseEngine();
                        open(resumePos);
                    }
                } else if (loading != null && loading.getVisibility() == View.VISIBLE) {
                    loading.setVisibility(View.GONE);
                }
            }
        };
        main.postDelayed(watchdogRun, 9000);
    }

    private void cancelWatchdog() {
        if (watchdogRun != null) {
            main.removeCallbacks(watchdogRun);
            watchdogRun = null;
        }
    }

    private void fallbackToSystem() {
        Ui.toast(this, "自研内核失败，切换到系统内核");
        releaseEngine();
        engine = new SystemEngine();
        engine.setCallback(this);
        engine.setSurface(surface);
        final long start = resumePos;
        new Thread(new Runnable() {
            public void run() {
                try {
                    engine.prepare(PlayerActivity.this, path, start);
                } catch (Exception e) {
                    main.post(new Runnable() {
                        public void run() {
                            loading.setVisibility(View.GONE);
                            Ui.toast(PlayerActivity.this, "播放失败");
                        }
                    });
                }
            }
        }).start();
    }

    private void releaseEngine() {
        if (engine != null) {
            try {
                engine.release();
            } catch (Exception ignored) {
            }
            engine = null;
        }
    }

    public void onPrepared(final int width, final int height, final long dur) {
        main.post(new Runnable() {
            public void run() {
                if (width > 0) {
                    videoW = width;
                    videoH = height;
                }
                duration = dur;
                // 校正旋转角：MediaPlayer 返回的是原始像素尺寸，竖屏视频常以
                // 横屏尺寸+旋转角存储（如 1920x1080 + 90°）。若旋转角未读出来，
                // 宽高比就会算反，竖屏视频被当成横屏显示 → 看起来就是被拉伸。
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            long[] sz = MediaUtils.probeVideoSize(path);
                            final int w = (int) sz[0];
                            final int h = (int) sz[1];
                            final int r = (int) sz[2];
                            main.post(new Runnable() {
                                public void run() {
                                    if (released) {
                                        return;
                                    }
                                    if (w > 0 && h > 0) {
                                        videoW = w;
                                        videoH = h;
                                    }
                                    rotation = r;
                                    applyRatio();
                                    // 按真实宽高比重新确定方向：默认"跟随视频"时，
                                    // 竖屏视频必须竖着播，竖屏视频不能因为上一集是横屏就横着播
                                    if (Prefs.orientation(PlayerActivity.this) == Prefs.O_VIDEO) {
                                        applyOrientation();
                                    }
                                }
                            });
                        } catch (Exception ignored) {
                        }
                    }
                }).start();
                prepared = true;
                Diagnostics.log("play", "prepared ok dur=" + dur
                        + " size=" + width + "x" + height);
                cancelWatchdog();
                retryCount = 0;
                if (loading != null) {
                    loading.setVisibility(View.GONE);
                }
                timeTotal.setText(MediaUtils.formatDuration(duration));
                if (Prefs.orientation(PlayerActivity.this) == Prefs.O_VIDEO) {
                    applyOrientation();
                }
                applyRatio();
                if (resumePos > 0 && resumePos < duration - 2000) {
                    engine.seekTo(resumePos);
                    showRestartPrompt();
                }
                engine.setSpeed(speed);
                // 立即应用音量放大，否则要等用户调音量才生效
                try {
                    engine.setVolume(1.0f, 1.0f);
                } catch (Exception ignored) {
                }
                engine.start();
                btnPlay.setImageResource(R.drawable.ic_pause);
                startFirstFrameCheck();
                loadSubtitle();
                attachAudioFx();
                if (playlistPanel != null) {
                    playlistPanel.refresh();
                }
            }
        });
    }

    private void attachAudioFx() {
        int session = 0;
        if (engine instanceof SystemEngine) {
            session = ((SystemEngine) engine).audioSessionId();
        } else if (engine instanceof CodecEngine) {
            session = ((CodecEngine) engine).audioSessionId();
        }
        if (session > 0) {
            AudioFx.attach(session);
        }
    }

    public void onFirstFrame() {
        if (floatWindow != null && inFloatWindow) {
            floatWindow.applyVideoSize();
        }
        gotFrame = true;
        Diagnostics.log("play", "first frame rendered");
        cancelFirstFrameCheck();
        main.post(new Runnable() {
            public void run() {
                loading.setVisibility(View.GONE);
            }
        });
    }

    public void onBuffering(int percent) {
        if (seek != null) {
            seek.setSecondaryProgress(percent * 10);
        }
    }

    /** 自研内核已重建过的次数，避免反复重启 */
    private int codecRetryCount = 0;

    /* ---- 悬浮窗小窗 ---- */
    private FloatWindow floatWindow;
    private boolean inFloatWindow = false;
    /** 播放页自己的 surface（悬浮窗期间画面的输出目标会临时切换） */
    private android.view.Surface pageSurface = null;
    private android.view.Surface floatSurface = null;
    private boolean useFloat = false;

    public void onError(final String msg) {
        Diagnostics.log("play", "onError: " + msg);
        main.post(new Runnable() {
            public void run() {
                loading.setVisibility(View.GONE);
                boolean isCodec = !(engine instanceof SystemEngine);
                // 自研内核出错：先原地重建一次（保留倍速与进度），
                // 仍失败才回退系统内核，避免动不动就"播放失败退出"
                if (isCodec && codecRetryCount < 1) {
                    codecRetryCount++;
                    Diagnostics.log("play", "codec restart attempt " + codecRetryCount);
                    long pos = engine != null ? engine.position() : resumePos;
                    Ui.toast(PlayerActivity.this, "解码异常，正在重试");
                    releaseEngine();
                    open(pos);
                    return;
                }
                if (Prefs.fallback(PlayerActivity.this) && isCodec) {
                    fallbackToSystem();
                } else {
                    Ui.toast(PlayerActivity.this, msg);
                }
            }
        });
    }

    public void onCompletion() {
        main.post(new Runnable() {
            public void run() {
                if (repeatMode == Prefs.REPEAT_ONE) {
                    engine.seekTo(0);
                    engine.start();
                    return;
                }
                boolean hasNext = index >= 0 && index + 1 < playlist.size();
                if (repeatMode == Prefs.REPEAT_ALL) {
                    playOffset(1);
                    return;
                }
                if (Prefs.autoNext(PlayerActivity.this) && hasNext) {
                    playOffset(1);
                } else if (Prefs.exitOnFinish(PlayerActivity.this)) {
                    finish();
                } else {
                    btnPlay.setImageResource(R.drawable.ic_play);
                    saveProgress(0);
                }
            }
        });
    }

    private void togglePlay() {
        if (engine == null || !prepared) {
            return;
        }
        if (engine.isPlaying()) {
            engine.pause();
            btnPlay.setImageResource(R.drawable.ic_play);
        } else {
            engine.start();
            btnPlay.setImageResource(R.drawable.ic_pause);
        }
    }

    private void seekDelta(int ms) {
        if (engine == null || !prepared) {
            return;
        }
        long p = engine.position() + ms;
        if (p < 0) {
            p = 0;
        }
        if (p > duration) {
            p = duration;
        }
        engine.seekTo(p);
    }

    private void playOffset(int off) {
        if (playlist.isEmpty()) {
            return;
        }
        int n = index + off;
        if (n < 0) {
            n = playlist.size() - 1;
        }
        if (n >= playlist.size()) {
            n = 0;
        }
        saveProgress(0);
        index = n;
        path = playlist.get(n);
        // 切集前先把尺寸和方向复位，避免沿用上一集（上集横屏会把竖屏的下一集也带成横屏）
        videoW = 0;
        videoH = 0;
        rotation = 0;
        if (Prefs.orientation(this) == Prefs.O_VIDEO) {
            applyOrientation();
        }
        int k = path.lastIndexOf('/');
        title = k >= 0 ? path.substring(k + 1) : path;
        VideoItem saved = db.find(path);
        resumePos = (saved != null && Prefs.rememberPos(this)) ? saved.position : 0;
        abA = -1;
        abB = -1;
        if (btnAb != null) {
            btnAb.setAlpha(0.6f);
        }
        zoomScale = 1.0f;
        open(resumePos);
    }

    private final Runnable updateRunnable = new Runnable() {
        public void run() {
            if (engine != null && prepared) {
                long pos = engine.position();
                // seek 是异步的：目标未到达前保持用户拖到的位置，不回弹
                if (pendingSeekMs >= 0) {
                    boolean arrived = Math.abs(pos - pendingSeekMs) < 1200L;
                    boolean timeout = (System.nanoTime() - pendingSeekAt) > 3000000000L;
                    if (arrived || timeout) {
                        pendingSeekMs = -1;
                    } else {
                        pos = pendingSeekMs;   // 显示目标位置而非中间态
                    }
                }
                if (!userSeeking && duration > 0 && seek != null) {
                    seek.setProgress((int) (pos * 1000L / duration));
                    timeCur.setText(MediaUtils.formatDuration(pos));
                }
                boolean pip = Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode();
                if (Prefs.statusOverlay(PlayerActivity.this) && !pip) {
                    updateStatusLeft();
                }
                if (subtitleOn && cues != null) {
                    subtitleView.setPosition(pos);
                }
                if (abA >= 0 && abB > abA && pos >= abB) {
                    engine.seekTo(abA);
                }
                if (System.currentTimeMillis() - lastProgressSave > 3000) {
                    saveProgress(pos);
                }
                if (sleepAt > 0 && System.currentTimeMillis() > sleepAt) {
                    sleepAt = 0;
                    if (engine.isPlaying()) {
                        engine.pause();
                        btnPlay.setImageResource(R.drawable.ic_play);
                    }
                    Ui.toast(PlayerActivity.this, "睡眠定时已到");
                }
                if (Prefs.showDebug(PlayerActivity.this) && pathView != null) {
                    pathView.setText(engine.engineName() + "  |  缓冲 "
                            + engine.buffered() + "%  |  " + videoW + "x" + videoH);
                }
            }
            main.postDelayed(this, 300);
        }
    };

    private void saveProgress(long pos) {
        lastProgressSave = System.currentTimeMillis();
        VideoItem v = new VideoItem();
        v.path = path;
        v.title = title;
        v.duration = duration;
        v.size = new File(path).length();
        v.width = videoW;
        v.height = videoH;
        db.saveHistory(v, pos);
    }

    /* ==================== 字幕 ==================== */
    private void loadSubtitle() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    File f = new File(path);
                    File dir = f.getParentFile();
                    String base = f.getName();
                    int i = base.lastIndexOf('.');
                    if (i > 0) {
                        base = base.substring(0, i);
                    }
                    String[] exts = {".srt", ".vtt", ".ass", ".ssa", ".lrc"};
                    File found = null;
                    if (dir != null) {
                        for (String e : exts) {
                            File c = new File(dir, base + e);
                            if (c.exists()) {
                                found = c;
                                break;
                            }
                        }
                    }
                    if (found == null) {
                        return;
                    }
                    InputStream in = new FileInputStream(found);
                    final List<SubtitleParser.Cue> list = SubtitleParser.parse(in, found.getName());
                    in.close();
                    main.post(new Runnable() {
                        public void run() {
                            cues = list;
                            subtitleView.setCues(list);
                            subtitleView.setVisibility(subtitleOn ? View.VISIBLE : View.GONE);
                        }
                    });
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    public void showSubtitleMenu() {
        List<String> opts = new ArrayList<String>();
        opts.add(subtitleOn ? "隐藏字幕" : "显示字幕");
        opts.add(getString(R.string.subtitle_size) + "（当前 " + Prefs.subtitleSize(this) + "sp）");
        opts.add(getString(R.string.subtitle_delay) + "（当前 " + Prefs.subtitleDelay(this) + "ms）");
        opts.add(getString(R.string.load_subtitle));
        Ui.sheet(this, getString(R.string.subtitle_title), opts.toArray(new String[0]), -1,
                new Ui.OnPick() {
                    public void onPick(int index) {
                        if (index == 0) {
                            subtitleOn = !subtitleOn;
                            subtitleView.setVisibility(subtitleOn ? View.VISIBLE : View.GONE);
                            Prefs.setSubtitleOn(PlayerActivity.this, subtitleOn);
                        } else if (index == 1) {
                            String[] sizes = {"12", "14", "16", "18", "20", "24", "28"};
                            Ui.sheet(PlayerActivity.this, getString(R.string.subtitle_size), sizes, -1,
                                    new Ui.OnPick() {
                                        public void onPick(int idx) {
                                            int[] vals = {12, 14, 16, 18, 20, 24, 28};
                                            Prefs.setSubtitleSize(PlayerActivity.this, vals[idx]);
                                            subtitleView.setSizeSp(vals[idx]);
                                        }
                                    });
                        } else if (index == 2) {
                            String[] ds = {"-3000", "-1500", "-500", "0", "500", "1500", "3000"};
                            Ui.sheet(PlayerActivity.this, getString(R.string.subtitle_delay), ds, 3,
                                    new Ui.OnPick() {
                                        public void onPick(int idx) {
                                            int[] vals = {-3000, -1500, -500, 0, 500, 1500, 3000};
                                            Prefs.setSubtitleDelay(PlayerActivity.this, vals[idx]);
                                            subtitleView.setDelayMs(vals[idx]);
                                        }
                                    });
                        } else {
                            Ui.toast(PlayerActivity.this, "请把同名字幕文件放在视频同一目录");
                        }
                    }
                });
    }

    /* ==================== 菜单 ==================== */
    /** 倍速：滑杆 0.25x–4.0x + 常用档位 + 自定义输入（紧凑面板，横竖屏一致） */
    public void showSpeedPanel() {
        hideControls();
        final float[] cur = {speed};
        final int accent0 = ThemeEngine.accent(this);
        float d0 = getResources().getDisplayMetrics().density;
        int pd = (int) (16 * d0);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pd, (int) (2 * d0), pd, (int) (6 * d0));

        // ---- 当前倍速大号显示 ----
        final TextView big = new TextView(this);
        big.setText(MediaUtils.formatSpeed(speed));
        big.setTextSize(34f);
        big.setTextColor(accent0);
        big.setGravity(Gravity.CENTER);
        big.setTypeface(null, android.graphics.Typeface.BOLD);
        big.setPadding(0, (int) (2 * d0), 0, (int) (2 * d0));
        box.addView(big);

        // ---- 滑杆 ----
        final int minP = 25;
        final int maxP = 400;
        SeekBar sb = new SeekBar(this);
        sb.setMax(maxP - minP);
        sb.setProgress(Math.round(speed * 100) - minP);
        sb.setPadding((int) (2 * d0), (int) (6 * d0), (int) (2 * d0), (int) (2 * d0));
        try {
            sb.setProgressDrawable(getResources().getDrawable(R.drawable.progress_player));
        } catch (Exception ignored) {
        }
        box.addView(sb);

        // ---- 刻度 ----
        LinearLayout ticks = new LinearLayout(this);
        ticks.setOrientation(LinearLayout.HORIZONTAL);
        ticks.setPadding((int) (2 * d0), 0, (int) (2 * d0), 0);
        String[] tk = {"0.25x", "1.0x", "2.0x", "3.0x", "4.0x"};
        for (int i = 0; i < tk.length; i++) {
            TextView t = new TextView(this);
            t.setText(tk[i]);
            t.setTextSize(10.5f);
            t.setTextColor(0x99FFFFFF);
            t.setGravity(i == 0 ? Gravity.LEFT
                    : (i == tk.length - 1 ? Gravity.RIGHT : Gravity.CENTER));
            t.setLayoutParams(new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            ticks.addView(t);
        }
        box.addView(ticks);

        // ---- 常用档位（圆角 chip，选中用强调色描边与底色） ----
        final FlowLayout fl = new FlowLayout(this);
        fl.setGaps((int) (8 * d0), (int) (8 * d0));
        fl.setPadding(0, (int) (10 * d0), 0, (int) (2 * d0));
        final float[] presets = {0.25f, 0.5f, 0.75f, 1.0f, 1.25f,
                1.5f, 2.0f, 2.5f, 3.0f, 4.0f};
        final List<TextView> chips = new ArrayList<TextView>();
        final Runnable repaint = new Runnable() {
            public void run() {
                int ar = Color.red(accent0);
                int ag = Color.green(accent0);
                int ab = Color.blue(accent0);
                for (int i = 0; i < chips.size(); i++) {
                    TextView t = chips.get(i);
                    boolean on = Math.abs(presets[i] - cur[0]) < 0.005f;
                    android.graphics.drawable.GradientDrawable gd =
                            new android.graphics.drawable.GradientDrawable();
                    gd.setCornerRadius(18 * d0);
                    if (on) {
                        gd.setColor(Color.argb(58, ar, ag, ab));
                        gd.setStroke(Math.max(1, (int) (1.4f * d0)), accent0);
                        t.setTextColor(accent0);
                    } else {
                        gd.setColor(0x14FFFFFF);
                        gd.setStroke(Math.max(1, (int) d0), 0x18FFFFFF);
                        t.setTextColor(0xFFDDDDE6);
                    }
                    t.setBackgroundDrawable(gd);
                }
            }
        };
        for (int i = 0; i < presets.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(MediaUtils.formatSpeed(presets[i]));
            t.setTextSize(13.5f);
            t.setTypeface(null, android.graphics.Typeface.BOLD);
            t.setGravity(Gravity.CENTER);
            int hp = (int) (16 * d0);
            int vp = (int) (9 * d0);
            t.setPadding(hp, vp, hp, vp);
            t.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    cur[0] = presets[idx];
                    big.setText(MediaUtils.formatSpeed(cur[0]));
                    sb.setProgress(Math.round(cur[0] * 100) - minP);
                    repaint.run();
                    applySpeedValue(cur[0]);
                }
            });
            chips.add(t);
            fl.addView(t);
        }
        repaint.run();
        box.addView(fl);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int p, boolean fromUser) {
                if (!fromUser) {
                    return;
                }
                float f = (p + minP) / 100f;
                if (f < 0.25f) {
                    f = 0.25f;
                }
                if (f > 4.0f) {
                    f = 4.0f;
                }
                cur[0] = f;
                big.setText(MediaUtils.formatSpeed(f));
                repaint.run();
                applySpeedValue(f);
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        // ---- 底部操作：自定义输入 / 复位 ----
        LinearLayout acts = new LinearLayout(this);
        acts.setOrientation(LinearLayout.HORIZONTAL);
        acts.setGravity(Gravity.CENTER);
        acts.setPadding(0, (int) (6 * d0), 0, 0);

        TextView custom = new TextView(this);
        custom.setText("\u270F 自定义");
        custom.setTextSize(12.5f);
        custom.setTextColor(accent0);
        custom.setGravity(Gravity.CENTER);
        custom.setPadding((int) (16 * d0), (int) (8 * d0),
                (int) (16 * d0), (int) (8 * d0));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        custom.setLayoutParams(clp);
        custom.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Ui.input(PlayerActivity.this, "自定义倍速（0.25 - 4.0）",
                        MediaUtils.formatSpeed(cur[0]).replace("x", ""), "例如 1.75",
                        new Ui.OnText() {
                    public void onText(String txt) {
                        try {
                            float f = Float.parseFloat(txt.trim());
                            if (f < 0.25f) {
                                f = 0.25f;
                            }
                            if (f > 4.0f) {
                                f = 4.0f;
                            }
                            cur[0] = f;
                            big.setText(MediaUtils.formatSpeed(f));
                            sb.setProgress(Math.round(f * 100) - minP);
                            repaint.run();
                            applySpeedValue(f);
                        } catch (Exception ignored) {
                        }
                    }
                });
            }
        });
        acts.addView(custom);

        TextView reset = new TextView(this);
        reset.setText("\u21BB 复位 1.0x");
        reset.setTextSize(12.5f);
        reset.setTextColor(0xFFDDDDE6);
        reset.setGravity(Gravity.CENTER);
        reset.setPadding((int) (16 * d0), (int) (8 * d0),
                (int) (16 * d0), (int) (8 * d0));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        rlp.leftMargin = (int) (8 * d0);
        reset.setLayoutParams(rlp);
        reset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                cur[0] = 1.0f;
                big.setText(MediaUtils.formatSpeed(1.0f));
                sb.setProgress(100 - minP);
                repaint.run();
                applySpeedValue(1.0f);
            }
        });
        acts.addView(reset);
        box.addView(acts);

        // 横竖屏都走紧凑面板：横屏不会占半屏，且是半透明底
        trackPanel(Ui.panelCompact(this, getString(R.string.speed_title), box));
    }

private void applySpeedValue(float f) {
        speed = f;
        savedSpeed = f;
        if (btnSpeed != null) {
            btnSpeed.setText(MediaUtils.formatSpeed(f));
        }
        if (engine != null) {
            engine.setSpeed(f);
        }
    }


    public void showRatio() {
        String[] opts = {"适应屏幕", "16:9", "4:3", "铺满(拉伸)", "原始尺寸", "裁剪填充", "1:1", "21:9"};
        Ui.sheet(this, getString(R.string.ratio_title), opts, ratio, new Ui.OnPick() {
            public void onPick(int index) {
                ratio = index;
                zoomScale = 1.0f;
                applyRatio();
            }
        });
    }

    private void applyRatio() {
        if (renderView == null) {
            return;
        }
        renderView.setVideoSize(videoW, videoH, rotation);
        renderView.setRatio(ratio);
    }


    public void showTracks() {
        if (engine == null) {
            return;
        }
        List<PlayerEngine.TrackInfo> tracks = engine.tracks();
        if (tracks.isEmpty()) {
            Ui.toast(this, getString(R.string.toast_unsupported));
            return;
        }
        String[] names = new String[tracks.size()];
        for (int i = 0; i < tracks.size(); i++) {
            PlayerEngine.TrackInfo t = tracks.get(i);
            String kind = t.type == 0 ? "视频" : (t.type == 1 ? "音频" : "字幕");
            names[i] = kind + " " + t.label();
        }
        Ui.sheet(this, getString(R.string.track_title), names, -1, new Ui.OnPick() {
            public void onPick(int index) {
                engine.selectTrack(engine.tracks().get(index).index);
            }
        });
    }

    public void showPlaylist() {
        hideControls();
        if (playlist.isEmpty()) {
            Ui.toast(this, "当前没有播放列表");
            return;
        }
        final PlaylistPanel pp = new PlaylistPanel(this, playlist,
                new PlaylistPanel.Provider() {
            public int currentIndex() {
                return index;
            }

            public long currentPos() {
                return engine == null ? 0 : engine.position();
            }
        },
                new PlaylistPanel.Callback() {
            public void onPick(int pos) {
                playOffset(pos - index);
            }

            public void onRemove(int pos) {
                if (playlist.size() <= 1) {
                    Ui.toast(PlayerActivity.this, "至少保留一个视频");
                    return;
                }
                if (pos == index) {
                    playOffset(1);
                }
                playlist.remove(pos);
                if (index > pos) {
                    index--;
                }
                if (index >= playlist.size()) {
                    index = playlist.size() - 1;
                }
                if (playlistPanel != null) {
                    playlistPanel.refresh();
                }
            }

            public void onReorder(List<String> newList) {
                playlist = new ArrayList<String>(newList);
                // 顺序变更后重新定位当前播放项，避免跳转错片
                int ni = playlist.indexOf(path);
                if (ni >= 0) {
                    index = ni;
                }
            }

            public void onMoveTo(int from, int to) {
                int ni = playlist.indexOf(path);
                if (ni >= 0) {
                    index = ni;
                }
                Ui.toast(PlayerActivity.this, "已调整顺序");
            }
        });
        // 不显示"取消/完成"按钮，让列表显示更多条目
        playlistPanel = pp;
        View body = pp.build();
        final AlertDialog dlg;
        if (getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE) {
            dlg = Ui.side(this, body);
        } else {
            dlg = Ui.panelNoButtons(this, getString(R.string.playlist), body, "playlist");
        }
        trackPanel(dlg);
    }


    public void toggleAb() {
        long pos = engine == null ? 0 : engine.position();
        if (abA < 0) {
            abA = pos;
            if (btnAb != null) {
                btnAb.setAlpha(1f);
            }
            Ui.toast(this, getString(R.string.ab_set_a, MediaUtils.formatDuration(abA)));
        } else if (abB < 0) {
            abB = pos;
            if (abB <= abA) {
                abB = -1;
                Ui.toast(this, "B 点需晚于 A 点");
                return;
            }
            Ui.toast(this, getString(R.string.ab_set_b, MediaUtils.formatDuration(abB)));
        } else {
            abA = -1;
            abB = -1;
            if (btnAb != null) {
                btnAb.setAlpha(0.6f);
            }
            Ui.toast(this, getString(R.string.ab_clear));
        }
    }


    public void showSleep() {
        String[] opts = {getString(R.string.sleep_off), "15 分钟", "30 分钟", "45 分钟",
                "60 分钟", "90 分钟", "本集播完"};
        final int[] mins = {0, 15, 30, 45, 60, 90, -1};
        Ui.sheet(this, getString(R.string.sleep_title), opts, 0, new Ui.OnPick() {
            public void onPick(int index) {
                if (mins[index] == 0) {
                    sleepAt = 0;
                    Ui.toast(PlayerActivity.this, getString(R.string.sleep_off));
                } else if (mins[index] < 0) {
                    sleepAt = -1;
                    Ui.toast(PlayerActivity.this, "本集播完即暂停");
                } else {
                    sleepAt = System.currentTimeMillis() + mins[index] * 60000L;
                    Ui.toast(PlayerActivity.this, getString(R.string.sleep_on, mins[index]));
                }
            }
        });
    }

    public void showInfo() {
        View v = getLayoutInflater().inflate(R.layout.dialog_info, null);
        TextView name = (TextView) v.findViewById(R.id.name);
        name.setText(title);
        name.setTextColor(ThemeEngine.accent(this));
        LinearLayout rows = (LinearLayout) v.findViewById(R.id.rows);
        // 文件基础信息
        try {
            java.io.File f = new java.io.File(path);
            if (f.exists()) {
                rows.addView(Ui.row(this, "文件大小", MediaUtils.formatSize(f.length())));
                rows.addView(Ui.row(this, "修改时间",
                        MediaUtils.formatDate(f.lastModified())));
            }
        } catch (Exception ignored) {
        }
        rows.addView(Ui.row(this, "播放时长", MediaUtils.formatDuration(duration)));
        if (duration > 0) {
            long pos = engine == null ? 0 : engine.position();
            int pct = (int) (pos * 100 / duration);
            rows.addView(Ui.row(this, "当前进度",
                    MediaUtils.formatDuration(pos) + "（" + pct + "%）"));
        }
        // 容器/轨道信息
        for (java.util.Map.Entry<String, String> e : MediaUtils.info(this, path).entrySet()) {
            rows.addView(Ui.row(this, e.getKey(), e.getValue()));
        }
        rows.addView(Ui.row(this, "解码内核", engine == null ? "-" : engine.engineName()));
        rows.addView(Ui.row(this, "缓冲进度",
                (engine == null ? 0 : engine.buffered()) + "%"));
        rows.addView(Ui.row(this, "渲染方式", "TextureView（矩阵变换）"));
        rows.addView(Ui.row(this, "路径", path));
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(v);
        Ui.panel(this, getString(R.string.info_title), sv, true, null);
    }

    public void screenshot() {
        Bitmap bm = null;
        if (renderView != null && renderView.view() != null) {
            try {
                bm = renderView.view().getBitmap(1280, 720);
            } catch (Exception ignored) {
            }
        }
        if (bm == null) {
            Ui.toast(this, getString(R.string.toast_unsupported));
            return;
        }
        final Bitmap fin = bm;
        new Thread(new Runnable() {
            public void run() {
                try {
                    String name = "Shichen_" + System.currentTimeMillis() + ".jpg";
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                    cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                    if (Build.VERSION.SDK_INT >= 29) {
                        cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Shichen");
                        cv.put(MediaStore.Images.Media.IS_PENDING, 1);
                    }
                    Uri uri = getContentResolver().insert(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                    if (uri != null) {
                        OutputStream os = getContentResolver().openOutputStream(uri);
                        fin.compress(Bitmap.CompressFormat.JPEG, 92, os);
                        os.close();
                        if (Build.VERSION.SDK_INT >= 29) {
                            cv.clear();
                            cv.put(MediaStore.Images.Media.IS_PENDING, 0);
                            getContentResolver().update(uri, cv, null, null);
                        }
                    }
                    main.post(new Runnable() {
                        public void run() {
                            Ui.toast(PlayerActivity.this, getString(R.string.screenshot_saved));
                        }
                    });
                } catch (Exception e) {
                    main.post(new Runnable() {
                        public void run() {
                            Ui.toast(PlayerActivity.this, getString(R.string.toast_unsupported));
                        }
                    });
                }
            }
        }).start();
    }

    public void startBackground() {
        Intent i = new Intent(this, PlaybackService.class);
        i.setAction(PlaybackService.ACTION_START);
        i.putExtra("path", path);
        i.putExtra("title", title);
        i.putExtra("pos", engine == null ? 0 : engine.position());
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
        Ui.toast(this, "已切换到后台播放");
    }

    /** 悬浮窗小窗：带进度条、播放暂停、按视频比例 */
    public void enterFloatWindow() {
        if (floatWindow == null) {
            floatWindow = new FloatWindow(this, floatHost);
        }
        if (!FloatWindow.hasPermission(this)) {
            Ui.toast(this, "需要悬浮窗权限才能使用小窗");
            try {
                Intent it = new Intent(
                        android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(it);
            } catch (Exception ignored) {
            }
            return;
        }
        if (floatWindow.show()) {
            inFloatWindow = true;
            hideControls();
            moveTaskToBack(true);
        } else {
            Ui.toast(this, "小窗启动失败");
        }
    }

    private final FloatWindow.Host floatHost = new FloatWindow.Host() {
        public void attachSurface(Surface s) {
            if (s != null) {
                floatSurface = s;
                useFloat = true;
                surface = s;
                if (engine instanceof HwEngine) {
                    // 时尘内核支持 Surface 热切换，无需重建解码器（更快且不会黑屏）
                    Diagnostics.log("float", "hw engine hot-swap surface");
                    try {
                        engine.setSurface(s);
                    } catch (Throwable ignored) {
                    }
                    return;
                }
                Diagnostics.log("float", "attach float surface, rebuild engine");
                long pos = engine != null ? engine.position() : 0;
                open(pos);
            } else {
                floatSurface = null;
                useFloat = false;
                surface = pageSurface;
                Diagnostics.log("float", "detach float surface, back to page");
                if (engine instanceof HwEngine) {
                    try {
                        engine.setSurface(pageSurface);
                    } catch (Throwable ignored) {
                    }
                    return;
                }
                long pos = engine != null ? engine.position() : 0;
                if (surface != null) {
                    open(pos);
                }
            }
        }

        public long position() {
            return engine == null ? 0 : engine.position();
        }

        public long duration() {
            return duration;
        }

        public boolean isPlaying() {
            return engine != null && engine.isPlaying();
        }

        public void seek(long ms) {
            if (engine != null) {
                engine.seekTo(ms);
            }
        }

        public void togglePlay() {
            if (engine == null) {
                return;
            }
            if (engine.isPlaying()) {
                engine.pause();
            } else {
                engine.start();
            }
        }

        public void requestFullscreen() {
            main.post(new Runnable() {
                public void run() {
                    closeFloatWindow();
                    comeBackFromFloat();
                }
            });
        }

        public void requestClose() {
            // 关掉小窗：先停播放再移除窗口，保证悬浮窗一定消失
            main.post(new Runnable() {
                public void run() {
                    closeFloatWindow();
                    finish();
                }
            });
        }

        public int[] videoSize() {
            int w = videoW;
            int h = videoH;
            // 旋转 90/270 度时长宽互换，小窗按实际看到的比例显示
            if (rotation == 90 || rotation == 270) {
                int t = w;
                w = h;
                h = t;
            }
            if (w <= 0 || h <= 0) {
                return null;
            }
            return new int[]{w, h};
        }
    };

    /** 统一关闭悬浮小窗并把画面还给播放页 */
    private void closeFloatWindow() {
        inFloatWindow = false;
        useFloat = false;
        floatSurface = null;
        surface = pageSurface;
        if (floatWindow != null) {
            floatWindow.dismiss();
            floatWindow = null;
        }
        if (engine != null && surface != null) {
            long pos = engine.position();
            open(pos);
        }
    }

    /** 从悬浮窗回到全屏播放页 */
    private void comeBackFromFloat() {
        Intent it = new Intent(this, PlayerActivity.class);
        it.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try {
            startActivity(it);
        } catch (Exception ignored) {
        }
        if (engine != null && renderView != null) {
            renderView.rebind();
        }
    }

    public void enterPip() {
        if (Prefs.floatWindowMode(this)) {
            enterFloatWindow();
            return;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                PictureInPictureParams.Builder b = new PictureInPictureParams.Builder();
                // 按视频真实比例弹出小窗（3:4 的视频就是 3:4 的小窗）
                int w = videoW;
                int h = videoH;
                if (rotation == 90 || rotation == 270) {
                    int t = w;
                    w = h;
                    h = t;
                }
                if (w > 0 && h > 0) {
                    try {
                        Rational r = new Rational(w, h);
                        // 系统限制 2.39:1 ~ 1:2.39，超出则收敛到边界
                        float ar = w / (float) h;
                        if (ar > 2.39f) {
                            r = new Rational(239, 100);
                        } else if (ar < 1f / 2.39f) {
                            r = new Rational(100, 239);
                        }
                        b.setAspectRatio(r);
                    } catch (Exception ignored) {
                    }
                }
                b.setActions(buildPipActions());
                enterPictureInPictureMode(b.build());
            } catch (Exception e) {
                Ui.toast(this, getString(R.string.toast_unsupported));
            }
        } else {
            Ui.toast(this, getString(R.string.toast_unsupported));
        }
    }

    /** 小窗上的自定义按钮：播放/暂停、上一个、下一个 */
    private java.util.List<android.app.RemoteAction> buildPipActions() {
        java.util.List<android.app.RemoteAction> acts =
                new java.util.ArrayList<android.app.RemoteAction>();
        if (Build.VERSION.SDK_INT < 26) {
            return acts;
        }
        // 播放 / 暂停
        boolean playing = engine != null && engine.isPlaying();
        acts.add(makePipAction(ACTION_PLAY_PAUSE, playing ? "暂停" : "播放",
                playing ? R.drawable.ic_pause : R.drawable.ic_play));
        // 快退 10 秒
        acts.add(makePipAction(ACTION_SEEK_BACK, "快退 10 秒", R.drawable.ic_rew));
        // 快进 10 秒
        acts.add(makePipAction(ACTION_SEEK_FWD, "快进 10 秒", R.drawable.ic_ff));
        return acts;
    }

    private android.app.RemoteAction makePipAction(String action, String title, int icon) {
        android.graphics.drawable.Icon ic =
                android.graphics.drawable.Icon.createWithResource(this, icon);
        PendingIntent pi = PendingIntent.getBroadcast(this, action.hashCode(),
                new Intent(action).setPackage(getPackageName()),
                PendingIntent.FLAG_UPDATE_CURRENT
                        | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        return new android.app.RemoteAction(ic, title, title, pi);
    }

    private static final String ACTION_PLAY_PAUSE = "com.shichen.player.PIP_PLAY";
    private static final String ACTION_SEEK_BACK = "com.shichen.player.PIP_BACK";
    private static final String ACTION_SEEK_FWD = "com.shichen.player.PIP_FWD";

    /** 接收小窗上自定义按钮的点击 */
    private void registerPipReceiver() {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_PLAY_PAUSE);
        f.addAction(ACTION_SEEK_BACK);
        f.addAction(ACTION_SEEK_FWD);
        android.content.BroadcastReceiver r = new android.content.BroadcastReceiver() {
            public void onReceive(Context c, Intent i) {
                if (i == null || i.getAction() == null) {
                    return;
                }
                if (ACTION_PLAY_PAUSE.equals(i.getAction())) {
                    if (engine != null && engine.isPlaying()) {
                        togglePlay();
                    } else {
                        togglePlay();
                    }
                    updatePipActions();
                } else if (ACTION_SEEK_BACK.equals(i.getAction())) {
                    seekRelative(-10000);
                } else if (ACTION_SEEK_FWD.equals(i.getAction())) {
                    seekRelative(10000);
                }
            }
        };
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(r, f);
            }
            pipReceiver = r;
        } catch (Exception ignored) {
        }
    }

    private android.content.BroadcastReceiver pipReceiver;

    private void seekRelative(long deltaMs) {
        if (engine == null || duration <= 0) {
            return;
        }
        long p = engine.position() + deltaMs;
        if (p < 0) {
            p = 0;
        }
        if (p > duration) {
            p = duration;
        }
        pendingSeekMs = p;
        pendingSeekAt = System.nanoTime();
        engine.seekTo(p);
        if (seek != null) {
            seek.setProgress((int) (p * 1000L / duration));
        }
        showHint(R.drawable.ic_ff, (deltaMs > 0 ? "+" : "") + (deltaMs / 1000) + "s", -1);
    }

    /** 切换播放状态后刷新小窗按钮图标 */
    private void updatePipActions() {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        if (!isInPictureInPictureMode()) {
            return;
        }
        try {
            PictureInPictureParams.Builder b = new PictureInPictureParams.Builder();
            b.setActions(buildPipActions());
            setPictureInPictureParams(b.build());
        } catch (Exception ignored) {
        }
    }

    public void setLocked(boolean l) {
        hideRestartPrompt();
        locked = l;
        if (topBar != null) {
            topBar.setVisibility(l ? View.GONE : View.VISIBLE);
        }
        if (bottomBar != null) {
            bottomBar.setVisibility(l ? View.GONE : View.VISIBLE);
        }
        // 锁定后解锁按钮默认隐藏，只有点击屏幕时才随控制条一起显现
        if (btnUnlock != null) {
            btnUnlock.setVisibility(View.GONE);
        }
        if (l && controlsVisible) {
            setControlsVisible(false);
        }
    }

    /** 有弹窗打开中：此时禁止控制条显示 */
    private boolean panelOpen = false;

    public void setPanelOpen(boolean v) {
        panelOpen = v;
        if (v) {
            hideControls();
        }
    }

    /** 保持控制条显示（取消已有的自动隐藏定时器） */
    private void keepControls() {
        main.removeCallbacks(hideControls);
    }

    /** 重新开始控制条自动隐藏倒计时 */
    private void scheduleHideControls() {
        main.removeCallbacks(hideControls);
        main.postDelayed(hideControls, Prefs.autoHideSec(this) * 1000L);
    }

    /** 打开任意功能弹窗时先隐藏播放器 UI，避免控制条和弹窗同时占屏 */
    public void hideControls() {
        // 弹窗打开期间反复收紧，防止被其它回调重新显示出来
        if (panelOpen) {
            main.postDelayed(new Runnable() {
                public void run() {
                    if (panelOpen) {
                        hideControls();
                    }
                }
            }, 200);
        }
        main.removeCallbacks(hideControls);
        if (controlsVisible) {
            setControlsVisible(false);
        } else {
            if (topBar != null) {
                topBar.setVisibility(View.GONE);
            }
            if (bottomBar != null) {
                bottomBar.setVisibility(View.GONE);
            }
        }
    }

    private void toggleControls() {
        setControlsVisible(!controlsVisible);
    }

    private void setControlsVisible(boolean v) {
        if (v && panelOpen) {
            return;   // 有弹窗时不允许显示控制条，避免与弹窗重叠
        }
        controlsVisible = v;
        if (topBar != null) {
            topBar.setVisibility(v && !locked ? View.VISIBLE : View.GONE);
        }
        if (bottomBar != null) {
            bottomBar.setVisibility(v && !locked ? View.VISIBLE : View.GONE);
        }
        // 解锁按钮：仅在已锁定时随控制条一起出现，点击屏幕才显现
        if (btnUnlock != null) {
            btnUnlock.setVisibility(locked && v ? View.VISIBLE : View.GONE);
            if (locked && v) {
                ((ImageView) btnUnlock).setColorFilter(0xFF9ED8FF);
            }
        }
        if (v) {
            main.removeCallbacks(hideControls);
            main.postDelayed(hideControls, Prefs.autoHideSec(this) * 1000L);
        }
    }

    private final Runnable hideControls = new Runnable() {
        public void run() {
            if (seekDragging) {
                // 正在拖进度条，延后再隐藏，绝不打断拖动
                main.postDelayed(hideControls, Prefs.autoHideSec(PlayerActivity.this) * 1000L);
                return;
            }
            if (controlsVisible) {
                setControlsVisible(false);
            }
        }
    };

    private final BroadcastReceiver headsetReceiver = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            if (!Prefs.headphonePause(PlayerActivity.this)) {
                return;
            }
            int state = i.getIntExtra("state", 1);
            if (state == 0 && engine != null && engine.isPlaying()) {
                engine.pause();
                btnPlay.setImageResource(R.drawable.ic_play);
            }
        }
    };

    public void onConfigurationChanged(Configuration cfg) {
        super.onConfigurationChanged(cfg);
        // 横竖屏切换：侧边面板的宽度/位置是按屏幕算的，不关会错位显示在角落
        closePanel();
        measureScreen();
        main.postDelayed(new Runnable() {
            public void run() {
                measureScreen();
                if (zoomScale != 1.0f) {
                    applyZoom();
                } else {
                    applyRatio();
                }
            }
        }, 260);
    }

    public void onPictureInPictureModeChanged(boolean inPip, Configuration cfg) {
        super.onPictureInPictureModeChanged(inPip, cfg);
        if (inPip) {
            if (topBar != null) {
                topBar.setVisibility(View.GONE);
            }
            if (bottomBar != null) {
                bottomBar.setVisibility(View.GONE);
            }
            if (subtitleView != null) {
                subtitleView.setVisibility(View.GONE);
            }
            // 小窗本来就小，顶部状态栏会遮挡画面 —— 进小窗一律隐藏
            if (statusOverlay != null) {
                statusOverlay.setVisibility(View.GONE);
            }
        } else {
            if (subtitleView != null) {
                subtitleView.setVisibility(subtitleOn ? View.VISIBLE : View.GONE);
            }
            applyStatusOverlay();
        }
    }

    protected void onPause() {
        super.onPause();
        if (engine != null) {
            long p = engine.position();
            if (p > 0 && duration > 0 && p < duration - 2000) {
                try {
                    saveProgress(p);
                } catch (Exception ignored) {
                }
            }
            // 小窗/画中画期间退到桌面属于正常场景，绝不能暂停播放
            boolean pip = Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode();
            if (!Prefs.backgroundPlay(this) && !inFloatWindow && !pip) {
                engine.pause();
                btnPlay.setImageResource(R.drawable.ic_play);
            }
        }
    }

    protected void onNewIntent(Intent in) {
        super.onNewIntent(in);
        setIntent(in);
        released = false;
        path = null;
        playlist.clear();
        resumePos = 0;
        parseIntent();
        if (titleView != null) {
            titleView.setText(title);
        }
        if (pathView != null) {
            pathView.setText(path);
        }
        open(Prefs.rememberPos(this) ? resumePos : 0);
    }

    /**
     * 回到前台：收起悬浮小窗并把画面还给播放页。
     * 否则会出现"全屏播放器 + 悬浮窗"两个画面并存且其中一个黑屏。
     */
    protected void onResume() {
        super.onResume();
        if (inFloatWindow) {
            closeFloatWindow();
        }
    }

    protected void onDestroy() {
        // 退出播放必须连小窗一起关掉，避免残留悬浮窗
        try {
            if (floatWindow != null) {
                floatWindow.dismiss();
                floatWindow = null;
            }
            inFloatWindow = false;
            useFloat = false;
        } catch (Exception ignored) {
        }
        try {
            if (pipReceiver != null) {
                unregisterReceiver(pipReceiver);
                pipReceiver = null;
            }
        } catch (Exception ignored) {
        }
        main.removeCallbacks(updateRunnable);
        releaseEngine();
        AudioFx.release();
        try {
            unregisterReceiver(headsetReceiver);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    public void toggleFav() {
        isFav = !isFav;
        db.setFav(path, isFav);
        updateFavIcon();
        Ui.toast(this, isFav ? "已收藏" : "已取消收藏");
    }

    /** 把当前视频所在目录的所有视频加入播放列表 */
    public void addFolderToList() {
        java.io.File f = new java.io.File(path);
        String dir = f.getParent();
        if (dir == null) {
            Ui.toast(this, "无法定位所在目录");
            return;
        }
        ArrayList<String> pl = new ArrayList<String>();
        java.io.File[] fs = dirFileList(dir);
        if (fs != null) {
            for (java.io.File x : fs) {
                pl.add(x.getAbsolutePath());
            }
        }
        if (pl.isEmpty()) {
            Ui.toast(this, "该目录下没有视频");
            return;
        }
        playlist = pl;
        index = pl.indexOf(path);
        if (index < 0) {
            pl.add(0, path);
            index = 0;
        }
        Ui.toast(this, "已加入 " + pl.size() + " 个视频");
    }

    private java.io.File[] dirFileList(String dir) {
        java.io.File d = new java.io.File(dir);
        java.io.File[] fs = d.listFiles();
        if (fs == null) {
            return null;
        }
        java.util.List<java.io.File> out = new ArrayList<java.io.File>();
        for (java.io.File x : fs) {
            if (x.isFile() && VideoScanner.isVideoName(x.getName())) {
                out.add(x);
            }
        }
        java.util.Collections.sort(out, new java.util.Comparator<java.io.File>() {
            public int compare(java.io.File a, java.io.File b) {
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        return out.toArray(new java.io.File[0]);
    }

    public void showUrlDialog() {
        Ui.input(this, getString(R.string.url_title), "", getString(R.string.url_hint), new Ui.OnText() {
            public void onText(String text) {
                if (text.length() == 0) {
                    return;
                }
                path = text;
                title = text;
                resumePos = 0;
                open(0);
            }
        });
    }

    public void applyRepeat(int mode) {
        repeatMode = mode;
        updateRepeatIcon();
        Ui.toast(this, SettingsPage.repeatName(mode));
    }


    private Runnable firstFrameCheck;
    private volatile boolean gotFrame = false;
    private int retryCount = 0;

    /** 首帧自检：3 秒内没渲染出画面就重建渲染表面并重试，解决黑屏 */
    private void startFirstFrameCheck() {
        cancelFirstFrameCheck();
        gotFrame = false;
        firstFrameCheck = new Runnable() {
            public void run() {
                if (released || gotFrame) {
                    return;
                }
                // 只要在播就认为正常，绝不重建渲染视图
                // （重建会销毁 surface，反而制造新的黑屏）
                if (engine != null && (engine.isPlaying() || engine.position() > 200)) {
                    gotFrame = true;
                    return;
                }
                if (retryCount >= 2) {
                    return;
                }
                retryCount++;
                // 第一次重试：切到最可靠的兼容模式（SurfaceView + 系统内核）
                Prefs.setRenderKind(PlayerActivity.this, VideoRenderView.KIND_SURFACE);
                Prefs.setDecodeMode(PlayerActivity.this, Prefs.DECODE_SYSTEM);
                Diagnostics.log("rescue", "switch to compatible mode, retry=" + retryCount);
                long p = engine == null ? 0 : engine.position();
                resumePos = p;
                open(p);
            }
        };
        main.postDelayed(firstFrameCheck, 5000);
    }


    private void cancelFirstFrameCheck() {
        if (firstFrameCheck != null) {
            main.removeCallbacks(firstFrameCheck);
            firstFrameCheck = null;
        }
    }

    private Runnable hideRestartRun;

    /** 续播提示：小胶囊按钮，5 秒后自动消失 */
    private void showRestartPrompt() {
        if (btnRestart == null) {
            return;
        }
        btnRestart.setVisibility(View.VISIBLE);
        btnRestart.setAlpha(0f);
        btnRestart.animate().alpha(0.9f).setDuration(180).start();
        if (hideRestartRun != null) {
            main.removeCallbacks(hideRestartRun);
        }
        hideRestartRun = new Runnable() {
            public void run() {
                if (btnRestart != null) {
                    btnRestart.animate().alpha(0f).setDuration(220)
                            .withEndAction(new Runnable() {
                        public void run() {
                            if (btnRestart != null) {
                                btnRestart.setVisibility(View.GONE);
                            }
                        }
                    }).start();
                }
            }
        };
        main.postDelayed(hideRestartRun, 5000);
    }

    private void hideRestartPrompt() {
        if (hideRestartRun != null) {
            main.removeCallbacks(hideRestartRun);
            hideRestartRun = null;
        }
        if (btnRestart != null && btnRestart.getVisibility() == View.VISIBLE) {
            btnRestart.setVisibility(View.GONE);
        }
    }

    private void restartFromStart() {
        hideRestartPrompt();
        resumePos = 0;
        if (engine != null) {
            engine.seekTo(0);
            if (!engine.isPlaying()) {
                engine.start();
                if (btnPlay != null) {
                    btnPlay.setImageResource(R.drawable.ic_pause);
                }
            }
        }
        Ui.toast(this, "从头播放");
    }

    private void onClick(int id, View.OnClickListener l) {
        View v = findViewById(id);
        if (v != null) {
            v.setOnClickListener(l);
        }
    }

    public void openPlaySettings() {
        hideControls();
        PlaySettingsPanel p = new PlaySettingsPanel(this);
        View body = p.build();
        if (getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE) {
            trackPanel(Ui.side(this, body));
        } else {
            // 竖屏与横屏共用同一个 PlaySettingsPanel，内容完全一致
            trackPanel(Ui.panel(this, "播放设置", body, false, null));
        }
    }

    /** 顶栏工具：圆形图标网格面板 */
    /** 登记当前面板；打开新面板或切换视频时自动关闭旧的 */
    private void trackPanel(AlertDialog d) {
        if (d == null) {
            panelOpen = false;
            return;
        }
        panelOpen = true;
        if (currentPanel != null && currentPanel != d) {
            try {
                currentPanel.dismiss();
            } catch (Exception ignored) {
            }
        }
        currentPanel = d;
        // 关键：面板关闭（点 X、点外部、返回键）时必须清标志，
        // 否则控制条会一直被判定为"弹窗打开中"而永远不显示
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface dd) {
                if (currentPanel == dd) {
                    currentPanel = null;
                }
                if (playlistPanel != null) {
                    playlistPanel = null;
                }
                panelOpen = false;
            }
        });
    }

    /** 关闭并清空当前面板（切集、旋屏时调用） */
    private void closePanel() {
        panelOpen = false;
        if (currentPanel != null) {
            try {
                if (currentPanel.isShowing()) {
                    currentPanel.dismiss();
                }
            } catch (Exception ignored) {
            }
            currentPanel = null;
        }
    }

    public void openTools() {
        hideControls();
        PlayToolsPanel p = new PlayToolsPanel(this);
        View body = p.build();
        // 横屏时工具面板贴在右半边，不遮挡画面
        if (getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE) {
            trackPanel(Ui.side(this, body));
        } else {
            trackPanel(Ui.panel(this, "播放工具", body, false, null));
        }
    }

    /** 供均衡器面板取用时尘内核内置 EQ；非时尘内核时返回 null */
    public com.hwdecoder.Equalizer hwEqualizer() {
        if (engine instanceof HwEngine) {
            try {
                return ((HwEngine) engine).equalizer();
            } catch (Throwable ignored) {
            }
        }
        return null;
    }

    public void openEqualizer() {
        // 改为播放界面内弹窗，不再跳转独立页面
        hideControls();
        EqualizerPanel eq = new EqualizerPanel(this);
        View body = eq.build();
        if (getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE) {
            trackPanel(Ui.side(this, body));
        } else {
            trackPanel(Ui.panel(this, "均衡器", body, false, null));
        }
        return;
    }

    public float speed() {
        return speed;
    }

    public void applySpeed(float s) {
        speed = s;
        savedSpeed = s;
        if (btnSpeed != null) {
            btnSpeed.setText(MediaUtils.formatSpeed(s));
        }
        if (engine != null) {
            engine.setSpeed(s);
        }
    }

    public int ratio() {
        return ratio;
    }

    public void applyRatio(int r) {
        ratio = r;
        zoomScale = 1.0f;
        applyRatio();
    }

    public void applyOrientation(int o) {
        Prefs.setOrientation(this, o);
        applyOrientation();
    }

    public float zoom() {
        return zoomScale;
    }

    public void applyZoom(float z) {
        zoomScale = z;
        applyZoom();
    }

    public void reloadEngine() {
        long pos = engine == null ? 0 : engine.position();
        resumePos = pos;
        open(pos);
    }

    public void openTracks() {
        showTracks();
    }

    public void openSubtitleMenu() {
        showSubtitleMenu();
    }

    public void applySubtitleStyle() {
        if (subtitleView != null) {
            subtitleView.setSizeSp(Prefs.subtitleSize(this));
        subtitleView.setOutline(Prefs.subtitleOutline(this));
        subtitleView.setBottomMargin(Prefs.subtitleBottom(this));
            subtitleView.setDelayMs(Prefs.subtitleDelay(this));
            subtitleView.setColor(subtitleColor());
        }
    }

    public void applyBrightness(float b) {
        setBrightness(b);
    }

    public void applyVolume(float v) {
        setVolume(v);
    }


    /** 声道平衡 */
    public void applyBalance(int v) {
        if (engine == null) {
            return;
        }
        float l = v <= 50 ? 1.0f : (100 - v) / 50f;
        float r = v >= 50 ? 1.0f : v / 50f;
        engine.setVolume(l, r);
    }

    /** 书签列表（当前会话内的书签） */
    private final java.util.ArrayList<Long> bookmarks = new java.util.ArrayList<Long>();

    public void showBookmarks() {
        final java.util.List<Long> marks = bookmarks;

        java.util.Collections.sort(marks);
        String[] names = new String[marks.size() + 1];
        names[0] = "＋ 添加当前位置为书签";
        for (int i = 0; i < marks.size(); i++) {
            names[i + 1] = MediaUtils.formatDuration(marks.get(i));
        }
        Ui.sheet(this, "书签", names, -1, new Ui.OnPick() {
            public void onPick(int i) {
                if (i == 0) {
                    long p = engine == null ? 0 : engine.position();
                    bookmarks.add(p);
                    Ui.toast(PlayerActivity.this, "已添加书签 "
                            + MediaUtils.formatDuration(p));
                } else if (i - 1 < marks.size() && engine != null) {
                    engine.seekTo(marks.get(i - 1));
                }
            }
        });
    }

    public void clearAb() {
        abA = -1;
        abB = -1;
        if (btnAb != null) {
            btnAb.setAlpha(0.6f);
        }
        if (seek != null) {
            seek.invalidate();
        }
    }

    /** 控制栏右侧可自定义按键的选项定义 */
    static final String[] CTRL_IDS = {
            "speed", "aspect", "pip", "rotate", "lock", "playlist", "shot", "subtitle",
            "ab", "repeat", "eq", "decode", "boost", "bright", "sleep", "info",
            "flip", "bookmark", "share", "jump",
    };
    static final int[] CTRL_ICONS = {
            R.drawable.ic_speed, R.drawable.ic_ratio, R.drawable.ic_pip,
            R.drawable.ic_screen_rotate, R.drawable.ic_lock, R.drawable.ic_playlist,
            R.drawable.ic_screenshot, R.drawable.ic_subtitle, R.drawable.ic_ab,
            R.drawable.ic_repeat, R.drawable.ic_equalizer, R.drawable.ic_decode,
            R.drawable.ic_volume, R.drawable.ic_brightness, R.drawable.ic_sleep,
            R.drawable.ic_info, R.drawable.ic_flip, R.drawable.ic_bookmark,
            R.drawable.ic_share, R.drawable.ic_jump,
    };
    static final String[] CTRL_LABELS = {
            "倍速", "画面比例", "小窗", "屏幕方向", "锁定", "播放列表", "截图", "字幕",
            "A-B循环", "循环模式", "均衡器", "解码", "音量放大", "亮度音量", "睡眠定时",
            "信息", "视频翻转", "书签", "分享", "跳转",
    };

    /** 重建控制栏右侧按键（默认 倍速/画面比例/小窗，最多 5 个，可留空） */
    public void rebuildActionBar() {
        View bar = findViewById(R.id.action_bar);
        if (!(bar instanceof LinearLayout)) {
            return;
        }
        LinearLayout ll = (LinearLayout) bar;
        ll.removeAllViews();
        // 从右往左排：容器靠右，第一个键在最右侧
        ll.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        // 复位旧引用，避免操作已脱离视图树的控件
        btnSpeed = null;
        btnAspect = null;
        btnPip = null;

        int dm = (int) getResources().getDisplayMetrics().density;
        String saved = Prefs.controlKeys(this);
        if (saved == null || saved.length() == 0) {
            return;
        }
        String[] keys0 = saved.split(",");
        // 反转：保存顺序的第一个键显示在最右侧（从右往左走）
        java.util.List<String> kl = new java.util.ArrayList<String>();
        for (String k : keys0) {
            if (k != null && k.length() > 0) {
                kl.add(k);
            }
        }
        java.util.Collections.reverse(kl);
        String[] keys = kl.toArray(new String[0]);
        int count = 0;
        for (String key : keys) {
            if (key == null || key.length() == 0 || count >= 5) {
                continue;
            }
            int idx = -1;
            for (int i = 0; i < CTRL_IDS.length; i++) {
                if (CTRL_IDS[i].equals(key)) {
                    idx = i;
                    break;
                }
            }
            if (idx < 0) {
                continue;
            }
            View v;
            if ("speed".equals(key)) {
                // 倍速用文字按钮，显示当前倍率
                TextView tv = new TextView(this);
                tv.setText(MediaUtils.formatSpeed(speed));
                tv.setTextColor(0xFFFFFFFF);
                tv.setTextSize(13f);
                tv.setGravity(Gravity.CENTER);
                tv.setTypeface(null, android.graphics.Typeface.BOLD);
                tv.setAlpha(0.92f);
                tv.setLayoutParams(new LinearLayout.LayoutParams(
                        46 * dm, 34 * dm));
                tv.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v2) {
                        showSpeedPanel();
                    }
                });
                btnSpeed = tv;
                v = tv;
            } else {
                ImageButton b = new ImageButton(this);
                b.setImageResource(CTRL_ICONS[idx]);
                b.setBackgroundResource(android.R.color.transparent);
                b.setScaleType(ImageView.ScaleType.FIT_CENTER);
                b.setColorFilter(0xFFF0F0F8);
                b.setPadding(6 * dm, 6 * dm, 6 * dm, 6 * dm);
                b.setLayoutParams(new LinearLayout.LayoutParams(40 * dm, 40 * dm));
                final String k = key;
                b.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v2) {
                        onControlAction(k);
                    }
                });
                if ("aspect".equals(key)) {
                    btnAspect = b;
                } else if ("pip".equals(key)) {
                    btnPip = b;
                }
                v = b;
            }
            ll.addView(v);
            count++;
        }
    }

    /** 控制栏按键的功能分发 */
    private void onControlAction(String key) {
        if ("aspect".equals(key)) {
            showRatio();
        } else if ("pip".equals(key)) {
            enterPip();
        } else if ("rotate".equals(key)) {
            showOrientationMenu();
        } else if ("lock".equals(key)) {
            setLocked(true);
        } else if ("playlist".equals(key)) {
            showPlaylist();
        } else if ("shot".equals(key)) {
            screenshot();
        } else if ("subtitle".equals(key)) {
            showSubtitleMenu();
        } else if ("ab".equals(key)) {
            toggleAb();
        } else if ("repeat".equals(key)) {
            showRepeatMenu();
        } else if ("eq".equals(key)) {
            openEqualizer();
        } else if ("decode".equals(key)) {
            showDecodeMenu();
        } else if ("boost".equals(key)) {
            showBoostMenu();
        } else if ("bright".equals(key)) {
            showBrightVolMenu();
        } else if ("sleep".equals(key)) {
            showSleep();
        } else if ("info".equals(key)) {
            showInfo();
        } else if ("flip".equals(key)) {
            showFlipMenu();
        } else if ("bookmark".equals(key)) {
            showBookmarks();
        } else if ("share".equals(key)) {
            shareCurrent();
        } else if ("jump".equals(key)) {
            showJumpMenu();
        }
    }

    private void showRatioMenuAlias() {
    }


    public void showOrientationMenu() {
        new PlayToolsPanel(this).doOrientation();
    }

    public void showRepeatMenu() {
        new PlayToolsPanel(this).doRepeat();
    }

    public void showDecodeMenu() {
        new PlayToolsPanel(this).doDecode();
    }

    public void showBoostMenu() {
        new PlayToolsPanel(this).doBoost();
    }

    public void showBrightVolMenu() {
        new PlayToolsPanel(this).doBrightVol();
    }

    public void showFlipMenu() {
        new PlayToolsPanel(this).doFlip();
    }

    public void showJumpMenu() {
        new PlayToolsPanel(this).doJump();
    }

    /** 面板透明度设置改动后，立即刷新当前显示的面板 */
    public void refreshPanelBg() {
        Ui.refreshPanelBg(this, currentPanel);
    }

    public void refreshCurrentPanelBg() {
        Ui.refreshPanelBg(this, currentPanel);
    }

    /** 面板透明度改变后立即刷新当前打开的面板背景，做到实时生效 */
    public void refreshPanelAlpha() {
        if (currentPanel == null) {
            return;
        }
        try {
            android.view.Window w = currentPanel.getWindow();
            if (w == null) {
                return;
            }
            float dm = getResources().getDisplayMetrics().density;
            android.graphics.drawable.GradientDrawable gd =
                    new android.graphics.drawable.GradientDrawable();
            gd.setColor(Ui.panelColor(this));
            gd.setCornerRadius(20 * dm);
            w.setBackgroundDrawable(gd);
        } catch (Exception ignored) {
        }
    }

    public void applyFlip(int flip) {
        Prefs.setVideoFlip(this, flip);
        if (renderView != null) {
            renderView.setFlip(flip);
        }
    }

    public void applyUserRotate(int r) {
        Prefs.setVideoRotate(this, r);
        if (renderView != null) {
            renderView.setUserRotate(r);
        }
        if (Prefs.orientation(this) == Prefs.O_VIDEO) {
            applyOrientation();
        }
    }

    public void applyBoost(float b) {
        try {
            // 系统内核（MediaPlayer）拿不到 PCM，无法真正放大；
            // 需要放大时自动切到自研内核，放大才有效
            if (engine instanceof HwEngine) {
                ((HwEngine) engine).setBoost(b);
                return;
            }
            if (b > 1.001f && engine instanceof SystemEngine) {
                Ui.toast(this, "音量放大需要自研内核，已自动切换");
                Prefs.setDecodeMode(this, 1);
                reloadEngine();
                return;
            }
            if (engine instanceof SystemEngine) {
                ((SystemEngine) engine).setBoost(b);
            } else if (engine instanceof CodecEngine) {
                ((CodecEngine) engine).setBoost(b);
            }
            engine.setVolume(1.0f, 1.0f);
        } catch (Exception ignored) {
        }
    }

    public void applyStatus() {
        applyStatusOverlay();
    }

    public void applyHq(boolean on) {
        if (renderView != null) {
            renderView.setHighQuality(on);
        }
    }

    public Activity activity() {
        return this;
    }

    public void onBackPressed() {
        if (locked) {
            Ui.toast(this, getString(R.string.player_locked));
            return;
        }
        // 先停解码再退出，避免退出瞬间回调打到已销毁的视图上
        try {
            cancelWatchdog();
            cancelFirstFrameCheck();
            if (engine != null) {
                engine.pause();
            }
        } catch (Exception ignored) {
        }
        try {
            super.onBackPressed();
        } catch (Exception ignored) {
            finish();
        }
    }
}
