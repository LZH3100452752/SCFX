package com.shichen.player;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.LruCache;
import android.widget.ImageView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThumbLoader {
    private static final int MEM = (int) (Runtime.getRuntime().maxMemory() / 8);
    private static LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(MEM) {
        protected int sizeOf(String k, Bitmap v) {
            return v.getByteCount() / 1024;
        }
    };
    private static ExecutorService pool = Executors.newFixedThreadPool(3);
    private static Handler main = new Handler(Looper.getMainLooper());
    private static Context app;

    public static void init(Context c) {
        app = c.getApplicationContext();
    }

    /** 同步取某一时刻的缩略图（用于拖动进度条预览） */
    public static Bitmap frameAt(String path, long timeMs) {
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(path);
            if (android.os.Build.VERSION.SDK_INT >= 27) {
                return mmr.getScaledFrameAtTime(timeMs * 1000L,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 320, 180);
            }
            return mmr.getFrameAtTime(timeMs * 1000L,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
        } catch (Exception e) {
            return null;
        } finally {
            try {
                mmr.release();
            } catch (Exception ignored) {
            }
        }
    }

    public static void load(final VideoItem item, final ImageView view) {
        if (view == null || item == null) {
            return;
        }
        final String key = item.path;
        Bitmap b = cache.get(key);
        if (b != null) {
            view.setImageBitmap(b);
            return;
        }
        view.setImageDrawable(null);
        view.setTag(key);
        pool.execute(new Runnable() {
            public void run() {
                Bitmap bm = get(key, item.id);
                if (bm != null) {
                    cache.put(key, bm);
                }
                final Bitmap fb = bm;
                main.post(new Runnable() {
                    public void run() {
                        if (key.equals(view.getTag()) && fb != null) {
                            view.setImageBitmap(fb);
                        }
                    }
                });
            }
        });
    }

    private static Bitmap get(String path, long id) {
        Bitmap bm = null;
        if (id > 0 && app != null) {
            try {
                bm = MediaStore.Video.Thumbnails.getThumbnail(app.getContentResolver(), id,
                        MediaStore.Video.Thumbnails.MINI_KIND, null);
            } catch (Exception ignored) {
            }
        }
        if (bm == null) {
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            try {
                mmr.setDataSource(path);
                bm = mmr.getFrameAtTime(2000000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                if (bm != null) {
                    int w = bm.getWidth();
                    int h = bm.getHeight();
                    int tw = 320;
                    if (w > tw) {
                        bm = Bitmap.createScaledBitmap(bm, tw, Math.max(1, h * tw / w), true);
                    }
                }
            } catch (Exception ignored) {
            } finally {
                try {
                    mmr.release();
                } catch (Exception ignored2) {
                }
            }
        }
        return bm;
    }

    public static void clear() {
        cache.evictAll();
    }
}
