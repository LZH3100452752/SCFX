package com.shichen.player;

import java.util.List;

public interface PlayerEngine {
    /** 0 视频 1 音频 2 字幕 */
    class TrackInfo {
        public int index;
        public int type;
        public String mime;
        public String lang;
        public boolean selected;

        public TrackInfo(int index, int type, String mime) {
            this.index = index;
            this.type = type;
            this.mime = mime;
        }

        public TrackInfo(int index, int type, String mime, String lang) {
            this(index, type, mime);
            this.lang = lang;
        }

        public String label() {
            StringBuilder sb = new StringBuilder();
            sb.append("#").append(index).append("  ");
            if (mime != null) {
                sb.append(mime.replace("video/", "").replace("audio/", "")
                        .replace("application/", "").replace("text/", ""));
            }
            if (lang != null && lang.length() > 0 && !lang.equals("und")) {
                sb.append(" (").append(lang).append(")");
            }
            return sb.toString();
        }
    }

    interface Callback {
        void onPrepared(int width, int height, long durationMs);

        void onFirstFrame();

        void onBuffering(int percent);

        void onError(String msg);

        void onCompletion();
    }

    void setCallback(Callback cb);

    void setSurface(android.view.Surface s);

    void prepare(android.content.Context c, String path, long startMs) throws Exception;

    void start();

    void pause();

    void seekTo(long ms);

    long position();

    long duration();

    boolean isPlaying();

    void setSpeed(float speed);

    void setVolume(float left, float right);

    int buffered();

    List<TrackInfo> tracks();

    void selectTrack(int index);

    void release();

    String engineName();

    int audioSessionId();
}
