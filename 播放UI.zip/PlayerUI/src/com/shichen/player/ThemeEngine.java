package com.shichen.player;

import android.app.Activity;
import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.widget.ImageView;
import android.widget.TextView;

public class ThemeEngine {
    public static final String[] ACCENT_NAMES = {
            "星夜紫", "流光青", "落日橙", "新芽绿", "樱花粉", "深海蓝",
            "烈焰红", "孔雀蓝", "青柠绿", "紫罗兰", "香槟金", "靛青蓝"
    };

    private static final int[] DARK = {
            R.style.Theme_Shi_Dark_Purple, R.style.Theme_Shi_Dark_Cyan,
            R.style.Theme_Shi_Dark_Orange, R.style.Theme_Shi_Dark_Green,
            R.style.Theme_Shi_Dark_Pink, R.style.Theme_Shi_Dark_Blue,
            R.style.Theme_Shi_Dark_Red, R.style.Theme_Shi_Dark_Teal,
            R.style.Theme_Shi_Dark_Lime, R.style.Theme_Shi_Dark_Violet,
            R.style.Theme_Shi_Dark_Gold, R.style.Theme_Shi_Dark_Indigo
    };
    private static final int[] BLACK = {
            R.style.Theme_Shi_Black_Purple, R.style.Theme_Shi_Black_Cyan,
            R.style.Theme_Shi_Black_Orange, R.style.Theme_Shi_Black_Green,
            R.style.Theme_Shi_Black_Pink, R.style.Theme_Shi_Black_Blue,
            R.style.Theme_Shi_Black_Red, R.style.Theme_Shi_Black_Teal,
            R.style.Theme_Shi_Black_Lime, R.style.Theme_Shi_Black_Violet,
            R.style.Theme_Shi_Black_Gold, R.style.Theme_Shi_Black_Indigo
    };
    private static final int[] LIGHT = {
            R.style.Theme_Shi_Light_Purple, R.style.Theme_Shi_Light_Cyan,
            R.style.Theme_Shi_Light_Orange, R.style.Theme_Shi_Light_Green,
            R.style.Theme_Shi_Light_Pink, R.style.Theme_Shi_Light_Blue,
            R.style.Theme_Shi_Light_Red, R.style.Theme_Shi_Light_Teal,
            R.style.Theme_Shi_Light_Lime, R.style.Theme_Shi_Light_Violet,
            R.style.Theme_Shi_Light_Gold, R.style.Theme_Shi_Light_Indigo
    };

    public static final String[] MODE_NAMES = {"深色", "纯黑", "浅色"};

    public static int themeRes(Context c) {
        int i = Prefs.accent(c);
        if (i < 0 || i >= DARK.length) {
            i = 0;
        }
        switch (Prefs.themeMode(c)) {
            case Prefs.T_BLACK:
                return BLACK[i];
            case Prefs.T_LIGHT:
                return LIGHT[i];
            default:
                return DARK[i];
        }
    }

    /** 热加载：不重启 Activity 也能切换主题（对后续 inflate 的视图生效） */
    public static void applyDynamic(Activity a) {
        a.getTheme().applyStyle(themeRes(a), true);
        android.content.res.Resources.Theme t = a.getTheme();
        // 同步窗口背景，避免主题色残留
        try {
            android.util.TypedValue tv = new android.util.TypedValue();
            t.resolveAttribute(android.R.attr.windowBackground, tv, true);
            if (tv.resourceId != 0) {
                a.getWindow().setBackgroundDrawableResource(tv.resourceId);
            }
        } catch (Exception ignored) {
        }
    }

    /** 播放页强制深色（保证控制条可读性） */
    public static int playerThemeRes(Context c) {
        int i = Prefs.accent(c);
        if (i < 0 || i >= DARK.length) {
            i = 0;
        }
        return Prefs.themeMode(c) == Prefs.T_BLACK ? BLACK[i] : DARK[i];
    }

    public static void apply(Activity a) {
        a.setTheme(themeRes(a));
    }

    public static int attr(Context c, int attrId) {
        TypedValue tv = new TypedValue();
        c.getTheme().resolveAttribute(attrId, tv, true);
        return tv.data;
    }

    public static int accent(Context c) {
        return attr(c, R.attr.scAccent);
    }

    public static int text(Context c) {
        return attr(c, R.attr.scText);
    }

    public static int sub(Context c) {
        return attr(c, R.attr.scSub);
    }

    public static int card(Context c) {
        return attr(c, R.attr.scCard);
    }

    public static int cardHi(Context c) {
        return attr(c, R.attr.scCardHi);
    }

    public static int bg(Context c) {
        return attr(c, R.attr.scBg);
    }

    public static void tint(ImageView v, int color) {
        if (v == null) {
            return;
        }
        Drawable d = v.getDrawable();
        if (d != null) {
            d.mutate().setColorFilter(color, PorterDuff.Mode.SRC_ATOP);
        }
    }

    public static void tintIcon(ImageView v, int resId, int color) {
        if (v == null) {
            return;
        }
        v.setImageResource(resId);
        tint(v, color);
    }

    public static void tintRes(ImageView v, int color) {
        if (v == null) {
            return;
        }
        Drawable d = v.getDrawable();
        if (d != null) {
            d.mutate().setColorFilter(color, PorterDuff.Mode.SRC_ATOP);
        }
    }

    public static void setColor(TextView v, int color) {
        if (v != null) {
            v.setTextColor(color);
        }
    }
}
