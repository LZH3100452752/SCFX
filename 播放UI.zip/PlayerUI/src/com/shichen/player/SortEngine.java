package com.shichen.player;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** 排序引擎：12 种字段 × 升/降序 */
public class SortEngine {

    public static String[] fieldNames() {
        return new String[]{"标题", "添加日期", "修改时间", "播放时间", "观看状态",
                "时长", "大小", "分辨率", "路径", "帧率", "类型", "文件名"};
    }

    /** 升序时该字段的语义标签（如 时长→最短） */
    public static String ascLabel(Context2 c, int field) {
        switch (field) {
            case Prefs.S_DURATION:
                return "最短";
            case Prefs.S_SIZE:
                return "最小";
            case Prefs.S_DATE:
            case Prefs.S_MODIFIED:
            case Prefs.S_PLAYTIME:
                return "最旧";
            case Prefs.S_TITLE:
            case Prefs.S_NAME:
            case Prefs.S_PATH:
                return "A→Z";
            case Prefs.S_RESOLUTION:
                return "最低";
            case Prefs.S_STATUS:
                return "未看优先";
            case Prefs.S_FPS:
                return "最低";
            default:
                return "升序";
        }
    }

    public static String descLabel(Context2 c, int field) {
        switch (field) {
            case Prefs.S_DURATION:
                return "最长";
            case Prefs.S_SIZE:
                return "最大";
            case Prefs.S_DATE:
            case Prefs.S_MODIFIED:
            case Prefs.S_PLAYTIME:
                return "最新";
            case Prefs.S_TITLE:
            case Prefs.S_NAME:
            case Prefs.S_PATH:
                return "Z→A";
            case Prefs.S_RESOLUTION:
                return "最高";
            case Prefs.S_STATUS:
                return "已看优先";
            case Prefs.S_FPS:
                return "最高";
            default:
                return "降序";
        }
    }

    /** 升序时的区间语义（如 时长→"最短→最长"），表示从上往下的排列方向 */
    public static String rangeLabel(int field) {
        switch (field) {
            case Prefs.S_DURATION:
                return "最短 → 最长";
            case Prefs.S_SIZE:
                return "最小 → 最大";
            case Prefs.S_DATE:
            case Prefs.S_MODIFIED:
                return "最旧 → 最新";
            case Prefs.S_PLAYTIME:
                return "最早看 → 最近看";
            case Prefs.S_TITLE:
            case Prefs.S_NAME:
            case Prefs.S_PATH:
                return "A → Z";
            case Prefs.S_RESOLUTION:
                return "最低 → 最高";
            case Prefs.S_FPS:
                return "低帧率 → 高帧率";
            case Prefs.S_STATUS:
                return "未看 → 已看";
            default:
                return "升序";
        }
    }

    /** 降序时的区间语义（各项顺序反转） */
    public static String rangeLabelDesc(int field) {
        switch (field) {
            case Prefs.S_DURATION:
                return "最长 → 最短";
            case Prefs.S_SIZE:
                return "最大 → 最小";
            case Prefs.S_DATE:
            case Prefs.S_MODIFIED:
                return "最新 → 最旧";
            case Prefs.S_PLAYTIME:
                return "最近看 → 最早看";
            case Prefs.S_TITLE:
            case Prefs.S_NAME:
            case Prefs.S_PATH:
                return "Z → A";
            case Prefs.S_RESOLUTION:
                return "最高 → 最低";
            case Prefs.S_FPS:
                return "高帧率 → 低帧率";
            case Prefs.S_STATUS:
                return "已看 → 未看";
            default:
                return "降序";
        }
    }

    public static String summary(Context2 c, int field, boolean asc) {
        return fieldNames()[field] + " · " + (asc ? ascLabel(c, field) : descLabel(c, field));
    }

    public static void sort(List<VideoItem> list, final int field, final boolean asc) {
        Collections.sort(list, new Comparator<VideoItem>() {
            public int compare(VideoItem a, VideoItem b) {
                int r = cmpField(a, b, field);
                return asc ? r : -r;
            }
        });
    }

    private static int cmpField(VideoItem a, VideoItem b, int field) {
        switch (field) {
            case Prefs.S_TITLE:
                return strCmp(a.nameNoExt(), b.nameNoExt());
            case Prefs.S_NAME:
                return strCmp(a.title, b.title);
            case Prefs.S_DATE:
                return cmp(a.dateAdded, b.dateAdded);
            case Prefs.S_MODIFIED:
                return cmp(a.dateModified, b.dateModified);
            case Prefs.S_PLAYTIME:
                return cmp(a.lastPlay, b.lastPlay);
            case Prefs.S_STATUS:
                return cmp(a.watchState(), b.watchState());
            case Prefs.S_DURATION:
                return cmp(a.duration, b.duration);
            case Prefs.S_SIZE:
                return cmp(a.size, b.size);
            case Prefs.S_RESOLUTION:
                return cmp(a.pixels(), b.pixels());
            case Prefs.S_PATH:
                return strCmp(a.path, b.path);
            case Prefs.S_FPS:
                return cmp(a.fps, b.fps);
            case Prefs.S_TYPE:
                int e = strCmp(a.ext(), b.ext());
                return e != 0 ? e : strCmp(a.title, b.title);
            default:
                return 0;
        }
    }

    /**
     * 标准升序比较（小在前）。
     * 之前这里写成了倒序，再配合 sort() 里的 asc?r:-r，
     * 导致"升序"实际排出从大到小 —— 选"最长→最短"却得到"最短→最长"。
     */
    private static int cmp(long a, long b) {
        return a < b ? -1 : (a > b ? 1 : 0);
    }

    private static int strCmp(String a, String b) {
        String x = a == null ? "" : a.toLowerCase(Locale.getDefault());
        String y = b == null ? "" : b.toLowerCase(Locale.getDefault());
        return x.compareTo(y);
    }

    /** 轻量上下文占位，避免依赖 android 类 */
    public static class Context2 {
    }
}
