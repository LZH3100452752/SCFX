package com.shichen.player;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

public class PlaybackService extends Service {

    public static final String ACTION_START = "com.shichen.player.START";
    public static final String ACTION_PAUSE = "com.shichen.player.PAUSE";
    public static final String ACTION_RESUME = "com.shichen.player.RESUME";
    public static final String ACTION_STOP = "com.shichen.player.STOP";
    private static final String CH = "shichen_play";
    private static final int ID = 20101;

    private MediaPlayer mp;
    private String path = "";
    private String title = "";
    private long startMs = 0;
    private boolean paused = false;
    private static int sessionId = 0;

    public static int sessionId() {
        return sessionId;
    }

    public IBinder onBind(Intent i) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "时尘后台播放",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("后台音频播放控制");
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.createNotificationChannel(ch);
            }
        }
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            return START_NOT_STICKY;
        }
        String act = intent.getAction();
        if (ACTION_STOP.equals(act)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_PAUSE.equals(act)) {
            if (mp != null && mp.isPlaying()) {
                mp.pause();
                paused = true;
                updateNotify();
            }
            return START_STICKY;
        }
        if (ACTION_RESUME.equals(act)) {
            if (mp != null && !mp.isPlaying()) {
                mp.start();
                paused = false;
                updateNotify();
            }
            return START_STICKY;
        }
        if (ACTION_START.equals(act)) {
            path = intent.getStringExtra("path");
            title = intent.getStringExtra("title");
            startMs = intent.getLongExtra("pos", 0);
            startPlay();
        }
        return START_STICKY;
    }

    private void startPlay() {
        if (path == null || path.length() == 0) {
            stopSelf();
            return;
        }
        try {
            if (mp != null) {
                mp.release();
            }
            mp = new MediaPlayer();
            mp.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
            if (path.startsWith("content://") || path.startsWith("http")) {
                mp.setDataSource(this, Uri.parse(path));
            } else {
                mp.setDataSource(path);
            }
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(MediaPlayer m) {
                    if (startMs > 0) {
                        try {
                            m.seekTo((int) startMs);
                        } catch (Exception ignored) {
                        }
                    }
                    m.start();
                    sessionId = m.getAudioSessionId();
                    paused = false;
                    updateNotify();
                }
            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer m) {
                    stopSelf();
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                public boolean onError(MediaPlayer m, int what, int extra) {
                    stopSelf();
                    return true;
                }
            });
            mp.prepareAsync();
            updateNotify();
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void updateNotify() {
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            nb = new Notification.Builder(this, CH);
        } else {
            nb = new Notification.Builder(this);
        }
        nb.setContentTitle("时尘播放器");
        nb.setContentText((paused ? "已暂停 · " : "正在播放 · ") + title);
        nb.setSmallIcon(R.drawable.ic_play);
        nb.setOngoing(true);
        Intent open = new Intent(this, PlayerActivity.class);
        open.putExtra("path", path);
        open.putExtra("title", title);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 1, open,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        nb.setContentIntent(pi);
        int flag = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        if (paused) {
            nb.addAction(R.drawable.ic_play, "继续", pi(getServiceIntent(ACTION_RESUME), 2, flag));
        } else {
            nb.addAction(R.drawable.ic_pause, "暂停", pi(getServiceIntent(ACTION_PAUSE), 3, flag));
        }
        nb.addAction(R.drawable.ic_close, "停止", pi(getServiceIntent(ACTION_STOP), 4, flag));
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startForeground(ID, nb.build());
    }

    private PendingIntent pi(Intent i, int code, int flag) {
        return PendingIntent.getService(this, code, i, flag);
    }

    private Intent getServiceIntent(String action) {
        Intent i = new Intent(this, PlaybackService.class);
        i.setAction(action);
        return i;
    }

    public void onDestroy() {
        if (mp != null) {
            try {
                if (mp.isPlaying()) {
                    mp.stop();
                }
            } catch (Exception ignored) {
            }
            mp.release();
            mp = null;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            stopForeground(true);
        } else {
            stopForeground(true);
        }
        super.onDestroy();
    }
}
