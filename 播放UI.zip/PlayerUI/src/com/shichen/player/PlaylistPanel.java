package com.shichen.player;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 播放列表面板：带视频封面、标题、时长、清晰度，
 * 长按右侧拖拽柄可拖动调整顺序，右侧叉号可移除条目。
 */
public class PlaylistPanel {

    public interface Callback {
        void onPick(int pos);          // 点击条目跳转
        void onRemove(int pos);        // 移除条目
        void onReorder(List<String> newList);  // 顺序变更
        void onMoveTo(int from, int to);       // 顺序调整后修正当前索引
    }

    /** 实时提供当前播放索引，保证列表始终高亮真正正在播放的那一条 */
    public interface Provider {
        int currentIndex();

        long currentPos();
    }

    private final Activity act;
    private final List<String> paths;
    private final Provider provider;
    private final Callback cb;
    private final int d;

    private PlaylistAdapter adapter;

    public PlaylistPanel(Activity a, List<String> paths, Provider provider, Callback cb) {
        act = a;
        this.paths = paths;
        this.provider = provider;
        this.cb = cb;
        d = (int) a.getResources().getDisplayMetrics().density;
    }

    /** 外部数据变化时刷新列表（当前项高亮随之更新） */
    public void refresh() {
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    public View build() {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
                android.graphics.drawable.GradientDrawable pg =
                new android.graphics.drawable.GradientDrawable();
        pg.setColor(0x00000000);   // 填充由窗口背景按 playlist 类别提供
        pg.setCornerRadius(22 * act.getResources().getDisplayMetrics().density);
        box.setBackgroundDrawable(pg);
        box.setPadding(6 * d, 4 * d, 6 * d, 8 * d);

        // 顶部小横条
        View bar = new View(act);
        bar.setBackgroundColor(0x59FFFFFF);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(34 * d, 3 * d);
        blp.gravity = Gravity.CENTER_HORIZONTAL;
        blp.bottomMargin = 6 * d;
        box.addView(bar, blp);

        TextView t = new TextView(act);
        t.setText("正在播放 (" + paths.size() + ")");
        t.setTextSize(15f);
        t.setTextColor(0xFFFFFFFF);
        t.setPadding(14 * d, 8 * d, 14 * d, 10 * d);
        box.addView(t);

        final ListView lv = new ListView(act);
        lv.setDivider(null);
        lv.setDividerHeight(0);
        lv.setSelector(android.R.color.transparent);
        adapter = new PlaylistAdapter();
        lv.setAdapter(adapter);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (int) (330 * d));
        box.addView(lv, lp);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                int cur = provider == null ? -1 : provider.currentIndex();
                if (pos != cur && cb != null) {
                    cb.onPick(pos);
                }
            }
        });

        TextView hint = new TextView(act);
        hint.setText("长按右侧手柄可拖动排序");
        hint.setTextSize(11f);
        hint.setTextColor(0xAAFFFFFF);
        hint.setPadding(14 * d, 8 * d, 14 * d, 2 * d);
        box.addView(hint);

        return box;
    }

    private class PlaylistAdapter extends ArrayAdapter<String> {

        PlaylistAdapter() {
            super(act, 0, paths);
        }

        public View getView(final int pos, View cv, ViewGroup parent) {
            LinearLayout row = new LinearLayout(act);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(10 * d, 7 * d, 6 * d, 7 * d);
            final int current = provider == null ? -1 : provider.currentIndex();
            final boolean isCur = (pos == current);
            row.setBackgroundResource(isCur ? R.drawable.bg_row_playing : R.drawable.bg_panel_btn);

            // 上移
            ImageView up = new ImageView(act);
            up.setImageResource(R.drawable.ic_arrow_up);
            up.setColorFilter(0xCCFFFFFF);
            up.setPadding(5 * d, 5 * d, 5 * d, 5 * d);
            up.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    move(pos, -1);
                }
            });
            row.addView(up, new LinearLayout.LayoutParams(30 * d, 30 * d));

            // 下移
            ImageView down = new ImageView(act);
            down.setImageResource(R.drawable.ic_arrow_down);
            down.setColorFilter(0xCCFFFFFF);
            down.setPadding(5 * d, 5 * d, 5 * d, 5 * d);
            down.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    move(pos, 1);
                }
            });
            row.addView(down, new LinearLayout.LayoutParams(30 * d, 30 * d));

            // 封面缩略图
            ImageView thumb = new ImageView(act);
            int tw = 74 * d, th = 44 * d;
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumb.setBackgroundResource(R.drawable.bg_thumb);
            VideoItem vi = new VideoItem();
            vi.path = getItem(pos);
            File f = new File(vi.path);
            int k = f.getName().lastIndexOf('.');
            vi.title = k > 0 ? f.getName().substring(0, k) : f.getName();
            VideoItem cached = new DbHelper(act).find(vi.path);
            if (cached != null && cached.duration > 0) {
                vi.duration = cached.duration;
                vi.width = cached.width;
                vi.height = cached.height;
            } else {
                long[] sz = MediaUtils.probeVideoSize(vi.path);
                if (sz[3] > 0) {
                    vi.duration = sz[3];
                }
                vi.width = (int) sz[0];
                vi.height = (int) sz[1];
            }
            ThumbLoader.load(vi, thumb);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(tw, th);
            tlp.leftMargin = 4 * d;
            row.addView(thumb, tlp);

            // 标题 + 时长/清晰度
            LinearLayout txt = new LinearLayout(act);
            txt.setOrientation(LinearLayout.VERTICAL);
            txt.setPadding(8 * d, 0, 2 * d, 0);
            txt.setLayoutParams(new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView name = new TextView(act);
            name.setText(vi.title);
            name.setTextSize(12.5f);
            name.setTextColor(isCur ? 0xFFFFFFFF : 0xFFEDEDF5);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            txt.addView(name);

            if (isCur) {
                TextView now = new TextView(act);
                now.setText("\u25B6 正在播放");
                now.setTextSize(10.5f);
                now.setTextColor(ThemeEngine.accent(act));
                txt.addView(now);
            }
            TextView sub = new TextView(act);
            String res = vi.resolution();
            sub.setText(MediaUtils.formatDuration(vi.duration)
                    + (res.length() > 0 ? "  \u00b7  " + res : ""));
            sub.setTextSize(10.5f);
            sub.setTextColor(isCur ? 0xDDFFFFFF : 0xAAFFFFFF);
            txt.addView(sub);
            row.addView(txt);

            // 当前播放指示
            if (isCur) {
                ImageView playing = new ImageView(act);
                playing.setImageResource(R.drawable.ic_play);
                playing.setColorFilter(ThemeEngine.accent(act));
                row.addView(playing, new LinearLayout.LayoutParams(18 * d, 18 * d));
            }

            // 移除
            ImageView del = new ImageView(act);
            del.setImageResource(R.drawable.ic_close);
            del.setColorFilter(0xCCFFFFFF);
            del.setPadding(8 * d, 8 * d, 8 * d, 8 * d);
            del.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (cb != null) {
                        cb.onRemove(pos);
                    }
                }
            });
            row.addView(del);

            return row;
        }
    }

    /** 上移/下移：交换相邻项并回调 */
    private void move(int pos, int dir) {
        int to = pos + dir;
        if (to < 0 || to >= paths.size()) {
            return;
        }
        Collections.swap(paths, pos, to);
        adapter.notifyDataSetChanged();
        if (cb != null) {
            cb.onReorder(new ArrayList<String>(paths));
            cb.onMoveTo(pos, to);
        }
    }

    /** 简易拖动：长按后按手指落点计算目标位置并交换 */
    private void startDrag(final View row, final int from) {
        row.setBackgroundColor(0x22FFFFFF);
        final ListView lv = (ListView) row.getParent();
        row.setOnTouchListener(new View.OnTouchListener() {
            float startY = 0;
            int target = from;

            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dy = e.getRawY() - startY;
                        int step = (int) (dy / (52f * d));
                        int nt = from + step;
                        if (nt < 0) {
                            nt = 0;
                        }
                        if (nt >= paths.size()) {
                            nt = paths.size() - 1;
                        }
                        if (nt != target) {
                            Collections.swap(paths, target, nt);
                            target = nt;
                            adapter.notifyDataSetChanged();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.setOnTouchListener(null);
                        row.setBackgroundResource(
                                target == (provider == null ? -1 : provider.currentIndex())
                                        ? R.drawable.bg_row_playing : R.drawable.bg_panel_btn);
                        if (target != from) {
                            if (cb != null) {
                                cb.onReorder(new ArrayList<String>(paths));
                                cb.onMoveTo(from, target);
                            }
                        }
                        return true;
                }
                return false;
            }
        });
    }
}
