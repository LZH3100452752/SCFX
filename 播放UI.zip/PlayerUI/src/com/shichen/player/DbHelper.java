package com.shichen.player;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {
    private static final String DB = "shichen.db";
    private static final int VER = 1;
    public static final int TYPE_WHITE = 0;
    public static final int TYPE_BLACK = 1;

    public DbHelper(Context c) {
        super(c.getApplicationContext(), DB, null, VER);
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS history (path TEXT PRIMARY KEY, title TEXT, duration INTEGER,"
                + " position INTEGER, last INTEGER, fav INTEGER, width INTEGER, height INTEGER, size INTEGER)");
        db.execSQL("CREATE TABLE IF NOT EXISTS dirs (path TEXT, type INTEGER, PRIMARY KEY(path,type))");
    }

    public void onUpgrade(SQLiteDatabase db, int o, int n) {
        db.execSQL("DROP TABLE IF EXISTS history");
        db.execSQL("DROP TABLE IF EXISTS dirs");
        onCreate(db);
    }

    public void saveHistory(VideoItem v, long pos) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("path", v.path);
        cv.put("title", v.title);
        cv.put("duration", v.duration);
        cv.put("position", pos);
        cv.put("last", System.currentTimeMillis());
        cv.put("width", v.width);
        cv.put("height", v.height);
        cv.put("size", v.size);
        db.insertWithOnConflict("history", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public long getProgress(String path) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query("history", new String[]{"position"}, "path=?", new String[]{path}, null, null, null);
        long p = 0;
        if (c.moveToFirst()) {
            p = c.getLong(0);
        }
        c.close();
        return p;
    }

    public List<VideoItem> getHistory(int limit) {
        List<VideoItem> list = new ArrayList<VideoItem>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query("history", null, null, null, null, null, "last DESC", String.valueOf(limit));
        while (c.moveToNext()) {
            list.add(from(c));
        }
        c.close();
        return list;
    }

    public List<VideoItem> getFavorites() {
        List<VideoItem> list = new ArrayList<VideoItem>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query("history", null, "fav=1", null, null, null, "last DESC", null);
        while (c.moveToNext()) {
            list.add(from(c));
        }
        c.close();
        return list;
    }

    public VideoItem find(String path) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query("history", null, "path=?", new String[]{path}, null, null, null);
        VideoItem v = null;
        if (c.moveToFirst()) {
            v = from(c);
        }
        c.close();
        return v;
    }

    private VideoItem from(Cursor c) {
        VideoItem v = new VideoItem();
        v.path = c.getString(c.getColumnIndex("path"));
        v.title = c.getString(c.getColumnIndex("title"));
        v.duration = c.getLong(c.getColumnIndex("duration"));
        v.position = c.getLong(c.getColumnIndex("position"));
        v.lastPlay = c.getLong(c.getColumnIndex("last"));
        v.fav = c.getInt(c.getColumnIndex("fav")) == 1;
        v.width = c.getInt(c.getColumnIndex("width"));
        v.height = c.getInt(c.getColumnIndex("height"));
        v.size = c.getLong(c.getColumnIndex("size"));
        return v;
    }

    public void setFav(String path, boolean fav) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("fav", fav ? 1 : 0);
        cv.put("last", System.currentTimeMillis());
        int n = db.update("history", cv, "path=?", new String[]{path});
        if (n == 0) {
            cv.put("path", path);
            db.insertWithOnConflict("history", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    public void delete(String path) {
        getWritableDatabase().delete("history", "path=?", new String[]{path});
    }

    public void clearHistory() {
        getWritableDatabase().delete("history", null, null);
    }

    public void clearPosition() {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("position", 0);
        db.update("history", cv, null, null);
    }

    public void addDir(String path, int type) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("path", path);
        cv.put("type", type);
        db.insertWithOnConflict("dirs", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public void removeDir(String path, int type) {
        getWritableDatabase().delete("dirs", "path=? AND type=?",
                new String[]{path, String.valueOf(type)});
    }

    public List<String> dirs(int type) {
        List<String> list = new ArrayList<String>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query("dirs", new String[]{"path"}, "type=?", new String[]{String.valueOf(type)},
                null, null, "path ASC");
        while (c.moveToNext()) {
            list.add(c.getString(0));
        }
        c.close();
        return list;
    }
}
