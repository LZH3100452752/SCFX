package com.shichen.player;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    private static final String NAME = "shichen_prefs";
    private static SharedPreferences sp;

    /* ---------- 解码 ---------- */
    public static final int DECODE_SYSTEM = 0;
    public static final int DECODE_HW = 1;
    public static final int DECODE_SW = 2;
    public static final int DECODE_AUTO = 3;

    public static final int RENDER_SURFACE = 0;
    public static final int RENDER_TEXTURE = 1;

    /* ---------- 排序字段（12 种） ---------- */
    public static final int S_TITLE = 0;
    public static final int S_DATE = 1;
    public static final int S_MODIFIED = 2;
    public static final int S_PLAYTIME = 3;
    public static final int S_STATUS = 4;
    public static final int S_DURATION = 5;
    public static final int S_SIZE = 6;
    public static final int S_RESOLUTION = 7;
    public static final int S_PATH = 8;
    public static final int S_FPS = 9;
    public static final int S_TYPE = 10;
    public static final int S_NAME = 11;

    /* ---------- 画面比例 ---------- */
    public static final int RATIO_FIT = 0;
    public static final int RATIO_16_9 = 1;
    public static final int RATIO_4_3 = 2;
    public static final int RATIO_FILL = 3;
    public static final int RATIO_ORIGINAL = 4;
    public static final int RATIO_CROP = 5;
    public static final int RATIO_1_1 = 6;
    public static final int RATIO_21_9 = 7;

    /* ---------- 主题模式 ---------- */
    public static final int T_DARK = 0;
    public static final int T_BLACK = 1;
    public static final int T_LIGHT = 2;

    /* ---------- 屏幕方向 ---------- */
    public static final int O_VIDEO = 0;
    public static final int O_AUTO = 1;
    public static final int O_LANDSCAPE = 2;
    public static final int O_PORTRAIT = 3;
    public static final int O_SYSTEM = 4;

    /* ---------- 循环模式 ---------- */
    public static final int REPEAT_OFF = 0;
    public static final int REPEAT_ALL = 1;
    public static final int REPEAT_ONE = 2;

    private static SharedPreferences get(Context c) {
        if (sp == null) {
            sp = c.getApplicationContext().getSharedPreferences(NAME, Context.MODE_PRIVATE);
        }
        return sp;
    }

    private static int g(Context c, String k, int d) {
        return get(c).getInt(k, d);
    }

    private static boolean gb(Context c, String k, boolean d) {
        return get(c).getBoolean(k, d);
    }

    /* ================= 外观 ================= */
    public static int themeMode(Context c) {
        return g(c, "theme_mode", T_DARK);
    }

    public static void setThemeMode(Context c, int v) {
        get(c).edit().putInt("theme_mode", v).apply();
    }

    public static int accent(Context c) {
        return g(c, "accent", 0);
    }

    public static void setAccent(Context c, int v) {
        get(c).edit().putInt("accent", v).apply();
    }

    /* ================= 排序 / 视图 ================= */
    public static int sortField(Context c) {
        return g(c, "sort_field", S_DATE);
    }

    public static void setSortField(Context c, int v) {
        get(c).edit().putInt("sort_field", v).apply();
    }

    public static boolean sortAsc(Context c) {
        return gb(c, "sort_asc", false);
    }

    public static void setSortAsc(Context c, boolean v) {
        get(c).edit().putBoolean("sort_asc", v).apply();
    }

    public static boolean gridView(Context c) {
        return gb(c, "grid", true);
    }

    public static void setGridView(Context c, boolean v) {
        get(c).edit().putBoolean("grid", v).apply();
    }

    public static boolean folderMode(Context c) {
        return gb(c, "folder_mode", false);
    }

    public static void setFolderMode(Context c, boolean v) {
        get(c).edit().putBoolean("folder_mode", v).apply();
    }

    /* ================= 播放 ================= */
    public static boolean rememberPos(Context c) {
        return gb(c, "remember", true);
    }

    public static void setRememberPos(Context c, boolean v) {
        get(c).edit().putBoolean("remember", v).apply();
    }

    public static boolean autoNext(Context c) {
        return gb(c, "auto_next", true);
    }

    public static void setAutoNext(Context c, boolean v) {
        get(c).edit().putBoolean("auto_next", v).apply();
    }

    public static boolean keepScreenOn(Context c) {
        return gb(c, "screen_on", true);
    }

    public static void setKeepScreenOn(Context c, boolean v) {
        get(c).edit().putBoolean("screen_on", v).apply();
    }

    public static boolean backgroundPlay(Context c) {
        return gb(c, "bg_play", false);
    }

    public static void setBackgroundPlay(Context c, boolean v) {
        get(c).edit().putBoolean("bg_play", v).apply();
    }

    public static float defaultSpeed(Context c) {
        return get(c).getFloat("speed", 1.0f);
    }

    public static void setDefaultSpeed(Context c, float v) {
        get(c).edit().putFloat("speed", v).apply();
    }

    public static int repeatMode(Context c) {
        return g(c, "repeat", REPEAT_OFF);
    }

    public static void setRepeatMode(Context c, int v) {
        get(c).edit().putInt("repeat", v).apply();
    }

    public static int skipSec(Context c) {
        return g(c, "skip", 10);
    }

    public static void setSkipSec(Context c, int v) {
        get(c).edit().putInt("skip", v).apply();
    }

    public static float longPressSpeed(Context c) {
        return get(c).getFloat("lp_speed", 2.0f);
    }

    public static void setLongPressSpeed(Context c, float v) {
        get(c).edit().putFloat("lp_speed", v).apply();
    }

    public static boolean resumeAsk(Context c) {
        return gb(c, "resume_ask", true);
    }

    public static void setResumeAsk(Context c, boolean v) {
        get(c).edit().putBoolean("resume_ask", v).apply();
    }

    public static boolean headphonePause(Context c) {
        return gb(c, "hp_pause", true);
    }

    public static void setHeadphonePause(Context c, boolean v) {
        get(c).edit().putBoolean("hp_pause", v).apply();
    }

    /* ================= 画面 / 方向 ================= */
    public static int defaultRatio(Context c) {
        return g(c, "ratio", RATIO_FIT);
    }

    public static void setDefaultRatio(Context c, int v) {
        get(c).edit().putInt("ratio", v).apply();
    }

    public static int orientation(Context c) {
        return g(c, "orientation", O_VIDEO);
    }

    public static void setOrientation(Context c, int v) {
        get(c).edit().putInt("orientation", v).apply();
    }

    public static int decodeMode(Context c) {
        return g(c, "decode", DECODE_SYSTEM);
    }

    public static void setDecodeMode(Context c, int v) {
        get(c).edit().putInt("decode", v).apply();
    }

    /**
     * 渲染模式：0=兼容(SurfaceView)，1=高级(TextureView)。
     * 默认必须是高级模式：兼容模式下矩阵变换不生效（updateTransform 直接 return），
     * 画面比例完全交给系统解码器，导致"适应屏幕"也无法保持原始比例、没有黑边。
     */
    public static int renderKind(Context c) {
        return g(c, "render_kind", 1);
    }

    public static void setRenderKind(Context c, int v) {
        get(c).edit().putInt("render_kind", v).apply();
    }

    /** 音量放大百分比：100 ~ 200 */
    public static int boostVolume(Context c) {
        int v = g(c, "boost_vol", 100);
        if (v < 100) {
            v = 100;
        }
        if (v > 200) {
            v = 200;
        }
        return v;
    }

    public static void setBoostVolume(Context c, int v) {
        if (v < 100) {
            v = 100;
        }
        if (v > 200) {
            v = 200;
        }
        get(c).edit().putInt("boost_vol", v).apply();
    }

    /** 音画同步：音频延迟毫秒（正=音频延后），范围 -1000 ~ +1000 */
    public static int audioDelay(Context c) {
        return g(c, "audio_delay", 0);
    }

    public static void setAudioDelay(Context c, int v) {
        if (v < -1000) {
            v = -1000;
        }
        if (v > 1000) {
            v = 1000;
        }
        get(c).edit().putInt("audio_delay", v).apply();
    }

    /** 记住上次使用的倍速 */
    public static boolean rememberSpeed(Context c) {
        return gb(c, "remember_speed", true);
    }

    public static void setRememberSpeed(Context c, boolean v) {
        get(c).edit().putBoolean("remember_speed", v).apply();
    }

    /** 控制条自动隐藏秒数 */
    public static int autoHideSec(Context c) {
        return g(c, "auto_hide", 4);
    }

    public static void setAutoHideSec(Context c, int v) {
        get(c).edit().putInt("auto_hide", v).apply();
    }

    /** 播放结束时恢复的亮度（%） */
    public static int restoreBright(Context c) {
        return g(c, "restore_bright", 0);
    }

    public static void setRestoreBright(Context c, int v) {
        get(c).edit().putInt("restore_bright", v).apply();
    }

    /** 字幕描边粗细 px */
    public static int subtitleOutline(Context c) {
        return g(c, "sub_outline", 2);
    }

    public static void setSubtitleOutline(Context c, int v) {
        get(c).edit().putInt("sub_outline", v).apply();
    }

    /** 字幕底部边距 dp */
    public static int subtitleBottom(Context c) {
        return g(c, "sub_bottom", 24);
    }

    public static void setSubtitleBottom(Context c, int v) {
        get(c).edit().putInt("sub_bottom", v).apply();
    }

    /** 拖动预览缩略图缩放 % */
    public static int previewScale(Context c) {
        return g(c, "preview_scale", 100);
    }

    public static void setPreviewScale(Context c, int v) {
        get(c).edit().putInt("preview_scale", v).apply();
    }

    /** 拖动时预览是否保持可见 */
    public static boolean previewSticky(Context c) {
        return gb(c, "preview_sticky", false);
    }

    public static void setPreviewSticky(Context c, boolean v) {
        get(c).edit().putBoolean("preview_sticky", v).apply();
    }

    /** 播放完成自动退出 */
    public static boolean exitOnFinish(Context c) {
        return gb(c, "exit_finish", false);
    }

    public static void setExitOnFinish(Context c, boolean v) {
        get(c).edit().putBoolean("exit_finish", v).apply();
    }

    /** 列表自动定位当前项 */
    public static boolean autoScrollList(Context c) {
        return gb(c, "auto_scroll_list", true);
    }

    public static void setAutoScrollList(Context c, boolean v) {
        get(c).edit().putBoolean("auto_scroll_list", v).apply();
    }

    /** 声道平衡：0=全左 50=居中 100=全右 */
    public static int balance(Context c) {
        return g(c, "balance", 50);
    }

    public static void setBalance(Context c, int v) {
        get(c).edit().putInt("balance", v).apply();
    }

    /** 视频翻转：0=不翻转 1=水平镜像 2=垂直翻转 3=旋转180° */
    public static int videoFlip(Context c) {
        return g(c, "video_flip", 0);
    }

    public static void setVideoFlip(Context c, int v) {
        get(c).edit().putInt("video_flip", v).apply();
    }

    /** 视频额外旋转：0/90/180/270 度，用于录制方向错误的视频 */
    public static int videoRotate(Context c) {
        return g(c, "video_rotate", 0);
    }

    public static void setVideoRotate(Context c, int v) {
        get(c).edit().putInt("video_rotate", v).apply();
    }

    /** 控制栏右侧按键（最多 5 个，默认 倍速/画面比例/小窗） */
    public static String controlKeys(Context c) {
        return get(c).getString("ctrl_keys", "speed,aspect,pip");
    }

    public static void setControlKeys(Context c, String v) {
        get(c).edit().putString("ctrl_keys", v == null ? "" : v).apply();
    }

    /* ============ 锁定后仍允许的手势 ============ */
    public static boolean lockDoubleTap(Context c) {
        return gb(c, "lock_dtap", true);
    }

    public static void setLockDoubleTap(Context c, boolean v) {
        get(c).edit().putBoolean("lock_dtap", v).apply();
    }

    public static boolean lockLongPress(Context c) {
        return gb(c, "lock_lp", true);
    }

    public static void setLockLongPress(Context c, boolean v) {
        get(c).edit().putBoolean("lock_lp", v).apply();
    }

    public static boolean lockSeek(Context c) {
        return gb(c, "lock_seek", false);
    }

    public static void setLockSeek(Context c, boolean v) {
        get(c).edit().putBoolean("lock_seek", v).apply();
    }

    public static boolean lockBrightness(Context c) {
        return gb(c, "lock_bright", false);
    }

    public static void setLockBrightness(Context c, boolean v) {
        get(c).edit().putBoolean("lock_bright", v).apply();
    }

    public static boolean lockVolume(Context c) {
        return gb(c, "lock_vol", false);
    }

    public static void setLockVolume(Context c, boolean v) {
        get(c).edit().putBoolean("lock_vol", v).apply();
    }

    public static boolean lockZoom(Context c) {
        return gb(c, "lock_zoom", false);
    }

    public static void setLockZoom(Context c, boolean v) {
        get(c).edit().putBoolean("lock_zoom", v).apply();
    }

    /** 播放工具里被隐藏的功能（存 id，逗号分隔） */
    public static String hiddenTools(Context c) {
        return get(c).getString("hidden_tools", "");
    }

    public static void setHiddenTools(Context c, String v) {
        get(c).edit().putString("hidden_tools", v == null ? "" : v).apply();
    }

    /** 小窗模式类型：false=系统画中画（默认） true=悬浮窗（自绘控件，需悬浮窗权限） */
    public static boolean floatWindowMode(Context c) {
        return gb(c, "float_window_mode", true);
    }

    public static void setFloatWindowMode(Context c, boolean v) {
        get(c).edit().putBoolean("float_window_mode", v).apply();
    }

    /** 弹窗面板半透明总开关 */
    public static boolean panelTranslucent(Context c) {
        return gb(c, "panel_translucent", true);
    }

    public static void setPanelTranslucent(Context c, boolean v) {
        get(c).edit().putBoolean("panel_translucent", v).apply();
    }

    /**
     * 按弹窗类别分别设置背景透明度（%）。
     * kind: main=主界面/设置页弹窗, player=播放界面弹窗,
     *       speed=倍速面板, playlist=播放列表
     */
    public static int panelAlphaKind(Context c, String kind) {
        int def = 72;
        if ("speed".equals(kind)) {
            def = 80;
        } else if ("playlist".equals(kind)) {
            def = 72;
        }
        int v = g(c, "panel_alpha_" + kind, def);
        if (v < 0) {
            v = 0;
        }
        if (v > 100) {
            v = 100;
        }
        return v;
    }

    public static void setPanelAlphaKind(Context c, String kind, int v) {
        if (v < 0) {
            v = 0;
        }
        if (v > 100) {
            v = 100;
        }
        get(c).edit().putInt("panel_alpha_" + kind, v).apply();
    }

    /** 弹窗面板背景透明度：0=全透明 100=接近不透明，默认 78（半透明） */
    public static int panelAlpha(Context c) {
        int v = g(c, "panel_alpha", 72);
        if (v < 0) {
            v = 0;
        }
        if (v > 100) {
            v = 100;
        }
        return v;
    }

    public static void setPanelAlpha(Context c, int v) {
        if (v < 0) {
            v = 0;
        }
        if (v > 100) {
            v = 100;
        }
        get(c).edit().putInt("panel_alpha", v).apply();
    }

    /** 播放工具面板的图标顺序（存 id，逗号分隔） */
    public static String toolsOrder(Context c) {
        return get(c).getString("tools_order", "");
    }

    public static void setToolsOrder(Context c, String v) {
        get(c).edit().putString("tools_order", v).apply();
    }

    /** 顶部状态显示：左侧视频时长 / 右侧电量与时间 */
    public static boolean statusOverlay(Context c) {
        return gb(c, "status_overlay", true);
    }

    public static void setStatusOverlay(Context c, boolean v) {
        get(c).edit().putBoolean("status_overlay", v).apply();
    }

    /** 顶部状态显示：左右两侧同步向内的水平偏移（dp），上限放宽到 160 */
    public static int statusInsetX(Context c) {
        int v = g(c, "status_ix", 14);
        if (v < 0) {
            v = 0;
        }
        if (v > 320) {
            v = 320;
        }
        return v;
    }

    public static void setStatusInsetX(Context c, int v) {
        if (v < 0) {
            v = 0;
        }
        if (v > 320) {
            v = 320;
        }
        get(c).edit().putInt("status_ix", v).apply();
    }

    /** 顶部状态显示：距顶部的垂直偏移（dp），上限放宽到 200 */
    public static int statusInsetY(Context c) {
        int v = g(c, "status_iy", 8);
        if (v < 0) {
            v = 0;
        }
        if (v > 320) {
            v = 320;
        }
        return v;
    }

    public static void setStatusInsetY(Context c, int v) {
        if (v < 0) {
            v = 0;
        }
        if (v > 320) {
            v = 320;
        }
        get(c).edit().putInt("status_iy", v).apply();
    }

    /** 左侧显示：0=总时长 1=剩余时长 2=当前/总时长 */
    public static int statusLeftMode(Context c) {
        return g(c, "status_lm", 2);
    }

    public static void setStatusLeftMode(Context c, int v) {
        get(c).edit().putInt("status_lm", v).apply();
    }

    /** 右侧显示：0=时间+电量 1=仅电量 2=仅时间 */
    public static int statusRightMode(Context c) {
        return g(c, "status_rm", 0);
    }

    public static void setStatusRightMode(Context c, int v) {
        get(c).edit().putInt("status_rm", v).apply();
    }

    public static int renderMode(Context c) {
        return g(c, "render", RENDER_SURFACE);
    }

    public static void setRenderMode(Context c, int v) {
        get(c).edit().putInt("render", v).apply();
    }

    public static boolean fallback(Context c) {
        return gb(c, "fallback", true);
    }

    public static void setFallback(Context c, boolean v) {
        get(c).edit().putBoolean("fallback", v).apply();
    }

    /* ================= 手势 ================= */
    public static boolean gSeek(Context c) {
        return gb(c, "g_seek", true);
    }

    public static void setGSeek(Context c, boolean v) {
        get(c).edit().putBoolean("g_seek", v).apply();
    }

    public static boolean gBrightness(Context c) {
        return gb(c, "g_bright", true);
    }

    public static void setGBrightness(Context c, boolean v) {
        get(c).edit().putBoolean("g_bright", v).apply();
    }

    public static boolean gVolume(Context c) {
        return gb(c, "g_vol", true);
    }

    public static void setGVolume(Context c, boolean v) {
        get(c).edit().putBoolean("g_vol", v).apply();
    }

    public static boolean gZoom(Context c) {
        return gb(c, "g_zoom", true);
    }

    public static void setGZoom(Context c, boolean v) {
        get(c).edit().putBoolean("g_zoom", v).apply();
    }

    public static boolean gLongPress(Context c) {
        return gb(c, "g_long", true);
    }

    public static void setGLongPress(Context c, boolean v) {
        get(c).edit().putBoolean("g_long", v).apply();
    }

    public static boolean gDoubleTap(Context c) {
        return gb(c, "g_double", true);
    }

    public static void setGDoubleTap(Context c, boolean v) {
        get(c).edit().putBoolean("g_double", v).apply();
    }

    public static int seekSensitivity(Context c) {
        return g(c, "seek_sens", 120);
    }

    public static void setSeekSensitivity(Context c, int v) {
        get(c).edit().putInt("seek_sens", v).apply();
    }

    /* ================= 字幕 ================= */
    public static int subtitleSize(Context c) {
        return g(c, "sub_size", 16);
    }

    public static void setSubtitleSize(Context c, int v) {
        get(c).edit().putInt("sub_size", v).apply();
    }

    public static int subtitleDelay(Context c) {
        return g(c, "sub_delay", 0);
    }

    public static void setSubtitleDelay(Context c, int v) {
        get(c).edit().putInt("sub_delay", v).apply();
    }

    public static boolean subtitleOn(Context c) {
        return gb(c, "sub_on", true);
    }

    public static void setSubtitleOn(Context c, boolean v) {
        get(c).edit().putBoolean("sub_on", v).apply();
    }

    public static int subtitleColor(Context c) {
        return g(c, "sub_color", 0);
    }

    public static void setSubtitleColor(Context c, int v) {
        get(c).edit().putInt("sub_color", v).apply();
    }

    /* ================= 音效 ================= */
    public static int bassBoost(Context c) {
        return g(c, "bass", 0);
    }

    public static void setBassBoost(Context c, int v) {
        get(c).edit().putInt("bass", v).apply();
    }

    public static int virtualizer(Context c) {
        return g(c, "viz", 0);
    }

    public static void setVirtualizer(Context c, int v) {
        get(c).edit().putInt("viz", v).apply();
    }

    public static int eqPreset(Context c) {
        return g(c, "eq_preset", -1);
    }

    public static void setEqPreset(Context c, int v) {
        get(c).edit().putInt("eq_preset", v).apply();
    }

    public static String eqLevels(Context c) {
        return get(c).getString("eq_levels", "");
    }

    public static void setEqLevels(Context c, String v) {
        get(c).edit().putString("eq_levels", v).apply();
    }

    public static boolean audioFxOn(Context c) {
        return gb(c, "audiofx", false);
    }

    public static void setAudioFxOn(Context c, boolean v) {
        get(c).edit().putBoolean("audiofx", v).apply();
    }

    /* ================= 扫描 ================= */
    public static int minDuration(Context c) {
        return g(c, "min_duration", 2);
    }

    public static void setMinDuration(Context c, int v) {
        get(c).edit().putInt("min_duration", v).apply();
    }

    public static boolean scanOnStart(Context c) {
        return gb(c, "scan_start", true);
    }

    public static void setScanOnStart(Context c, boolean v) {
        get(c).edit().putBoolean("scan_start", v).apply();
    }

    public static boolean hideShort(Context c) {
        return gb(c, "hide_short", true);
    }

    public static void setHideShort(Context c, boolean v) {
        get(c).edit().putBoolean("hide_short", v).apply();
    }

    /* ================= 高级 ================= */
    public static boolean showDebug(Context c) {
        return gb(c, "debug", false);
    }

    public static void setShowDebug(Context c, boolean v) {
        get(c).edit().putBoolean("debug", v).apply();
    }

    public static int lastTab(Context c) {
        return g(c, "last_tab", 0);
    }

    public static void setLastTab(Context c, int v) {
        get(c).edit().putInt("last_tab", v).apply();
    }
}
