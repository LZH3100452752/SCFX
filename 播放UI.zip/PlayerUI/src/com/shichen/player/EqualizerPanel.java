package com.shichen.player;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/**
 * 均衡器：以弹窗形式出现在播放界面内，不再跳转到独立页面。
 * 内容 = 总开关 + 预设 + 各频段滑杆 + 低音增强 + 环绕声
 */
public class EqualizerPanel {

    private final PlayerActivity act;
    private final int d;
    private final int accent;
    /** 时尘内核内置 EQ（新解码器），非空时优先用它，否则走系统音效 */
    private com.hwdecoder.Equalizer hwEq = null;
    private boolean hwMode = false;
    private LinearLayout bands;
    private FlowLayout presets;
    private int range;

    public EqualizerPanel(PlayerActivity a) {
        act = a;
        d = (int) a.getResources().getDisplayMetrics().density;
        accent = ThemeEngine.accent(a);
        try {
            hwEq = a.hwEqualizer();
        } catch (Throwable ignored) {
        }
        hwMode = hwEq != null;
    }

    public View build() {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14 * d, 12 * d, 14 * d, 12 * d);

        if (!AudioFx.available()) {
            TextView warn = new TextView(act);
            warn.setText(hwMode ? "时尘内核音效已就绪" : "音效引擎未就绪，请先开始播放视频音频");
            warn.setTextSize(12.5f);
            warn.setTextColor(0xFFB8B8C8);
            box.addView(warn);
        }

        // ---- 总开关 ----
        LinearLayout swRow = new LinearLayout(act);
        swRow.setOrientation(LinearLayout.HORIZONTAL);
        swRow.setGravity(Gravity.CENTER_VERTICAL);
        swRow.setPadding(4 * d, 4 * d, 4 * d, 8 * d);
        TextView swT = new TextView(act);
        swT.setText("启用音效");
        swT.setTextSize(13.5f);
        swT.setTextColor(0xFFF0F0F5);
        swT.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Switch sw = new Switch(act);
        sw.setChecked(Prefs.audioFxOn(act));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                if (hwMode) {
                    hwEq.setEnabled(v);
                } else {
                    AudioFx.setEnabled(v);
                }
            }
        });
        swRow.addView(swT);
        swRow.addView(sw);
        box.addView(swRow);

        // ---- 预设 ----
        box.addView(title("预设"));
        presets = new FlowLayout(act);
        presets.setGaps(8 * d, 8 * d);
        presets.setPadding(0, 4 * d, 0, 6 * d);
        box.addView(presets);

        // ---- 频段 ----
        box.addView(title("频段"));
        bands = new LinearLayout(act);
        bands.setOrientation(LinearLayout.VERTICAL);
        bands.setPadding(0, 4 * d, 0, 6 * d);
        box.addView(bands);

        // ---- 低音 / 环绕 ----
        box.addView(slider("低音增强", Prefs.bassBoost(act), 0, 1000,
                new OnV() {
            public void on(int v) {
                AudioFx.setBass(v);
            }
        }));
        box.addView(slider("环绕声", Prefs.virtualizer(act), 0, 1000,
                new OnV() {
            public void on(int v) {
                AudioFx.setViz(v);
            }
        }));

        buildPresets();
        buildBands();
        return box;
    }

    private View title(String s) {
        TextView t = new TextView(act);
        t.setText(s);
        t.setTextSize(12f);
        t.setTextColor(accent);
        t.setPadding(4 * d, 8 * d, 4 * d, 2 * d);
        return t;
    }

    private void buildPresets() {
        presets.removeAllViews();
        String[] names = hwMode ? HW_PRESETS : AudioFx.PRESETS;
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            boolean on = i == (hwMode ? hwPresetIdx : Prefs.eqPreset(act));
            TextView t = new TextView(act);
            t.setText(names[i]);
            t.setTextSize(12.5f);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(on ? Color.WHITE : 0xFFDDDDE6);
            t.setBackgroundResource(on ? R.drawable.bg_panel_btn_sel
                    : R.drawable.bg_panel_btn);
            t.setPadding(14 * d, 8 * d, 14 * d, 8 * d);
            t.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (hwMode) {
                        applyHwPreset(idx);
                    } else {
                        AudioFx.applyPreset(idx, false);
                    }
                    buildPresets();
                    buildBands();
                }
            });
            presets.addView(t);
        }
    }

    /** 时尘内核的预设增益表（dB），对应 10 段中心频率 */
    private int hwPresetIdx = 0;
    private static final float[][] HW_PRESET_GAINS = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},                       // 关闭
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},                       // 默认（平直）
            {-1, 2, 4, 3, 0, -1, -1, 0, 2, 3},                    // 流行
            {5, 4, 2, 0, -1, -1, 0, 2, 4, 5},                     // 摇滚
            {3, 2, 1, 1, -1, -1, 0, 2, 3, 4},                     // 爵士
            {4, 3, 1, 2, -1, -1, 1, 3, 4, 4},                     // 古典
            {-2, -1, 0, 2, 4, 4, 3, 1, -1, -2},                   // 人声
            {6, 5, 3, 0, -2, -2, -1, 1, 4, 6},                    // 重低音
            {-3, -2, -1, 0, 2, 3, 4, 3, 1, -1},                   // 清晰
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},                       // 自定义
    };
    private static final String[] HW_PRESETS = {"关闭", "默认", "流行", "摇滚", "爵士",
            "古典", "人声", "重低音", "清晰", "自定义"};

    private void applyHwPreset(int idx) {
        hwPresetIdx = idx;
        if (hwEq == null) {
            return;
        }
        float[] g = HW_PRESET_GAINS[idx];
        int n = Math.min(g.length, hwEq.getBandCount());
        hwEq.setEnabled(idx != 0);
        for (int i = 0; i < n; i++) {
            hwEq.setBandGain(i, g[i]);
        }
    }

    private void buildBands() {
        bands.removeAllViews();
        int n = hwMode ? hwEq.getBandCount() : AudioFx.bandCount();
        if (n <= 0) {
            TextView t = new TextView(act);
            t.setText("开始播放后即可调节各频段");
            t.setTextColor(0xFFB8B8C8);
            t.setTextSize(12.5f);
            t.setPadding(4 * d, 4 * d, 4 * d, 4 * d);
            bands.addView(t);
            return;
        }
        range = AudioFx.range();
        int min = AudioFx.minLevel();
        for (int i = 0; i < n; i++) {
            final int band = i;
            final int mn = min;
            LinearLayout row = new LinearLayout(act);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(2 * d, 2 * d, 2 * d, 2 * d);

            int lv0 = hwMode
                    ? Math.round(hwEq.getBandGain(i) * 100)
                    : AudioFx.level((short) i);
            TextView label = new TextView(act);
            label.setText(hwMode
                    ? Math.round(hwEq.getBandFreq(i)) + "Hz"
                    : AudioFx.bandFreq((short) i) + "Hz");
            label.setTextColor(0xFFB8B8C8);
            label.setTextSize(10.5f);
            label.setWidth(56 * d);

            SeekBar sb = new SeekBar(act);
            sb.setMax(range * 2);
            sb.setProgress(lv0 - min);
            sb.setLayoutParams(new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            final TextView val = new TextView(act);
            val.setText(fmtDb(lv0));
            val.setTextColor(0xFFF0F0F5);
            val.setTextSize(10.5f);
            val.setWidth(46 * d);
            val.setGravity(Gravity.RIGHT);

            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                    if (fromUser) {
                        if (hwMode) {
                            hwEq.setBandGain(band, (p + mn) / 100f);
                            hwEq.setEnabled(true);
                            hwPresetIdx = 9;   // 手动调整后标记为"自定义"
                        } else {
                            AudioFx.setLevel((short) band, p + mn);
                        }
                        val.setText(fmtDb(p + mn));
                    }
                }

                public void onStartTrackingTouch(SeekBar s) {
                }

                public void onStopTrackingTouch(SeekBar s) {
                    if (!hwMode) {
                        AudioFx.saveLevels();
                    }
                }
            });

            row.addView(label);
            row.addView(sb);
            row.addView(val);
            bands.addView(row);
        }
    }

    private static String fmtDb(int lv) {
        return (lv > 0 ? "+" : "") + (lv / 100) + "dB";
    }

    private View slider(String name, int value, int min, int max, final OnV cb) {
        LinearLayout ll = new LinearLayout(act);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setPadding(4 * d, 6 * d, 4 * d, 2 * d);

        final TextView tv = new TextView(act);
        tv.setTextSize(12.5f);
        tv.setTextColor(0xFFF0F0F5);
        ll.addView(tv);

        SeekBar sb = new SeekBar(act);
        sb.setMax(max - min);
        sb.setProgress(value - min);
        final int mn = min;
        tv.setText(name + "：" + pct(value - min, max - min));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                tv.setText(name + "：" + pct(p, s.getMax()));
                if (fromUser) {
                    cb.on(p + mn);
                }
            }

            public void onStartTrackingTouch(SeekBar s) {
            }

            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        ll.addView(sb);
        return ll;
    }

    private static String pct(int v, int max) {
        if (max <= 0) {
            return "0%";
        }
        return Math.round(v * 100f / max) + "%";
    }

    public interface OnV {
        void on(int v);
    }
}
