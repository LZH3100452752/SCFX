package com.shichen.player;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.SurfaceTexture;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * 悬浮窗小窗：比系统画中画更可控。
 * 支持按视频原始比例显示、拖动移动、双击放大/还原、
 * 播放暂停、进度条拖动、关闭、返回全屏。
 */
public class FloatWindow {

    /** 与播放页的桥接：由 PlayerActivity 实现 */
    public interface Host {
        /** 悬浮窗的画面已就绪，把解码输出切到这里；s 为 null 表示切回播放页 */
        void attachSurface(Surface s);

        long position();

        long duration();

        boolean isPlaying();

        void seek(long ms);

        void togglePlay();

        /** 点全屏：关闭悬浮窗并回到播放页 */
        void requestFullscreen();

        /** 点关闭：停止播放 */
        void requestClose();

        /** 视频有效宽高（用于按比例设置小窗尺寸），返回 null 表示未知 */
        int[] videoSize();
    }

    private final Context ctx;
    private final Host host;
    private final WindowManager wm;
    private final Handler main = new Handler(Looper.getMainLooper());

    private View root;
    private TextureView texture;
    private SeekBar seek;
    private TextView timeCur;
    private TextView timeTotal;
    private ImageButton btnPlay;
    private ImageButton btnClose;
    private ImageButton btnFull;
    private View header;
    private LinearLayout controls;

    private WindowManager.LayoutParams lp;
    private boolean showing = false;
    private boolean enlarged = false;
    private boolean userSeeking = false;
    private Surface surface;

    private int baseW;
    private int baseH;

    public FloatWindow(Context c, Host h) {
        ctx = c;
        host = h;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
    }

    public static boolean hasPermission(Context c) {
        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        return android.provider.Settings.canDrawOverlays(c);
    }

    public boolean isShowing() {
        return showing;
    }

    /** 显示小窗。宽度取屏幕的 42%，高度严格按视频原始比例计算 */
    public boolean show() {
        if (showing) {
            return true;
        }
        if (!hasPermission(ctx)) {
            return false;
        }
        root = buildView();
        int type;
        if (Build.VERSION.SDK_INT >= 26) {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            type = WindowManager.LayoutParams.TYPE_PHONE;
        }
        android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        int[] sz = calcSize(dm, false);
        baseW = sz[0];
        baseH = sz[1];
        lp = new WindowManager.LayoutParams(
                sz[0], sz[1],
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dm.widthPixels - sz[0] - (int) (8 * dm.density);
        lp.y = (int) (80 * dm.density);
        try {
            wm.addView(root, lp);
        } catch (Exception e) {
            return false;
        }
        showing = true;
        startUpdate();
        setControlsVisible(true);
        scheduleHide();
        // 可见性自检：部分 ROM（如 MIUI）还需"后台弹出界面"权限，
        // 悬浮窗会被静默拦下，这里检测出来并明确提示
        main.postDelayed(new Runnable() {
            public void run() {
                if (!showing || root == null) {
                    return;
                }
                boolean visible = root.isAttachedToWindow()
                        && root.getWindowVisibility() == View.VISIBLE;
                if (!visible && ctx instanceof PlayerActivity) {
                    Ui.toast(ctx, "悬浮窗未显示：请在系统设置中允许「后台弹出界面」");
                }
            }
        }, 1200);
        return true;
    }

    public void dismiss() {
        if (!showing) {
            return;
        }
        showing = false;
        try {
            wm.removeView(root);
        } catch (Exception ignored) {
        }
        if (surface != null) {
            try {
                surface.release();
            } catch (Exception ignored) {
            }
            surface = null;
        }
        main.removeCallbacks(updateRun);
        root = null;
    }

    /** 按视频原始比例计算小窗尺寸：3:4 的视频就是 3:4 的小窗 */
    private int[] calcSize(android.util.DisplayMetrics dm, boolean big) {
        int[] vs = host.videoSize();
        double ratio;
        if (vs != null && vs[0] > 0 && vs[1] > 0) {
            ratio = vs[0] / (double) vs[1];
        } else {
            ratio = 16.0 / 9.0;
        }
        if (ratio <= 0.01) {
            ratio = 16.0 / 9.0;
        }
        int w = (int) (dm.widthPixels * (big ? 0.72f : 0.42f));
        int h = (int) (w / ratio);
        int maxH = (int) (dm.heightPixels * (big ? 0.62f : 0.40f));
        if (h > maxH) {
            h = maxH;
            w = (int) (h * ratio);
        }
        int minW = (int) (150 * dm.density);
        if (w < minW) {
            w = minW;
            h = (int) (w / ratio);
        }
        return new int[]{w, h};
    }

    private View buildView() {
        android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        int d = (int) dm.density;
        int[] sz = calcSize(dm, enlarged);
        int w = sz[0];
        int h = sz[1];

        // 外层：系统画中画风格的圆角黑底
        FrameLayout outer = new FrameLayout(ctx);
        outer.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        android.graphics.drawable.GradientDrawable bg =
                new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xE6000000);
        bg.setCornerRadius(12 * d);
        outer.setBackgroundDrawable(bg);
        // 圆角裁剪：让画面也跟随圆角，接近系统画中画观感
        if (Build.VERSION.SDK_INT >= 21) {
            outer.setClipToOutline(true);
            outer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                public void getOutline(View view, android.graphics.Outline outline) {
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(),
                            12 * ctx.getResources().getDisplayMetrics().density);
                }
            });
        }

        // ---- 画面 ----
        texture = new TextureView(ctx);
        texture.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            public void onSurfaceTextureAvailable(SurfaceTexture st, int w2, int h2) {
                surface = new Surface(st);
                host.attachSurface(surface);
            }

            public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w2, int h2) {
            }

            public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                host.attachSurface(null);
                return true;
            }

            public void onSurfaceTextureUpdated(SurfaceTexture st) {
            }
        });
        outer.addView(texture);

        // ---- 右上角圆形关闭按钮（对齐系统画中画） ----
        btnClose = new ImageButton(ctx);
        btnClose.setImageResource(R.drawable.ic_close);
        btnClose.setBackgroundResource(android.R.color.transparent);
        btnClose.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        btnClose.setColorFilter(0xFFFFFFFF);
        btnClose.setPadding(5 * d, 5 * d, 5 * d, 5 * d);
        int closeSize = (int) (24 * dm.density);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(closeSize, closeSize);
        cp.gravity = Gravity.TOP | Gravity.END;
        cp.setMargins(0, (int) (4 * dm.density), (int) (4 * dm.density), 0);
        btnClose.setLayoutParams(cp);
        android.graphics.drawable.GradientDrawable cb =
                new android.graphics.drawable.GradientDrawable();
        cb.setColor(0x99000000);
        cb.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        btnClose.setBackgroundDrawable(cb);
        btnClose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                host.requestClose();
            }
        });
        outer.addView(btnClose);

        // ---- 底部控制条（单行浮层：播放 / 时间 / 进度 / 全屏） ----
        controls = new LinearLayout(ctx);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        android.graphics.drawable.GradientDrawable ctlBg =
                new android.graphics.drawable.GradientDrawable();
        ctlBg.setColor(0xB3000000);
        ctlBg.setCornerRadius(10 * d);
        controls.setBackgroundDrawable(ctlBg);
        controls.setPadding(5 * d, 3 * d, 5 * d, 3 * d);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        bp.gravity = Gravity.BOTTOM;
        bp.setMargins((int) (4 * dm.density), 0, (int) (4 * dm.density),
                (int) (4 * dm.density));
        controls.setLayoutParams(bp);

        int btn = (int) (24 * dm.density);
        btnPlay = new ImageButton(ctx);
        btnPlay.setImageResource(R.drawable.ic_play);
        btnPlay.setBackgroundResource(android.R.color.transparent);
        btnPlay.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        btnPlay.setColorFilter(0xFFFFFFFF);
        btnPlay.setPadding(2 * d, 2 * d, 2 * d, 2 * d);
        btnPlay.setLayoutParams(new LinearLayout.LayoutParams(btn, btn));
        btnPlay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                host.togglePlay();
                refreshPlayIcon();
            }
        });
        controls.addView(btnPlay);

        timeCur = new TextView(ctx);
        timeCur.setText("00:00");
        timeCur.setTextSize(9f);
        timeCur.setTextColor(0xDDFFFFFF);
        timeCur.setPadding(2 * d, 0, 2 * d, 0);
        controls.addView(timeCur);

        seek = new SeekBar(ctx);
        seek.setMax(1000);
        seek.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s2, int p, boolean fromUser) {
                if (fromUser) {
                    long dur = host.duration();
                    if (dur > 0 && timeCur != null) {
                        timeCur.setText(MediaUtils.formatDuration(p * dur / 1000));
                    }
                }
            }

            public void onStartTrackingTouch(SeekBar s2) {
                userSeeking = true;
            }

            public void onStopTrackingTouch(SeekBar s2) {
                userSeeking = false;
                long dur = host.duration();
                if (dur > 0) {
                    host.seek(s2.getProgress() * dur / 1000);
                }
            }
        });
        controls.addView(seek);

        btnFull = new ImageButton(ctx);
        btnFull.setImageResource(R.drawable.ic_fullscreen);
        btnFull.setBackgroundResource(android.R.color.transparent);
        btnFull.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        btnFull.setColorFilter(0xFFFFFFFF);
        btnFull.setPadding(2 * d, 2 * d, 2 * d, 2 * d);
        btnFull.setLayoutParams(new LinearLayout.LayoutParams(btn, btn));
        btnFull.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                host.requestFullscreen();
            }
        });
        controls.addView(btnFull);

        // 总时长以极小字显示在右上角，不占控制条空间
        timeTotal = new TextView(ctx);
        timeTotal.setText("00:00");
        timeTotal.setTextSize(9f);
        timeTotal.setTextColor(0x99FFFFFF);
        outer.addView(controls);


        setupDrag(outer, dm);
        refreshPlayIcon();
        return outer;
    }

    /** 拖动移动 + 双击放大还原 */
    private void setupDrag(View v, final android.util.DisplayMetrics dm) {
        final int[] start = new int[2];
        final float[] last = new float[2];
        final long[] downAt = new long[1];
        final float[] downXy = new float[2];
        final int slop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        final boolean[] moved = new boolean[1];

        v.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        start[0] = lp.x;
                        start[1] = lp.y;
                        last[0] = e.getRawX();
                        last[1] = e.getRawY();
                        downXy[0] = e.getRawX();
                        downXy[1] = e.getRawY();
                        downAt[0] = System.currentTimeMillis();
                        moved[0] = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - last[0];
                        float dy = e.getRawY() - last[1];
                        if (Math.abs(e.getRawX() - downXy[0]) > slop
                                || Math.abs(e.getRawY() - downXy[1]) > slop) {
                            moved[0] = true;
                        }
                        int nx = (int) (lp.x + dx);
                        int ny = (int) (lp.y + dy);
                        // 限制在屏幕范围内，不允许被拖到屏幕外
                        int maxX = dm.widthPixels - baseW;
                        int maxY = dm.heightPixels - baseH;
                        if (maxX < 0) {
                            maxX = 0;
                        }
                        if (maxY < 0) {
                            maxY = 0;
                        }
                        if (nx < 0) {
                            nx = 0;
                        }
                        if (nx > maxX) {
                            nx = maxX;
                        }
                        if (ny < 0) {
                            ny = 0;
                        }
                        if (ny > maxY) {
                            ny = maxY;
                        }
                        lp.x = nx;
                        lp.y = ny;
                        try {
                            wm.updateViewLayout(root, lp);
                        } catch (Exception ignored) {
                        }
                        last[0] = e.getRawX();
                        last[1] = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        long dur = System.currentTimeMillis() - downAt[0];
                        if (!moved[0] && dur < 300) {
                            // 单击：显示/隐藏控件，并重新计时
                            boolean vis = controls != null
                                    && controls.getVisibility() == View.VISIBLE;
                            setControlsVisible(!vis);
                            if (!vis) {
                                scheduleHide();
                            } else {
                                main.removeCallbacks(hideControls);
                            }
                            // 第二次点击判定双击：放大 / 还原
                            if (System.currentTimeMillis() - lastTapAt < 320) {
                                toggleSize(dm);
                                lastTapAt = 0;
                            } else {
                                lastTapAt = System.currentTimeMillis();
                            }
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private long lastTapAt = 0;
    /** 控制条与关闭键空闲后自动隐藏，画面完整不被遮挡 */
    private final Runnable hideControls = new Runnable() {
        public void run() {
            if (!showing) {
                return;
            }
            if (userSeeking) {
                main.postDelayed(hideControls, 2500);
                return;
            }
            setControlsVisible(false);
        }
    };

    private void setControlsVisible(boolean v) {
        if (controls != null) {
            controls.setVisibility(v ? View.VISIBLE : View.GONE);
        }
        if (btnClose != null) {
            btnClose.setVisibility(v ? View.VISIBLE : View.GONE);
        }
    }

    private void scheduleHide() {
        main.removeCallbacks(hideControls);
        main.postDelayed(hideControls, 2500);
    }

    /** 双击切换大小：小窗 ↔ 放大，高度始终按视频比例 */
    private void toggleSize(android.util.DisplayMetrics dm) {
        enlarged = !enlarged;
        int[] sz = calcSize(dm, enlarged);
        baseW = sz[0];
        baseH = sz[1];
        lp.width = sz[0];
        lp.height = sz[1];
        try {
            wm.updateViewLayout(root, lp);
        } catch (Exception ignored) {
        }
    }

    private void refreshPlayIcon() {
        if (btnPlay != null) {
            btnPlay.setImageResource(host.isPlaying()
                    ? R.drawable.ic_pause : R.drawable.ic_play);
        }
    }

    private final Runnable updateRun = new Runnable() {
        public void run() {
            if (!showing) {
                return;
            }
            long dur = host.duration();
            long pos = host.position();
            if (dur > 0) {
                if (timeTotal != null) {
                    timeTotal.setText(MediaUtils.formatDuration(dur));
                }
                if (!userSeeking) {
                    if (seek != null) {
                        seek.setProgress((int) (pos * 1000L / dur));
                    }
                    if (timeCur != null) {
                        timeCur.setText(MediaUtils.formatDuration(pos));
                    }
                }
            }
            refreshPlayIcon();
            main.postDelayed(updateRun, 400);
        }
    };

    private void startUpdate() {
        main.removeCallbacks(updateRun);
        main.postDelayed(updateRun, 300);
    }

    /** 视频切换后按比例重设小窗尺寸 */
    public void applyVideoSize() {
        if (!showing || root == null) {
            return;
        }
        android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        int[] sz = calcSize(dm, enlarged);
        baseW = sz[0];
        baseH = sz[1];
        lp.width = sz[0];
        lp.height = sz[1];
        try {
            wm.updateViewLayout(root, lp);
        } catch (Exception ignored) {
        }
    }
}
