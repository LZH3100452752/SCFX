package com.shichen.player;

import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.provider.MediaStore;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class VideoScanner {

    private static final String[] COLS = {
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.MIME_TYPE
    };

    public static List<VideoItem> scan(Context c) {
        List<VideoItem> list = new ArrayList<VideoItem>();
        List<String> white = new DbHelper(c).dirs(DbHelper.TYPE_WHITE);
        List<String> black = new DbHelper(c).dirs(DbHelper.TYPE_BLACK);
        int minSec = Prefs.minDuration(c);
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, COLS, null, null,
                    MediaStore.Video.Media.DATE_ADDED + " DESC");
            if (cur == null) {
                return list;
            }
            int iId = cur.getColumnIndex(MediaStore.Video.Media._ID);
            int iData = cur.getColumnIndex(MediaStore.Video.Media.DATA);
            int iName = cur.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME);
            int iTitle = cur.getColumnIndex(MediaStore.Video.Media.TITLE);
            int iDur = cur.getColumnIndex(MediaStore.Video.Media.DURATION);
            int iSize = cur.getColumnIndex(MediaStore.Video.Media.SIZE);
            int iDate = cur.getColumnIndex(MediaStore.Video.Media.DATE_ADDED);
            int iMod = cur.getColumnIndex(MediaStore.Video.Media.DATE_MODIFIED);
            int iW = cur.getColumnIndex(MediaStore.Video.Media.WIDTH);
            int iH = cur.getColumnIndex(MediaStore.Video.Media.HEIGHT);
            int iB = cur.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME);
            int iM = cur.getColumnIndex(MediaStore.Video.Media.MIME_TYPE);

            while (cur.moveToNext()) {
                String path = iData >= 0 ? cur.getString(iData) : null;
                if (path == null || path.length() == 0) {
                    continue;
                }
                if (!allowed(path, white, black)) {
                    continue;
                }
                File f = new File(path);
                if (!f.exists()) {
                    continue;
                }
                VideoItem v = new VideoItem();
                v.id = iId >= 0 ? cur.getLong(iId) : 0;
                v.path = path;
                v.title = iName >= 0 && cur.getString(iName) != null
                        ? cur.getString(iName) : f.getName();
                v.duration = iDur >= 0 ? cur.getLong(iDur) : 0;
                v.size = iSize >= 0 ? cur.getLong(iSize) : f.length();
                v.dateAdded = iDate >= 0 ? cur.getLong(iDate) * 1000 : f.lastModified();
                v.dateModified = iMod >= 0 ? cur.getLong(iMod) * 1000 : f.lastModified();
                v.width = iW >= 0 ? cur.getInt(iW) : 0;
                v.height = iH >= 0 ? cur.getInt(iH) : 0;
                v.bucket = iB >= 0 ? cur.getString(iB) : "";
                v.mime = iM >= 0 ? cur.getString(iM) : "";
                if (Prefs.hideShort(c) && v.duration > 0 && v.duration < minSec * 1000L) {
                    continue;
                }
                list.add(v);
            }
        } catch (Exception ignored) {
        } finally {
            if (cur != null) {
                cur.close();
            }
        }
        if (list.isEmpty()) {
            list.addAll(fileScan(white, black, minSec));
        }
        return list;
    }

    public static boolean isVideoName(String name) {
        if (name == null) {
            return false;
        }
        String n = name.toLowerCase(java.util.Locale.getDefault());
        for (String e : VIDEO_EXT) {
            if (n.endsWith(e)) {
                return true;
            }
        }
        return false;
    }

    public static boolean allowed(String path, List<String> white, List<String> black) {
        String dir = path.substring(0, Math.max(0, path.lastIndexOf('/')));
        for (String b : black) {
            if (dir.equals(b) || dir.startsWith(b + "/") || path.startsWith(b)) {
                return false;
            }
        }
        if (white == null || white.isEmpty()) {
            return true;
        }
        for (String w : white) {
            if (dir.equals(w) || dir.startsWith(w + "/") || path.startsWith(w)) {
                return true;
            }
        }
        return false;
    }

    private static final String[] VIDEO_EXT = {".mp4", ".mkv", ".webm", ".avi", ".mov",
            ".m4v", ".3gp", ".3g2", ".flv", ".ts", ".m2ts", ".mpg", ".mpeg", ".ogv",
            ".rmvb", ".rm", ".asf", ".wmv", ".vob", ".divx", ".f4v", ".mts"};

    /** MediaStore 不可用时的兜底递归扫描 */
    private static List<VideoItem> fileScan(List<String> white, List<String> black, int minSec) {
        List<VideoItem> out = new ArrayList<VideoItem>();
        List<String> roots = new ArrayList<String>();
        if (white != null && !white.isEmpty()) {
            roots.addAll(white);
        } else {
            roots.addAll(commonDirs());
        }
        for (String root : roots) {
            walk(new File(root), out, black, minSec, 0);
        }
        return out;
    }

    private static void walk(File dir, List<VideoItem> out, List<String> black,
                             int minSec, int depth) {
        if (dir == null || !dir.isDirectory() || depth > 4 || out.size() > 4000) {
            return;
        }
        File[] fs = dir.listFiles();
        if (fs == null) {
            return;
        }
        for (File f : fs) {
            if (f.isDirectory()) {
                if (!f.getName().startsWith(".")) {
                    walk(f, out, black, minSec, depth + 1);
                }
                continue;
            }
            String n = f.getName().toLowerCase(Locale.US);
            boolean hit = false;
            for (String e : VIDEO_EXT) {
                if (n.endsWith(e)) {
                    hit = true;
                    break;
                }
            }
            if (!hit) {
                continue;
            }
            String path = f.getAbsolutePath();
            if (!allowed(path, null, black)) {
                continue;
            }
            VideoItem v = new VideoItem();
            v.path = path;
            v.title = f.getName();
            v.size = f.length();
            v.dateAdded = f.lastModified();
            v.dateModified = f.lastModified();
            long[] sz = MediaUtils.probeVideoSize(path);
            v.width = (int) sz[0];
            v.height = (int) sz[1];
            v.duration = sz.length > 3 ? sz[3] : 0;
            if (v.duration > 0 && v.duration < minSec * 1000L) {
                continue;
            }
            out.add(v);
        }
    }

    public static Map<String, List<VideoItem>> groupByDir(List<VideoItem> list) {
        Map<String, List<VideoItem>> map = new LinkedHashMap<String, List<VideoItem>>();
        for (VideoItem v : list) {
            String d = v.dir();
            List<VideoItem> l = map.get(d);
            if (l == null) {
                l = new ArrayList<VideoItem>();
                map.put(d, l);
            }
            l.add(v);
        }
        return map;
    }

    public static List<String> commonDirs() {
        List<String> dirs = new ArrayList<String>();
        String root = android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
        String[] subs = {"/DCIM", "/Movies", "/Download", "/Pictures", "/Videos", "/Tencent",
                "/QQBrowser", "/Documents", "/BaiduNetdisk", "/Xunlei", "/WeChat"};
        dirs.add(root);
        for (String s : subs) {
            File f = new File(root + s);
            if (f.isDirectory()) {
                dirs.add(f.getAbsolutePath());
            }
        }
        if (Build.VERSION.SDK_INT >= 19) {
            File[] ext = new File("/storage").listFiles();
            if (ext != null) {
                for (File f : ext) {
                    if (f.isDirectory() && !f.getAbsolutePath().equals(root)) {
                        dirs.add(f.getAbsolutePath());
                        File[] inner = f.listFiles();
                        if (inner != null) {
                            for (File g : inner) {
                                if (g.isDirectory() && !g.getName().startsWith(".")) {
                                    dirs.add(g.getAbsolutePath());
                                }
                            }
                        }
                    }
                }
            }
        }
        return dirs;
    }
}
