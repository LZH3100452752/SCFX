package com.shichen.player;

import android.content.Context;
import android.os.Build;
import android.os.Environment;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** 播放诊断：记录全链路步骤与异常，可导出报告文件 */
public class Diagnostics {
    private static final List<String> log = new ArrayList<String>();
    private static final SimpleDateFormat FMT =
            new SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault());

    public static void clear() {
        log.clear();
    }

    public static synchronized void log(String tag, String msg) {
        String line = FMT.format(new Date()) + " [" + tag + "] " + msg;
        log.add(line);
        android.util.Log.d("ShichenDiag", line);
    }

    public static synchronized void err(String tag, Throwable t) {
        String line = FMT.format(new Date()) + " [" + tag + "] EXCEPTION "
                + t.getClass().getSimpleName() + ": " + t.getMessage();
        log.add(line);
        java.io.StringWriter sw = new java.io.StringWriter();
        t.printStackTrace(new java.io.PrintWriter(sw));
        log.add(sw.toString());
        android.util.Log.e("ShichenDiag", line, t);
    }

    public static String text() {
        StringBuilder sb = new StringBuilder();
        sb.append("时尘播放器 诊断报告\n");
        sb.append("生成时间：").append(new Date().toString()).append("\n");
        sb.append("设备：").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("\n");
        sb.append("系统：Android ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("----------------------------------------\n");
        synchronized (Diagnostics.class) {
            for (String s : log) {
                sb.append(s).append("\n");
            }
        }
        return sb.toString();
    }

    /** 导出到外部存储，返回文件绝对路径；失败返回 null */
    public static String export(Context c) {
        try {
            File dir;
            if (Build.VERSION.SDK_INT >= 19) {
                dir = c.getExternalFilesDir(null);
            } else {
                dir = new File(Environment.getExternalStorageDirectory(), "Shichen");
            }
            if (dir == null) {
                return null;
            }
            if (!dir.exists()) {
                dir.mkdirs();
            }
            File f = new File(dir, "shichen_diag.txt");
            FileOutputStream os = new FileOutputStream(f, false);
            os.write(text().getBytes("UTF-8"));
            os.close();
            return f.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }
}
