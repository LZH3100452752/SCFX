package com.shichen.player;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.net.Uri;
import android.os.Build;
import android.view.Surface;

import java.util.ArrayList;
import java.util.List;

public class SystemEngine implements PlayerEngine {

    private MediaPlayer mp;
    private Callback cb;
    private Surface surface;
    private long duration = 0;
    private int buffering = 0;
    private float speed = 1.0f;
    private boolean prepared = false;
    private boolean playing = false;
    private long startMs = 0;
    private volatile boolean haveSurface = false;
    private boolean fillMode = false;

    public void setCallback(Callback cb) {
        this.cb = cb;
    }

    public void setSurface(Surface surface) {
        this.surface = surface;
        if (mp != null && surface != null && !haveSurface) {
            try {
                mp.setSurface(surface);
                haveSurface = true;
            } catch (Exception ignored) {
            }
        }
    }

    public void prepare(Context c, String path, long startMs) throws Exception {
        this.startMs = startMs;
        mp = new MediaPlayer();
        mp.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
        if (path.startsWith("content://") || path.startsWith("http") || path.startsWith("rtsp")) {
            mp.setDataSource(c, Uri.parse(path));
        } else {
            mp.setDataSource(path);
        }
        // 只在此处绑定一次 surface；prepared 之后再次 setSurface 会让部分机型重置渲染导致黑屏
        if (surface != null) {
            mp.setSurface(surface);
            haveSurface = true;
        }
        // 兼容模式（SurfaceView 全屏）下由 MediaPlayer 自行适配画面比例
        applyScaling();
        mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer m) {
                prepared = true;
                duration = m.getDuration();
                if (startMs > 0 && startMs < duration - 1000) {
                    try {
                        m.seekTo((int) startMs);
                    } catch (Exception ignored) {
                    }
                }
                if (speed != 1.0f) {
                    applySpeed(speed);
                }
                if (cb != null) {
                    cb.onPrepared(m.getVideoWidth(), m.getVideoHeight(), duration);
                }
            }
        });
        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer m) {
                playing = false;
                if (cb != null) {
                    cb.onCompletion();
                }
            }
        });
        mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            public boolean onError(MediaPlayer m, int what, int extra) {
                if (cb != null) {
                    cb.onError("系统内核错误 (" + what + ")");
                }
                return true;
            }
        });
        mp.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener() {
            public void onBufferingUpdate(MediaPlayer m, int percent) {
                buffering = percent;
                if (cb != null) {
                    cb.onBuffering(percent);
                }
            }
        });
        mp.setOnInfoListener(new MediaPlayer.OnInfoListener() {
            public boolean onInfo(MediaPlayer m, int what, int extra) {
                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START && cb != null) {
                    cb.onFirstFrame();
                }
                return false;
            }
        });
        mp.prepareAsync();
    }

    /** 由播放界面告知当前是否需要铺满（兼容模式下使用） */
    public void setFillMode(boolean fill) {
        fillMode = fill;
        applyScaling();
    }

    /** 兼容模式下根据画面比例选择系统缩放模式 */
    private void applyScaling() {
        if (mp == null) {
            return;
        }
        try {
            int mode = fillMode
                    ? MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                    : MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT;
            mp.setVideoScalingMode(mode);
        } catch (Exception ignored) {
        }
    }

    private void applySpeed(float s) {
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                PlaybackParams pp = new PlaybackParams();
                pp.setSpeed(s);
                pp.setPitch(1.0f);
                mp.setPlaybackParams(pp);
            } catch (Exception ignored) {
            }
        }
    }

    public void start() {
        if (mp == null || !prepared) {
            return;
        }
        if (!haveSurface && surface != null) {
            try {
                mp.setSurface(surface);
                haveSurface = true;
            } catch (Exception ignored) {
            }
        }
        try {
            mp.start();
            playing = true;
            if (speed != 1.0f) {
                applySpeed(speed);
            }
        } catch (Exception ignored) {
        }
    }

    public void pause() {
        if (mp != null && playing) {
            try {
                mp.pause();
            } catch (Exception ignored) {
            }
            playing = false;
        }
    }

    public void seekTo(long ms) {
        if (mp != null && prepared) {
            try {
                mp.seekTo((int) ms);
            } catch (Exception ignored) {
            }
        }
    }

    public long position() {
        if (mp != null && prepared) {
            try {
                return mp.getCurrentPosition();
            } catch (Exception e) {
                return 0;
            }
        }
        return 0;
    }

    public long duration() {
        return duration;
    }

    public boolean isPlaying() {
        return mp != null && playing;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
        applySpeed(speed);
    }

    /** 音量放大倍数（1.0 ~ 2.0） */
    private float boost = 1.0f;

    public void setBoost(float b) {
        boost = b;
    }

    public void setVolume(float left, float right) {
        if (mp != null) {
            try {
                // MediaPlayer 音量上限 1.0，超出部分无法再提升，
                // 因此放大仅在源音量较低时有效（clamp 到 1.0）
                float l = Math.min(1.0f, left * boost);
                float r = Math.min(1.0f, right * boost);
                mp.setVolume(l, r);
            } catch (Exception ignored) {
            }
        }
    }

    public void release() {
        if (mp != null) {
            try {
                mp.stop();
            } catch (Exception ignored) {
            }
            try {
                mp.release();
            } catch (Exception ignored) {
            }
            mp = null;
        }
        prepared = false;
        playing = false;
    }

    public int buffered() {
        return buffering;
    }

    public List<TrackInfo> tracks() {
        List<TrackInfo> list = new ArrayList<TrackInfo>();
        if (mp == null || !prepared) {
            return list;
        }
        try {
            MediaPlayer.TrackInfo[] infos = mp.getTrackInfo();
            for (int i = 0; i < infos.length; i++) {
                MediaPlayer.TrackInfo ti = infos[i];
                int t = ti.getTrackType();
                int type = t == MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_VIDEO ? 0
                        : (t == MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_AUDIO ? 1 : 2);
                TrackInfo info = new TrackInfo(i, type, ti.toString());
                info.lang = ti.getLanguage();
                list.add(info);
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public void selectTrack(int index) {
        if (mp != null && prepared) {
            try {
                mp.selectTrack(index);
            } catch (Exception ignored) {
            }
        }
    }

    public String engineName() {
        return "系统播放器内核";
    }

    public int audioSessionId() {
        if (mp != null) {
            try {
                return mp.getAudioSessionId();
            } catch (Exception e) {
                return 0;
            }
        }
        return 0;
    }
}
