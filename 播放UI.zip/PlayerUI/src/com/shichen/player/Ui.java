package com.shichen.player;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ScrollView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Ui {

    public static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }

    public static void toast(Context c, int resId) {
        Toast.makeText(c, resId, Toast.LENGTH_SHORT).show();
    }

    /* ==================== 底部弹窗 ==================== */
    /**
     * 侧边面板：横屏时贴在屏幕右半边，高度填满，宽度约 42%，
     * 不遮挡左侧画面（参考主流播放器横屏工具面板）。
     */
    /** 把面板根布局的背景按当前透明度设置实时赋予（XML 里不再写死） */
    static void applyPanelBg(android.app.Activity act, View root) {
        if (act == null || root == null) {
            return;
        }
        // 只画描边：填充色统一由窗口背景提供，
        // 若这里再铺一层，两层半透明叠加会变成近乎实色（这正是之前"调了没变化"的原因）
        android.graphics.drawable.GradientDrawable gd =
                new android.graphics.drawable.GradientDrawable();
        gd.setColor(0x00000000);
        gd.setCornerRadius(22 * act.getResources().getDisplayMetrics().density);
        gd.setStroke(Math.max(1, (int) act.getResources().getDisplayMetrics().density),
                0x18FFFFFF);
        root.setBackgroundDrawable(gd);
    }

    /* ---- 已打开面板登记，用于透明度实时生效 ---- */
    private static final List<Object[]> openPanels = new ArrayList<Object[]>();

    /** 登记面板窗口与它的背景 drawable，透明度改变时可立即重刷 */
    static void registerPanel(android.app.Activity act, android.view.Window w,
                              android.graphics.drawable.GradientDrawable gd, String kind) {
        try {
            openPanels.add(new Object[]{act, w, gd, kind});
        } catch (Exception ignored) {
        }
    }

    /** 面板关闭时移除登记 */
    static void unregisterPanel(android.view.Window w) {
        for (int i = openPanels.size() - 1; i >= 0; i--) {
            Object[] e = openPanels.get(i);
            if (e[1] == w) {
                openPanels.remove(i);
            }
        }
    }

    /** 透明度改变后立即重刷所有已打开面板（不关闭重开） */
    public static void refreshPanelAlpha(android.app.Activity act) {
        for (int i = 0; i < openPanels.size(); i++) {
            try {
                Object[] e = openPanels.get(i);
                android.app.Activity a = (android.app.Activity) e[0];
                android.view.Window w = (android.view.Window) e[1];
                if (w == null || (w.getDecorView() == null)) {
                    continue;
                }
                if (w.getDecorView().getWindowToken() == null) {
                    continue;
                }
                android.graphics.drawable.GradientDrawable gd =
                        (android.graphics.drawable.GradientDrawable) e[2];
                String kind = (String) e[3];
                gd.setColor(panelColor(a, kind));
                w.setBackgroundDrawable(gd);
                View dv = w.getDecorView();
                if (dv != null) {
                    dv.postInvalidate();
                }
            } catch (Exception ignored) {
            }
        }
        if (act != null) {
            try {
                act.getWindow().getDecorView().postInvalidate();
            } catch (Exception ignored) {
            }
        }
    }

    /** 按用户设置的透明度生成面板底色（ARGB），默认按当前界面推断类别 */
    static int panelColor(android.app.Activity act) {
        return panelColor(act, null);
    }

    /**
     * 按类别生成面板底色。kind 为 null 时自动推断：
     * 播放界面 → player，其余 → main
     */
    static int panelColor(android.app.Activity act, String kind) {
        if (act == null) {
            return 0xB814141E;
        }
        if (!Prefs.panelTranslucent(act)) {
            return 0xFF14141E;
        }
        if (kind == null) {
            kind = (act instanceof PlayerActivity) ? "player" : "main";
        }
        return alphaColor(Prefs.panelAlphaKind(act, kind));
    }

    private static int alphaColor(int a) {
        int av = Math.round(255 * a / 100f);
        if (av < 0) {
            av = 0;
        }
        if (av > 255) {
            av = 255;
        }
        return (av << 24) | 0x14141E;
    }

    /**
     * 横屏侧边面板：贴在屏幕右半边，左侧圆角、右侧贴边。
     * 播放工具与播放设置专用（用户要求保持这个样式）。
     */
    public static AlertDialog side(android.app.Activity act, View root) {
        hidePlayerUi(act);
        if (act == null || act.isFinishing()) {
            return null;
        }
        float dm = act.getResources().getDisplayMetrics().density;
        int sp = (int) (10 * dm);
        android.widget.ScrollView sv;
        if (root instanceof android.widget.ScrollView) {
            sv = (android.widget.ScrollView) root;
            sv.setPadding(sp, sp, sp, sp);
        } else {
            sv = new android.widget.ScrollView(act);
            sv.setPadding(sp, sp, sp, sp);
            sv.addView(root);
        }
        final AlertDialog d;
        try {
            d = new AlertDialog.Builder(act).setView(sv).create();
        } catch (Exception e) {
            return null;
        }
        try {
            d.show();
        } catch (Exception e) {
            return null;
        }
        Window w = d.getWindow();
        if (w != null) {
            int wpx = act.getResources().getDisplayMetrics().widthPixels;
            w.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.width = Math.max((int) (wpx * 0.40f), (int) (300 * dm));
            lp.height = WindowManager.LayoutParams.MATCH_PARENT;
            lp.dimAmount = 0.10f;
            w.setAttributes(lp);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            android.graphics.drawable.GradientDrawable gd =
                    new android.graphics.drawable.GradientDrawable();
            gd.setColor(panelColor(act));
            gd.setCornerRadii(new float[]{20 * dm, 20 * dm, 0, 0, 0, 0,
                    20 * dm, 20 * dm});
            w.setBackgroundDrawable(gd);
            registerPanel(act, w, gd, null);
        }
        return d;
    }

    /** 任何弹窗打开前统一隐藏播放器 UI，避免控制条与弹窗重合 */
    private static void hidePlayerUi(android.app.Activity act) {
        if (act instanceof PlayerActivity) {
            ((PlayerActivity) act).hideControls();
        }
    }

    public static AlertDialog bottom(android.app.Activity act, View v) {
        return bottom(act, v, 0.78f);
    }

    /** 底部弹窗：超过屏幕 ratio 高度时自动加滚动并限高，避免铺满屏幕 */
    public static AlertDialog bottom(android.app.Activity act, View root, float ratio) {
        return bottom(act, root, ratio, null);
    }

    public static AlertDialog bottom(android.app.Activity act, View root, float ratio, String kind) {
        hidePlayerUi(act);
        if (act == null || act.isFinishing()) {
            return null;
        }
        View v = root;
        if (ratio > 0 && root != null) {
            int max = (int) (act.getResources().getDisplayMetrics().heightPixels * ratio);
            root.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            if (root.getMeasuredHeight() > max) {
                FrameLayout wrap = new FrameLayout(act);
                ScrollView sv = new ScrollView(act);
                sv.setLayoutParams(new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, max));
                sv.setFillViewport(false);
                sv.addView(root);
                wrap.addView(sv);
                v = wrap;
            }
        }
        AlertDialog d;
        try {
            d = new AlertDialog.Builder(act).setView(v).create();
        } catch (Exception e) {
            return null;
        }
        d.setOnShowListener(new DialogInterface.OnShowListener() {
            public void onShow(DialogInterface dialog) {
                Window w = ((AlertDialog) dialog).getWindow();
                if (w != null) {
                    // show() 之后系统会按主题重套一次 windowBackground，
                    // 这里必须再设回用户选择的面板底色，否则设置不生效
                    float dmS = act.getResources().getDisplayMetrics().density;
                    android.graphics.drawable.GradientDrawable gs =
                            new android.graphics.drawable.GradientDrawable();
                    gs.setColor(panelColor(act, kind));
                    gs.setCornerRadii(new float[]{0, 0, 22 * dmS, 22 * dmS,
                            22 * dmS, 22 * dmS, 0, 0});
                    w.setBackgroundDrawable(gs);
                    registerPanel(act, w, gs, null);
                }
            }
        });
        try {
            d.show();
        } catch (Exception e) {
            return null;
        }
        Window w = d.getWindow();
        if (w != null) {
            float dmW = act.getResources().getDisplayMetrics().density;
            boolean land = act.getResources().getConfiguration().orientation
                    == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
            if (land) {
                // 横屏改为居中窗口式：不再拉满宽度、不再是一条通长的侧栏，
                // 宽度最多 460dp 或屏幕的 52%，高度最多 76%
                int sw = act.getResources().getDisplayMetrics().widthPixels;
                int want = (int) (460 * dmW);
                int cap = (int) (sw * 0.52f);
                if (want > cap) {
                    want = cap;
                }
                w.setGravity(Gravity.CENTER);
                WindowManager.LayoutParams lp = w.getAttributes();
                lp.width = want;
                int sh = act.getResources().getDisplayMetrics().heightPixels;
                lp.height = Math.min(WindowManager.LayoutParams.WRAP_CONTENT,
                        (int) (sh * 0.76f));
                lp.dimAmount = 0.10f;
                w.setAttributes(lp);
                w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                android.graphics.drawable.GradientDrawable gb =
                        new android.graphics.drawable.GradientDrawable();
                gb.setColor(panelColor(act, kind));
                gb.setCornerRadius(20 * dmW);
                gb.setStroke(Math.max(1, (int) dmW), 0x18FFFFFF);
                w.setBackgroundDrawable(gb);
                registerPanel(act, w, gb, kind);
                return d;
            }
            w.setGravity(Gravity.BOTTOM);
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            lp.dimAmount = 0.10f;
            w.setAttributes(lp);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            // 面板底色统一由"面板背景透明度"设置决定（顶部圆角）
            float dmB = act.getResources().getDisplayMetrics().density;
            android.graphics.drawable.GradientDrawable gb =
                    new android.graphics.drawable.GradientDrawable();
            gb.setColor(panelColor(act, kind));
            gb.setCornerRadii(new float[]{22 * dmB, 22 * dmB, 22 * dmB, 22 * dmB, 0, 0, 0, 0});
            w.setBackgroundDrawable(gb);
            registerPanel(act, w, gb, null);
        }
        return d;
    }

    /**
     * 带图标的半透明列表面板：每项 = 圆形底图标 + 文字 + 当前项高亮。
     * 用于播放页「更多」等功能菜单，比纯文字列表更直观。
     */
    public static void sheetIcons(final android.app.Activity act, String title,
                                  final int[] icons, final String[] items,
                                  final int checked, final OnPick pick) {
        hidePlayerUi(act);
        final AlertDialog[] dgRef = new AlertDialog[1];
        int d = (int) act.getResources().getDisplayMetrics().density;
        int acc = ThemeEngine.accent(act);
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(8 * d, 4 * d, 8 * d, 10 * d);
        // 半透明面板：能透出后面的视频画面
                // 内层不再铺色，避免与窗口背景叠加
        box.setBackgroundColor(0x00000000);

        // 顶部小横条
        View bar = new View(act);
        bar.setBackgroundColor(0x59FFFFFF);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(34 * d, 3 * d);
        blp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        blp.bottomMargin = 6 * d;
        bar.setLayoutParams(blp);
        box.addView(bar);

        TextView t = new TextView(act);
        t.setText(title);
        t.setTextSize(15f);
        t.setTextColor(0xFFFFFFFF);
        t.setPadding(12 * d, 10 * d, 12 * d, 10 * d);
        box.addView(t);

        View sep = new View(act);
        sep.setBackgroundColor(0x26FFFFFF);
        sep.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1));
        box.addView(sep);

        for (int i = 0; i < items.length; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(act);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(10 * d, 9 * d, 10 * d, 9 * d);
            row.setBackgroundResource(i == checked
                    ? R.drawable.bg_panel_btn_sel : R.drawable.bg_panel_btn);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = 6 * d;
            row.setLayoutParams(lp);

            android.widget.FrameLayout circle = new android.widget.FrameLayout(act);
            int sz = 34 * d;
            circle.setLayoutParams(new LinearLayout.LayoutParams(sz, sz));
            ImageView iv = new ImageView(act);
            iv.setImageResource(icons[i]);
            iv.setColorFilter(i == checked ? 0xFFFFFFFF : acc);
            int ip = 8 * d;
            android.widget.FrameLayout.LayoutParams flp =
                    new android.widget.FrameLayout.LayoutParams(sz - ip, sz - ip);
            flp.gravity = android.view.Gravity.CENTER;
            circle.addView(iv, flp);
            row.addView(circle);

            TextView tv = new TextView(act);
            tv.setText(items[i]);
            tv.setTextSize(14f);
            tv.setTextColor(i == checked ? 0xFFFFFFFF : 0xFFEDEDF5);
            tv.setPadding(12 * d, 0, 6 * d, 0);
            tv.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(tv);

            if (i == checked) {
                TextView mark = new TextView(act);
                mark.setText("\u2713");
                mark.setTextSize(14f);
                mark.setTextColor(acc);
                row.addView(mark);
            }

            final int pos = i;
            row.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (dgRef[0] != null) {
                        try {
                            dgRef[0].dismiss();
                        } catch (Exception ignored) {
                        }
                    }
                    pick.onPick(pos);
                }
            });
            box.addView(row);
        }

        android.widget.ScrollView sv = new android.widget.ScrollView(act);
        sv.addView(box);
        sv.setPadding(6 * d, 0, 6 * d, 0);
        dgRef[0] = bottom(act, sv, 0.62f);
    }

    public static void sheet(final android.app.Activity act, String title, final String[] items,
                             final int checked, final OnPick pick) {
        hidePlayerUi(act);
        View v = LayoutInflater.from(act).inflate(R.layout.dialog_list, null);
        applyPanelBg(act, v);
        TextView t = (TextView) v.findViewById(R.id.title);
        t.setText(title);
        t.setTextColor(ThemeEngine.text(act));
        ListView lv = (ListView) v.findViewById(R.id.list);
        lv.setAdapter(new ArrayAdapter<String>(act, android.R.layout.simple_list_item_1, items) {
            public View getView(int pos, View cv, ViewGroup p) {
                View v2 = super.getView(pos, cv, p);
                TextView tv = (TextView) v2.findViewById(android.R.id.text1);
                int d = (int) getContext().getResources().getDisplayMetrics().density;
                tv.setPadding(20 * d, 13 * d, 20 * d, 13 * d);
                tv.setTextSize(14.5f);
                if (pos == checked) {
                    tv.setText("\u2713  " + getItem(pos));
                    tv.setTextColor(ThemeEngine.accent(getContext()));
                } else {
                    tv.setText("      " + getItem(pos));
                    tv.setTextColor(0xFFF0F0F5);
                }
                return v2;
            }
        });
        if (checked >= 0 && checked < items.length) {
            lv.setItemChecked(checked, true);
        }
        limitHeight(act, lv);
        final AlertDialog d = bottom(act, v);
        if (d == null) {
            return;
        }
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v2, int pos, long id) {
                try {
                    d.dismiss();
                } catch (Exception ignored) {
                }
                pick.onPick(pos);
            }
        });
    }

    /** 限制视图最大高度为屏幕的 55%，避免弹窗铺满屏幕 */
    private static void limitHeight(android.app.Activity act, View v) {
        int maxH = (int) (act.getResources().getDisplayMetrics().heightPixels * 0.5);
        v.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        if (v.getMeasuredHeight() > maxH) {
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            lp.height = maxH;
            v.setLayoutParams(lp);
        }
    }

    /** 半透明参数面板：内容区限高，可带取消/确定按钮 */
    /** 面板（不显示底部取消/完成按钮，内容区域更大） */
    public static AlertDialog panelNoButtons(android.app.Activity act, String title, View content) {
        return panelNoButtons(act, title, content, null);
    }

    public static AlertDialog panelNoButtons(android.app.Activity act, String title,
                                             View content, final String kind) {
        hidePlayerUi(act);
        View v = LayoutInflater.from(act).inflate(R.layout.dialog_panel, null);
        applyPanelBg(act, v);
        TextView t = (TextView) v.findViewById(R.id.title);
        t.setText(title);
        FrameLayout box = (FrameLayout) v.findViewById(R.id.content);
        box.addView(content);
        int maxH = (int) (act.getResources().getDisplayMetrics().heightPixels * 0.72);
        if (!(content instanceof ScrollView)) {
            content.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            if (content.getMeasuredHeight() > maxH) {
                ScrollView sv = new ScrollView(act);
                box.removeAllViews();
                box.addView(sv);
                sv.addView(content);
                ViewGroup.LayoutParams lp = sv.getLayoutParams();
                lp.height = maxH;
                sv.setLayoutParams(lp);
            }
        }
        final AlertDialog d = bottom(act, v);
        if (d == null) {
            return null;
        }
        v.findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v2) {
                safeDismiss(d);
            }
        });
        return d;
    }

    public static AlertDialog panel(final android.app.Activity act, String title, View content,
                                    boolean showButtons, final OnPanel ok) {
        hidePlayerUi(act);
        View v = LayoutInflater.from(act).inflate(R.layout.dialog_panel, null);
        applyPanelBg(act, v);
        TextView t = (TextView) v.findViewById(R.id.title);
        t.setText(title);
        FrameLayout box = (FrameLayout) v.findViewById(R.id.content);
        box.addView(content);
        int maxH = (int) (act.getResources().getDisplayMetrics().heightPixels * 0.74);
        View sc = null;
        if (content instanceof ScrollView) {
            sc = content;
        }
        if (sc != null) {
            content.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            if (content.getMeasuredHeight() > maxH) {
                ViewGroup.LayoutParams lp = content.getLayoutParams();
                lp.height = maxH;
                content.setLayoutParams(lp);
            }
        } else {
            content.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            if (content.getMeasuredHeight() > maxH) {
                ScrollView sv = new ScrollView(act);
                box.removeAllViews();
                box.addView(sv);
                sv.addView(content);
                ViewGroup.LayoutParams lp = sv.getLayoutParams();
                lp.height = maxH;
                sv.setLayoutParams(lp);
            }
        }
        View btns = v.findViewById(R.id.buttons);
        if (showButtons) {
            btns.setVisibility(View.VISIBLE);
        }
        final AlertDialog d = bottom(act, v);
        if (d == null) {
            return null;
        }
        v.findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v2) {
                safeDismiss(d);
            }
        });
        if (showButtons) {
            v.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    safeDismiss(d);
                }
            });
            v.findViewById(R.id.btn_ok).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    safeDismiss(d);
                    if (ok != null) {
                        ok.onOk(d);
                    }
                }
            });
        }
        return d;
    }

    /** 修改透明度设置时立即刷新"当前正在显示的面板"的底色，做到实时生效 */
    public static void refreshPanelBg(android.app.Activity act, AlertDialog d) {
        if (act == null || d == null) {
            return;
        }
        Window w = d.getWindow();
        if (w == null) {
            return;
        }
        float dm = act.getResources().getDisplayMetrics().density;
        android.graphics.drawable.GradientDrawable gd =
                new android.graphics.drawable.GradientDrawable();
        gd.setColor(panelColor(act));
        gd.setCornerRadius(20 * dm);
        w.setBackgroundDrawable(gd);
        w.getDecorView().invalidate();
    }

    /**
     * 紧凑面板：底部居中、限宽、半透明底。
     * 用于倍速这类只需要几个控件的小面板，横屏也不会占半屏。
     */
    public static AlertDialog panelCompact(final android.app.Activity act, String title,
                                           View content) {
        if (act == null || act.isFinishing()) {
            return null;
        }
        View v = LayoutInflater.from(act).inflate(R.layout.dialog_compact, null);
        TextView t = (TextView) v.findViewById(R.id.title);
        t.setText(title);
        FrameLayout box = (FrameLayout) v.findViewById(R.id.content);
        box.addView(content);
        // 内容过高时加滚动并限高；不超限时紧贴内容，底部不留空
        int maxH = (int) (act.getResources().getDisplayMetrics().heightPixels * 0.46f);
        content.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        if (content.getMeasuredHeight() > maxH) {
            ScrollView sv = new ScrollView(act);
            box.removeAllViews();
            box.addView(sv);
            sv.addView(content);
            ViewGroup.LayoutParams lp = sv.getLayoutParams();
            lp.height = maxH;
            sv.setLayoutParams(lp);
        }
        final AlertDialog d;
        try {
            d = new AlertDialog.Builder(act).setView(v).create();
            d.show();
        } catch (Exception e) {
            return null;
        }
        Window w = d.getWindow();
        if (w != null) {
            float dm = act.getResources().getDisplayMetrics().density;
            int sw = act.getResources().getDisplayMetrics().widthPixels;
            int want = (int) (400 * dm);
            if (want > sw - (int) (24 * dm)) {
                want = sw - (int) (24 * dm);
            }
            w.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.width = want;
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.dimAmount = 0.16f;
            w.setAttributes(lp);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            // 贴底：去掉窗口底部留白，内容多高面板就多高
            try {
                android.view.ViewGroup decor =
                        (android.view.ViewGroup) w.getDecorView();
                decor.setPadding(0, 0, 0, 0);
            } catch (Exception ignored) {
            }
            // 倍速面板用独立类别的透明度（不再跟随播放界面弹窗）
            android.graphics.drawable.GradientDrawable gd =
                    new android.graphics.drawable.GradientDrawable();
            gd.setColor(panelColor(act, "speed"));
            gd.setCornerRadius(20 * dm);
            gd.setStroke(Math.max(1, (int) dm), 0x22FFFFFF);
            w.setBackgroundDrawable(gd);
            registerPanel(act, w, gd, "speed");
        }
        v.findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v2) {
                safeDismiss(d);
            }
        });
        return d;
    }

    public interface OnPanel {
        void onOk(AlertDialog d);
    }

    public interface OnPick {
        void onPick(int index);
    }

    /* ==================== 排序面板（MX Player 风格） ==================== */
    public static void sortDialog(final android.app.Activity act, final SortCb cb) {
        View v = LayoutInflater.from(act).inflate(R.layout.dialog_sort, null);
        applyPanelBg(act, v);
        final int accent = ThemeEngine.accent(act);
        final int txt = ThemeEngine.text(act);
        final int sub = ThemeEngine.sub(act);

        final boolean[] grid = {Prefs.gridView(act)};
        final boolean[] folder = {Prefs.folderMode(act)};
        final int[] field = {Prefs.sortField(act)};
        final boolean[] asc = {Prefs.sortAsc(act)};

        final TextView vg = (TextView) v.findViewById(R.id.view_grid);
        final TextView vl = (TextView) v.findViewById(R.id.view_list);
        final TextView vf = (TextView) v.findViewById(R.id.view_folder);
        final TextView oa = (TextView) v.findViewById(R.id.order_asc);
        final TextView od = (TextView) v.findViewById(R.id.order_desc);
        final TextView ol = (TextView) v.findViewById(R.id.order_label);
        final FlowLayout fields = (FlowLayout) v.findViewById(R.id.fields);

        Runnable paint = new Runnable() {
            public void run() {
                int s = (int) act.getResources().getDisplayMetrics().density;
                vg.setBackgroundResource(grid[0] ? R.drawable.bg_chip_sel : R.drawable.bg_chip);
                vg.setTextColor(grid[0] ? Color.WHITE : txt);
                vl.setBackgroundResource(!grid[0] ? R.drawable.bg_chip_sel : R.drawable.bg_chip);
                vl.setTextColor(!grid[0] ? Color.WHITE : txt);
                vf.setBackgroundResource(folder[0] ? R.drawable.bg_chip_sel : R.drawable.bg_chip);
                vf.setTextColor(folder[0] ? Color.WHITE : txt);
                oa.setBackgroundResource(asc[0] ? R.drawable.bg_chip_sel : R.drawable.bg_chip);
                oa.setTextColor(asc[0] ? Color.WHITE : txt);
                od.setBackgroundResource(!asc[0] ? R.drawable.bg_chip_sel : R.drawable.bg_chip);
                od.setTextColor(!asc[0] ? Color.WHITE : txt);
                // 直接把排列方向写在选项上，一目了然（从上往下）
                oa.setText(SortEngine.rangeLabel(field[0]));
                od.setText(SortEngine.rangeLabelDesc(field[0]));
                ol.setText("从上往下排列");
                ol.setTextColor(sub);
                for (int i = 0; i < fields.getChildCount(); i++) {
                    TextView c = (TextView) fields.getChildAt(i);
                    boolean on = (i == field[0]);
                    c.setBackgroundResource(on ? R.drawable.bg_chip_sel : R.drawable.bg_chip);
                    c.setTextColor(on ? Color.WHITE : txt);
                }
            }
        };

        String[] names = SortEngine.fieldNames();
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView c = new TextView(act);
            c.setText(names[i]);
            c.setTextSize(13);
            c.setGravity(Gravity.CENTER);
            c.setPadding(18 * (int) act.getResources().getDisplayMetrics().density / 1, 11, 0, 0);
            int pd = (int) (14 * act.getResources().getDisplayMetrics().density);
            c.setPadding(pd, (int) (10 * act.getResources().getDisplayMetrics().density), pd,
                    (int) (10 * act.getResources().getDisplayMetrics().density));
            c.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            c.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v2) {
                    field[0] = idx;
                    paint.run();
                }
            });
            fields.addView(c);
        }
        paint.run();

        vg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v2) {
                grid[0] = true;
                paint.run();
            }
        });
        vl.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v2) {
                grid[0] = false;
                paint.run();
            }
        });
        vf.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v2) {
                folder[0] = !folder[0];
                paint.run();
            }
        });
        oa.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v2) {
                asc[0] = true;
                paint.run();
            }
        });
        od.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v2) {
                asc[0] = false;
                paint.run();
            }
        });

        final AlertDialog d = bottom(act, v);
        if (d == null) {
            return;
        }
        v.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v2) {
                safeDismiss(d);
            }
        });
        v.findViewById(R.id.btn_ok).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v2) {
                safeDismiss(d);
                Prefs.setGridView(act, grid[0]);
                Prefs.setFolderMode(act, folder[0]);
                Prefs.setSortField(act, field[0]);
                Prefs.setSortAsc(act, asc[0]);
                cb.onApply();
            }
        });
    }

    public interface SortCb {
        void onApply();
    }

    /* ==================== 输入 ==================== */
    public static void input(android.app.Activity act, String title, String def, String hint,
                             final OnText ok) {
        View v = LayoutInflater.from(act).inflate(R.layout.dialog_input, null);
        applyPanelBg(act, v);
        TextView t = (TextView) v.findViewById(R.id.title);
        t.setText(title);
        t.setTextColor(ThemeEngine.text(act));
        final EditText et = (EditText) v.findViewById(R.id.input);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        et.setTextColor(ThemeEngine.text(act));
        et.setHintTextColor(ThemeEngine.sub(act));
        if (def != null) {
            et.setText(def);
        }
        if (hint != null) {
            et.setHint(hint);
        }
        if (act == null || act.isFinishing()) {
            return;
        }
        final AlertDialog d;
        try {
            d = new AlertDialog.Builder(act).setView(v).create();
            d.show();
            Window w2 = d.getWindow();
            if (w2 != null) {
                float dmI = act.getResources().getDisplayMetrics().density;
                android.graphics.drawable.GradientDrawable gi =
                        new android.graphics.drawable.GradientDrawable();
                gi.setColor(panelColor(act));
                gi.setCornerRadius(20 * dmI);
                w2.setBackgroundDrawable(gi);
            }
        } catch (Exception e) {
            return;
        }
        TextView cancel = (TextView) v.findViewById(R.id.btn_cancel);
        TextView sure = (TextView) v.findViewById(R.id.btn_ok);
        sure.setTextColor(ThemeEngine.accent(act));
        cancel.setTextColor(ThemeEngine.sub(act));
        cancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v2) {
                d.dismiss();
            }
        });
        sure.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v2) {
                d.dismiss();
                ok.onText(et.getText().toString().trim());
            }
        });
    }

    public interface OnText {
        void onText(String text);
    }

    public static void confirm(android.app.Activity act, String msg, final Runnable yes) {
        if (act == null || act.isFinishing()) {
            return;
        }
        AlertDialog d;
        try {
            d = new AlertDialog.Builder(act)
                .setMessage(msg)
                .setNegativeButton(R.string.action_cancel, null)
                .setPositiveButton(R.string.action_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        yes.run();
                    }
                }).create();
            d.show();
        } catch (Exception e) {
            return;
        }
    }

    private static void safeDismiss(AlertDialog d) {
        try {
            if (d != null && d.isShowing()) {
                d.dismiss();
            }
        } catch (Exception ignored) {
        }
    }

    /* ==================== 目录选择 ==================== */
    public static void dirPick(android.app.Activity act, String title, List<String> dirs,
                              final OnDirs pick) {
        final boolean[] sel = new boolean[dirs.size()];
        View v = LayoutInflater.from(act).inflate(R.layout.dialog_list, null);
        applyPanelBg(act, v);
        TextView t = (TextView) v.findViewById(R.id.title);
        t.setText(title);
        t.setTextColor(ThemeEngine.text(act));
        ListView lv = (ListView) v.findViewById(R.id.list);
        lv.setAdapter(new ArrayAdapter<String>(act, R.layout.item_dir_pick, R.id.name, dirs) {
            public View getView(int pos, View cv, ViewGroup p) {
                View v2 = super.getView(pos, cv, p);
                TextView n = (TextView) v2.findViewById(R.id.name);
                TextView pa = (TextView) v2.findViewById(R.id.path);
                n.setTextColor(ThemeEngine.text(getContext()));
                pa.setText(getItem(pos));
                pa.setTextColor(ThemeEngine.sub(getContext()));
                FileNameHelper fh = new FileNameHelper();
                n.setText(fh.shortName(getItem(pos)));
                return v2;
            }
        });
        final AlertDialog d = bottom(act, v);
        if (d == null) {
            return;
        }
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v2, int pos, long id) {
                sel[pos] = !sel[pos];
                safeDismiss(d);
                java.util.List<String> out = new java.util.ArrayList<String>();
                for (int i = 0; i < sel.length; i++) {
                    if (sel[i]) {
                        out.add((String) p.getItemAtPosition(i));
                    }
                }
                pick.onDirs(out);
            }
        });
    }

    public static class FileNameHelper {
        public String shortName(String d) {
            String s = d.substring(d.lastIndexOf('/') + 1);
            return s.length() == 0 ? d : s;
        }
    }

    public interface OnDirs {
        void onDirs(List<String> dirs);
    }

    /* ==================== 行 ==================== */
    public static View row(Context c, String k, String v) {
        LinearLayout ll = new LinearLayout(c);
        ll.setOrientation(LinearLayout.HORIZONTAL);
        ll.setPadding(0, 9, 0, 9);
        TextView a = new TextView(c);
        a.setText(k);
        a.setTextSize(13);
        a.setTextColor(ThemeEngine.sub(c));
        a.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView b = new TextView(c);
        b.setText(v);
        b.setTextSize(13);
        b.setTextColor(ThemeEngine.text(c));
        b.setSingleLine(false);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.9f));
        ll.addView(a);
        ll.addView(b);
        return ll;
    }

    public static View rowWhite(Context c, String k, String v) {
        LinearLayout ll = new LinearLayout(c);
        ll.setOrientation(LinearLayout.HORIZONTAL);
        ll.setPadding(0, 9, 0, 9);
        TextView a = new TextView(c);
        a.setText(k);
        a.setTextSize(13);
        a.setTextColor(Color.parseColor("#A6FFFFFF"));
        a.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView b = new TextView(c);
        b.setText(v);
        b.setTextSize(13);
        b.setTextColor(Color.WHITE);
        b.setSingleLine(false);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.9f));
        ll.addView(a);
        ll.addView(b);
        return ll;
    }

    /** 底部弹窗中的一个操作行（带图标） */
    public static View actionRow(Context c, int icon, String text, View.OnClickListener l) {
        LinearLayout ll = new LinearLayout(c);
        ll.setOrientation(LinearLayout.HORIZONTAL);
        ll.setGravity(android.view.Gravity.CENTER_VERTICAL);
        int d = (int) c.getResources().getDisplayMetrics().density;
        ll.setPadding(20 * d, 13 * d, 16 * d, 13 * d);
        ImageView iv = new ImageView(c);
        iv.setImageResource(icon);
        iv.setLayoutParams(new LinearLayout.LayoutParams(22 * d, 22 * d));
        ThemeEngine.tint(iv, ThemeEngine.sub(c));
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextSize(15);
        tv.setTextColor(ThemeEngine.text(c));
        tv.setPadding(16 * d, 0, 0, 0);
        ll.addView(iv);
        ll.addView(tv);
        ll.setOnClickListener(l);
        return ll;
    }
}
