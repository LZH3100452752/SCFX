package com.shichen.player;

import android.content.Context;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Equalizer;
import android.media.audiofx.Virtualizer;

public class AudioFx {
    private static Equalizer eq;
    private static BassBoost bass;
    private static Virtualizer viz;
    private static Context ctx;
    private static int session = 0;
    public static final int[] PRESET_COUNT = {0};

    public static final String[] PRESETS = {"关闭", "默认", "流行", "摇滚", "爵士", "古典",
            "舞曲", "人声", "重低音", "柔和"};
    private static final short[] PRESET_IDS = {-1, 0, 1, 2, 3, 4, 5, 6, 7, 8};

    public static void init(Context c) {
        ctx = c.getApplicationContext();
    }

    public static void attach(int audioSessionId) {
        release();
        if (audioSessionId <= 0) {
            return;
        }
        session = audioSessionId;
        try {
            eq = new Equalizer(0, audioSessionId);
            eq.setEnabled(Prefs.audioFxOn(ctx));
        } catch (Exception e) {
            eq = null;
        }
        try {
            bass = new BassBoost(0, audioSessionId);
            int v = Prefs.bassBoost(ctx);
            if (v > 0) {
                bass.setStrength((short) v);
            }
            bass.setEnabled(v > 0);
        } catch (Exception e) {
            bass = null;
        }
        try {
            viz = new Virtualizer(0, audioSessionId);
            int v = Prefs.virtualizer(ctx);
            if (v > 0) {
                viz.setStrength((short) v);
            }
            viz.setEnabled(v > 0);
        } catch (Exception e) {
            viz = null;
        }
        applyPreset(Prefs.eqPreset(ctx), true);
        applySavedLevels();
    }

    public static void release() {
        try {
            if (eq != null) {
                eq.release();
            }
        } catch (Exception ignored) {
        }
        try {
            if (bass != null) {
                bass.release();
            }
        } catch (Exception ignored) {
        }
        try {
            if (viz != null) {
                viz.release();
            }
        } catch (Exception ignored) {
        }
        eq = null;
        bass = null;
        viz = null;
    }

    public static boolean available() {
        return eq != null;
    }

    public static int bandCount() {
        if (eq == null) {
            return 0;
        }
        try {
            return eq.getNumberOfBands();
        } catch (Exception e) {
            return 0;
        }
    }

    public static int bandFreq(short band) {
        if (eq == null) {
            return 0;
        }
        try {
            return eq.getCenterFreq(band) / 1000;
        } catch (Exception e) {
            return 0;
        }
    }

    public static int level(short band) {
        if (eq == null) {
            return 0;
        }
        try {
            return eq.getBandLevel(band);
        } catch (Exception e) {
            return 0;
        }
    }

    public static int range() {
        if (eq == null) {
            return 1500;
        }
        try {
            short[] r = eq.getBandLevelRange();
            return (r[1] - r[0]) / 2;
        } catch (Exception e) {
            return 1500;
        }
    }

    public static int minLevel() {
        if (eq == null) {
            return -1500;
        }
        try {
            return eq.getBandLevelRange()[0];
        } catch (Exception e) {
            return -1500;
        }
    }

    public static void setLevel(short band, int level) {
        if (eq == null) {
            return;
        }
        try {
            eq.setBandLevel(band, (short) level);
        } catch (Exception ignored) {
        }
    }

    public static void setEnabled(boolean on) {
        Prefs.setAudioFxOn(ctx, on);
        if (eq != null) {
            try {
                eq.setEnabled(on);
            } catch (Exception ignored) {
            }
        }
    }

    public static boolean enabled() {
        if (eq == null) {
            return false;
        }
        try {
            return eq.getEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    public static void setBass(int v) {
        Prefs.setBassBoost(ctx, v);
        if (bass != null) {
            try {
                bass.setStrength((short) v);
                bass.setEnabled(v > 0);
            } catch (Exception ignored) {
            }
        }
    }

    public static void setViz(int v) {
        Prefs.setVirtualizer(ctx, v);
        if (viz != null) {
            try {
                viz.setStrength((short) v);
                viz.setEnabled(v > 0);
            } catch (Exception ignored) {
            }
        }
    }

    public static void applyPreset(int idx, boolean silent) {
        if (eq == null) {
            return;
        }
        if (idx < 0 || idx >= PRESET_IDS.length) {
            return;
        }
        try {
            short n = eq.getNumberOfPresets();
            short want = PRESET_IDS[idx];
            if (want >= 0 && want < n) {
                eq.usePreset(want);
                if (!silent) {
                    saveLevels();
                    Prefs.setEqPreset(ctx, idx);
                }
            } else if (want < 0) {
                short bands = eq.getNumberOfBands();
                for (short b = 0; b < bands; b++) {
                    eq.setBandLevel(b, (short) 0);
                }
                if (!silent) {
                    saveLevels();
                    Prefs.setEqPreset(ctx, idx);
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static void saveLevels() {
        if (eq == null) {
            return;
        }
        try {
            short n = eq.getNumberOfBands();
            StringBuilder sb = new StringBuilder();
            for (short b = 0; b < n; b++) {
                if (b > 0) {
                    sb.append(",");
                }
                sb.append(eq.getBandLevel(b));
            }
            Prefs.setEqLevels(ctx, sb.toString());
        } catch (Exception ignored) {
        }
    }

    private static void applySavedLevels() {
        String s = Prefs.eqLevels(ctx);
        if (s == null || s.length() == 0 || eq == null) {
            return;
        }
        try {
            String[] parts = s.split(",");
            short n = eq.getNumberOfBands();
            for (int i = 0; i < n && i < parts.length; i++) {
                eq.setBandLevel((short) i, (short) Integer.parseInt(parts[i]));
            }
        } catch (Exception ignored) {
        }
    }

    public static int session() {
        return session;
    }
}
