package com.shichen.player;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.os.Bundle;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.PlaybackParams;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 自研解码内核 v2（性能强化版）
 * - 视频/音频双线程，MediaCodec 同步模式 + 精确调度
 * - 音画同步以音频时钟为主，无音轨时退化为系统时钟
 * - 输出缓冲队列上限，避免积压导致的卡顿
 * - 支持软/硬解强制、轨道选择、变速不变调
 */
public class CodecEngine implements PlayerEngine {

    private Callback cb;
    private Context ctx;
    private Surface surface;
    private String path;
    private long startMs;

    private MediaExtractor vEx;
    private MediaExtractor aEx;
    private MediaCodec vDec;
    private MediaCodec aDec;
    private AudioTrack audioTrack;

    private Thread vThread;
    /** 连续落后帧计数：只有持续落后才丢帧，避免抖动误丢 */
    private int lateCount = 0;
    /** 按帧率推算的最小出帧间隔（ms），0=不限流 */
    private int minFrameMs = 0;
    /** 上一帧渲染时刻（纳秒），用于自适应限流 */
    private long lastRenderNs = 0;
    /** 视频帧率，用于倍速时动态调节解码器运行速率 */
    private int videoFps = 0;
    /**
     * 倍速时是否静音。
     * 只在「倍速超出设备支持范围」或「AudioTrack 变速实际未生效」时才静音 ——
     * 这样既保住了常用倍速的声音，又避免了音画不同步与卡顿。
     */
    private volatile boolean audioMuted = false;
    private Thread aThread;
    private volatile boolean running = false;
    private volatile boolean released = false;
    private volatile boolean videoEos = false;
    private volatile boolean audioEos = false;
    private volatile boolean inputEosV = false;
    private volatile boolean inputEosA = false;

    private long durationUs = 0;
    private int vIndex = -1;
    private int aIndex = -1;

    /* ---- 时钟 ---- */
    private volatile long anchorMediaUs = 0;
    private volatile long anchorRealNs = 0;
    private volatile long audioClockUs = -1;
    private volatile long audioClockNs = 0;
    /* ---- 精确音频时钟：用 AudioTrack 播放头反推真实听感位置 ---- */
    private volatile long writtenFrames = 0;   // 累计写入的 PCM 帧数
    private volatile long anchorFrames = 0;    // 锚点：写入完成时的累计帧数
    private volatile long anchorPtsUs = -1;    // 锚点：该帧对应的媒体时间
    private volatile int lastHead = 0;         // 上一次读到的播放头，用于检测重置
    /** 音频变速是否真正生效；不生效时必须静音，否则音画必然不同步且卡顿 */
    private volatile boolean audioRateOk = true;
    private volatile double speed = 1.0;
    private volatile long pausedPos = 0;
    private volatile int pendingFrames = 0;

    private int videoWidth = 0;
    private int videoHeight = 0;
    private int rotation = 0;
    private List<TrackInfo> trackList = new ArrayList<TrackInfo>();
    private final Object sync = new Object();
    private boolean preferHw = true;
    private volatile boolean firstFrame = false;
    private volatile boolean hasAudio = false;
    private int sampleRate = 44100;
    private int channelCount = 2;

    private static final int MAX_PENDING = 3;      // 输出队列上限，防止积压
    private static final int VIDEO_TIMEOUT = 8000; // us

    public void setCallback(Callback cb) {
        this.cb = cb;
    }

    public void setSurface(Surface surface) {
        this.surface = surface;
    }

    public void setPreferHw(boolean hw) {
        preferHw = hw;
    }

    /* ============================ 准备 ============================ */
    public void prepare(Context c, String path, long startMs) throws Exception {
        this.ctx = c.getApplicationContext();
        this.path = path;
        this.startMs = startMs;
        released = false;
        firstFrame = false;
        trackList.clear();
        vIndex = -1;
        aIndex = -1;

        MediaExtractor probe = new MediaExtractor();
        try {
            if (isRemote(path)) {
                probe.setDataSource(this.ctx, Uri.parse(path), null);
            } else {
                probe.setDataSource(path);
            }
            for (int i = 0; i < probe.getTrackCount(); i++) {
                MediaFormat f = probe.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime == null) {
                    continue;
                }
                int t = mime.startsWith("video") ? 0 : (mime.startsWith("audio") ? 1 : 2);
                String lang = null;
                try {
                    lang = f.getString(MediaFormat.KEY_LANGUAGE);
                } catch (Exception ignored) {
                }
                TrackInfo ti = new TrackInfo(i, t, mime, lang);
                if (t == 0 && vIndex < 0) {
                    vIndex = i;
                    ti.selected = true;
                } else if (t == 1 && aIndex < 0) {
                    aIndex = i;
                    ti.selected = true;
                }
                trackList.add(ti);
            }
            if (vIndex >= 0) {
                MediaFormat vf = probe.getTrackFormat(vIndex);
                videoWidth = getInt(vf, MediaFormat.KEY_WIDTH);
                videoHeight = getInt(vf, MediaFormat.KEY_HEIGHT);
                try {
                    if (vf.containsKey(MediaFormat.KEY_ROTATION)) {
                        rotation = vf.getInteger(MediaFormat.KEY_ROTATION);
                    } else if (vf.containsKey("rotation-degrees")) {
                        rotation = vf.getInteger("rotation-degrees");
                    }
                } catch (Exception ignored) {
                }
            }
            if (aIndex >= 0) {
                MediaFormat af = probe.getTrackFormat(aIndex);
                sampleRate = getInt(af, MediaFormat.KEY_SAMPLE_RATE);
                if (sampleRate <= 0) {
                    sampleRate = 44100;
                }
                channelCount = getInt(af, MediaFormat.KEY_CHANNEL_COUNT);
                if (channelCount <= 0) {
                    channelCount = 2;
                }
                hasAudio = true;
            }
            long d = 0;
            try {
                if (probe.getTrackCount() > 0) {
                    MediaFormat f = probe.getTrackFormat(vIndex >= 0 ? vIndex : 0);
                    if (f.containsKey(MediaFormat.KEY_DURATION)) {
                        d = f.getLong(MediaFormat.KEY_DURATION);
                    }
                }
            } catch (Exception ignored) {
            }
            durationUs = d;
        } finally {
            probe.release();
        }

        if (vIndex < 0 && aIndex < 0) {
            throw new Exception("文件中没有可播放轨道");
        }

        if (vIndex >= 0) {
            vEx = createExtractor();
            vEx.selectTrack(vIndex);
            try {
                vDec = createDecoder(vEx.getTrackFormat(vIndex), false);
            } catch (Exception e) {
                throw new Exception("视频解码不可用");
            }
        }
        if (aIndex >= 0) {
            aEx = createExtractor();
            aEx.selectTrack(aIndex);
            aDec = createDecoder(aEx.getTrackFormat(aIndex), true);
            initAudioTrack();
        }

        seekInternal(startMs * 1000L);
        anchorMediaUs = startMs * 1000L;
        anchorRealNs = System.nanoTime();
        pausedPos = startMs;

        if (cb != null) {
            cb.onPrepared(videoWidth, videoHeight, durationUs / 1000);
        }

        if (vDec != null) {
            vThread = new Thread(videoRun, "shichen-video");
            vThread.setPriority(Thread.MAX_PRIORITY - 1);
            vThread.start();
        }
        if (aDec != null) {
            aThread = new Thread(audioRun, "shichen-audio");
            aThread.setPriority(Thread.MAX_PRIORITY);
            aThread.start();
        }
    }

    private static boolean isRemote(String p) {
        return p.startsWith("content://") || p.startsWith("http")
                || p.startsWith("rtsp") || p.startsWith("rtmp");
    }

    private static int getInt(MediaFormat f, String key) {
        try {
            if (f.containsKey(key)) {
                return f.getInteger(key);
            }
        } catch (Exception ignored) {
        }
        return 0;
    }

    private MediaExtractor createExtractor() throws Exception {
        MediaExtractor ex = new MediaExtractor();
        if (isRemote(path)) {
            ex.setDataSource(ctx, Uri.parse(path), null);
        } else {
            ex.setDataSource(path);
        }
        return ex;
    }

    private MediaCodec createDecoder(MediaFormat format, boolean audio) throws Exception {
        String mime = format.getString(MediaFormat.KEY_MIME);
        List<String> candidates = new ArrayList<String>();
        if (preferHw && Build.VERSION.SDK_INT >= 18) {
            candidates.addAll(findCodecs(mime, true));
        }
        candidates.addAll(findCodecs(mime, false));
        candidates.add(mime);

        // 流畅度优化：声明按实际帧率运行，并尽量启用低延迟解码
        if (!audio) {
            try {
                if (Build.VERSION.SDK_INT >= 23) {
                    int fps = 30;
                    try {
                        int f = format.getInteger(MediaFormat.KEY_FRAME_RATE);
                        if (f > 0) {
                            fps = f;
                        }
                    } catch (Exception ignored) {
                    }
                    format.setInteger(MediaFormat.KEY_OPERATING_RATE, Math.min(fps, 120));
                }
            } catch (Exception ignored) {
            }
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    format.setInteger("low-latency", 1);
                }
            } catch (Exception ignored) {
            }
        }

        MediaCodec last = null;
        Exception lastErr = null;
        for (String name : candidates) {
            try {
                MediaCodec c = MediaCodec.createByCodecName(name);
                c.configure(format, audio ? null : surface, null, 0);
                last = c;
                break;
            } catch (Exception e) {
                lastErr = e;
            }
        }
        if (last == null) {
            if (audio) {
                hasAudio = false;
                return null;
            }
            throw lastErr != null ? lastErr : new Exception("无可用解码器：" + mime);
        }
        last.start();
        return last;
    }

    private List<String> findCodecs(String mime, boolean hw) {
        List<String> out = new ArrayList<String>();
        try {
            if (Build.VERSION.SDK_INT >= 21) {
                MediaCodecList list = new MediaCodecList(MediaCodecList.ALL_CODECS);
                for (MediaCodecInfo info : list.getCodecInfos()) {
                    if (info.isEncoder()) {
                        continue;
                    }
                    boolean h = isHardware(info.getName());
                    if (hw != h) {
                        continue;
                    }
                    try {
                        for (String t : info.getSupportedTypes()) {
                            if (t.equalsIgnoreCase(mime)) {
                                out.add(info.getName());
                                break;
                            }
                        }
                    } catch (Exception ignored) {
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private static boolean isHardware(String name) {
        String n = name.toLowerCase(Locale.US);
        if (n.contains("omx.google") || n.contains("sw") || n.contains("software")) {
            return false;
        }
        if (n.contains("c2.android")) {
            return false;
        }
        return true;
    }

    private void initAudioTrack() {
        try {
            int chCfg = channelCount == 1 ? AudioFormat.CHANNEL_OUT_MONO
                    : AudioFormat.CHANNEL_OUT_STEREO;
            int minBuf = AudioTrack.getMinBufferSize(sampleRate, chCfg,
                    AudioFormat.ENCODING_PCM_16BIT);
            int buf = Math.max(minBuf, sampleRate / 4 * 2 * 2);
            audioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, sampleRate, chCfg,
                    AudioFormat.ENCODING_PCM_16BIT, buf, AudioTrack.MODE_STREAM);
            audioTrack.play();
        } catch (Exception e) {
            audioTrack = null;
            hasAudio = false;
        }
    }

    /* ============================ 视频线程 ============================ */
    private final Runnable videoRun = new Runnable() {
        public void run() {
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            long lastRenderNs = 0;
            while (!released) {
                if (!running) {
                    sleepQuiet(40);
                    lastRenderNs = 0;
                    continue;
                }
                try {
                    /* ---- 输入 ---- */
                    if (!inputEosV) {
                        int in = vDec.dequeueInputBuffer(10000);
                        if (in >= 0) {
                            ByteBuffer buf = getInputBuffer(vDec, in);
                            int sz = vEx.readSampleData(buf, 0);
                            if (sz < 0) {
                                vDec.queueInputBuffer(in, 0, 0, 0,
                                        MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inputEosV = true;
                            } else {
                                long pts = vEx.getSampleTime();
                                int flags = vEx.getSampleFlags();
                                if ((flags & MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
                                    flags = MediaCodec.BUFFER_FLAG_KEY_FRAME;
                                } else {
                                    flags = 0;
                                }
                                vDec.queueInputBuffer(in, 0, sz, pts, flags);
                                vEx.advance();
                            }
                        }
                    }
                    /* ---- 输出 ---- */
                    int out = vDec.dequeueOutputBuffer(info, VIDEO_TIMEOUT);
                    if (out == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        continue;
                    } else if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        MediaFormat f = vDec.getOutputFormat();
                        videoWidth = getInt(f, MediaFormat.KEY_WIDTH);
                        videoHeight = getInt(f, MediaFormat.KEY_HEIGHT);
                        try {
                            int fps = f.getInteger(MediaFormat.KEY_FRAME_RATE);
                            if (fps >= 15 && fps <= 120) {
                                videoFps = fps;
                                minFrameMs = Math.max(0, 1000 / fps - 2);
                            } else {
                                videoFps = 0;
                                minFrameMs = 0;
                            }
                        } catch (Exception ignored) {
                            videoFps = 0;
                            minFrameMs = 0;
                        }
                        if (videoWidth <= 0) {
                            try {
                                videoWidth = getInt(f, "crop-left") + getInt(f, "crop-right");
                            } catch (Exception ignored) {
                            }
                        }
                        continue;
                    } else if (out < 0) {
                        continue;
                    }
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        videoEos = true;
                        releaseOutput(vDec, out, false);
                        checkEnd();
                        continue;
                    }
                    if (info.size > 0) {
                        long ptsUs = info.presentationTimeUs;
                        long nowNs = System.nanoTime();
                        long nowUs = clockUs();
                        // 媒体时间差 → 真实时间差（倍速下真实耗时更短）
                        long delayMs = (ptsUs - nowUs) / 1000;
                        if (speed > 0.01f) {
                            delayMs = (long) (delayMs / speed);
                        }

                        if (delayMs <= -800) {
                            // 严重落后才丢帧，且要连续多次，避免抖动误丢造成跳帧感
                            lateCount++;
                            if (lateCount >= 4) {
                                releaseOutput(vDec, out, false);
                                continue;
                            }
                            releaseOutput(vDec, out, true);
                        } else if (delayMs >= 400) {
                            // pts 异常超前（容器时间戳跳变），重设锚点后立即渲染
                            anchorMediaUs = ptsUs;
                            anchorRealNs = nowNs;
                            lateCount = 0;
                            releaseOutput(vDec, out, true);
                        } else if (delayMs < 2) {
                            // 已到点或轻微落后：立即呈现
                            lateCount = 0;
                            releaseOutput(vDec, out, true);
                        } else {
                            // 正常排队：交给系统按时间戳呈现，避免 sleep 抖动
                            lateCount = 0;
                            releaseOutputAt(vDec, out, nowNs + delayMs * 1000000L);
                        }
                        lastRenderNs = System.nanoTime();
                        if (!firstFrame) {
                            firstFrame = true;
                            postFirstFrame();
                        }
                    } else {
                        releaseOutput(vDec, out, false);
                    }
                } catch (IllegalStateException e) {
                    // 解码器瞬时状态异常（seek/flush 竞态常见）：
                    // 不再对外抛错导致播放退出，短暂等待后继续
                    if (!released) {
                        sleepQuiet(16);
                    }
                } catch (Exception e) {
                    if (!released) {
                        sleepQuiet(16);
                    }
                }
            }
        }
    };

    /* ============================ 音频线程 ============================ */
    private final Runnable audioRun = new Runnable() {
        public void run() {
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (!released) {
                if (!running) {
                    sleepQuiet(30);
                    continue;
                }
                try {
                    if (!inputEosA) {
                        int in = aDec.dequeueInputBuffer(10000);
                        if (in >= 0) {
                            ByteBuffer buf = getInputBuffer(aDec, in);
                            int sz = aEx.readSampleData(buf, 0);
                            if (sz < 0) {
                                aDec.queueInputBuffer(in, 0, 0, 0,
                                        MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inputEosA = true;
                            } else {
                                aDec.queueInputBuffer(in, 0, sz, aEx.getSampleTime(), 0);
                                aEx.advance();
                            }
                        }
                    }
                    int out = aDec.dequeueOutputBuffer(info, 5000);
                    if (out == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        continue;
                    } else if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        MediaFormat f = aDec.getOutputFormat();
                        int sr = getInt(f, MediaFormat.KEY_SAMPLE_RATE);
                        int cc = getInt(f, MediaFormat.KEY_CHANNEL_COUNT);
                        if (sr > 0 && (sr != sampleRate || cc != channelCount)) {
                            sampleRate = sr;
                            if (cc > 0) {
                                channelCount = cc;
                            }
                            try {
                                if (audioTrack != null) {
                                    audioTrack.stop();
                                    audioTrack.release();
                                }
                            } catch (Exception ignored) {
                            }
                            initAudioTrack();
                        }
                        continue;
                    } else if (out < 0) {
                        continue;
                    }
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        audioEos = true;
                        releaseOutput(aDec, out, false);
                        checkEnd();
                        continue;
                    }
                    if (info.size > 0 && audioTrack != null) {
                        ByteBuffer ob = getOutputBuffer(aDec, out);
                        byte[] chunk = new byte[info.size];
                        ob.position(info.offset);
                        ob.get(chunk);
                        // 真正的音频放大：对 PCM 样本做增益并限幅，
                        // AudioTrack 自身增益上限只有 1.0，靠它无法超过原始音量
                        if (boost > 1.001f) {
                            applyGain(chunk, info.size, boost);
                        }
                        if (audioMuted) {
                            // 变速不可用：不写音频设备，视频改走系统时钟。
                            // 放慢空转节奏，把 CPU 留给视频解码
                            audioClockUs = -1;
                            anchorPtsUs = -1;
                            sleepQuiet(8);
                            continue;
                        }
                        long t0 = System.nanoTime();
                        int written = audioTrack.write(chunk, 0, info.size);
                        long costMs = (System.nanoTime() - t0) / 1000000L;
                        if (costMs > 800 || written < 0) {
                            // 写阻塞或失败：音频时钟不可信，改用系统时钟继续播画面
                            audioClockUs = -1;
                            anchorPtsUs = -1;
                        } else {
                            // 建立锚点：这帧数据写完时的累计帧数 ↔ 它的媒体时间
                            int ch = channelCount > 0 ? channelCount : 2;
                            writtenFrames += written / (2 * ch);
                            anchorFrames = writtenFrames;
                            anchorPtsUs = info.presentationTimeUs;
                            audioClockUs = info.presentationTimeUs;
                            audioClockNs = System.nanoTime();
                        }
                    }
                    releaseOutput(aDec, out, false);
                } catch (Exception e) {
                    if (!released) {
                        audioClockUs = -1;
                    }
                    break;
                }
            }
        }
    };

    private void checkEnd() {
        boolean vDone = vDec == null || videoEos;
        boolean aDone = aDec == null || audioEos;
        if (vDone && aDone && cb != null) {
            running = false;
            android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
            h.post(new Runnable() {
                public void run() {
                    if (cb != null) {
                        cb.onCompletion();
                    }
                }
            });
        }
    }

    private void postFirstFrame() {
        android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        h.post(new Runnable() {
            public void run() {
                if (cb != null) {
                    cb.onFirstFrame();
                }
            }
        });
    }

    private void postError(final String msg) {
        android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        h.post(new Runnable() {
            public void run() {
                if (cb != null && !released) {
                    cb.onError(msg);
                }
            }
        });
    }

    /* ============================ 缓冲区兼容 ============================ */
    private ByteBuffer getInputBuffer(MediaCodec c, int idx) {
        if (Build.VERSION.SDK_INT >= 21) {
            return c.getInputBuffer(idx);
        }
        ByteBuffer[] arr = c.getInputBuffers();
        return arr[idx];
    }

    private ByteBuffer getOutputBuffer(MediaCodec c, int idx) {
        if (Build.VERSION.SDK_INT >= 21) {
            return c.getOutputBuffer(idx);
        }
        ByteBuffer[] arr = c.getOutputBuffers();
        return arr[idx];
    }

    /**
     * 按目标呈现时间把帧交给系统合成器。
     * 系统会根据 vsync 精确安排显示时刻，比自己 Thread.sleep 再渲染平滑得多 ——
     * 这是倍速下不再卡顿的关键（sleep 精度差，倍速时误差被放大）。
     */
    private void releaseOutputAt(MediaCodec c, int idx, long renderTimeNs) {
        try {
            if (Build.VERSION.SDK_INT >= 21) {
                c.releaseOutputBuffer(idx, renderTimeNs);
            } else {
                c.releaseOutputBuffer(idx, true);
            }
        } catch (Exception e) {
            // 时间戳渲染不被支持时退回立即渲染，绝不因此中断播放
            try {
                c.releaseOutputBuffer(idx, true);
            } catch (Exception ignored) {
            }
        }
    }

    private void releaseOutput(MediaCodec c, int idx, boolean render) {
        try {
            if (Build.VERSION.SDK_INT >= 21) {
                if (render && surface != null) {
                    c.releaseOutputBuffer(idx, true);
                } else {
                    c.releaseOutputBuffer(idx, false);
                }
            } else {
                if (render && surface != null) {
                    c.releaseOutputBuffer(idx, true);
                } else {
                    c.releaseOutputBuffer(idx, false);
                }
            }
        } catch (Exception ignored) {
        }
    }

    /* ============================ 时钟 ============================ */
    /**
     * 调度时钟：优先用音频时钟（音画同步），但音频时钟超过 400ms 未更新
     * （例如 AudioTrack 写阻塞）时自动降级到系统时钟，避免视频线程一直等待而黑屏卡死。
     */
    private long clockUs() {
        long precise = preciseAudioClockUs();
        if (precise >= 0) {
            return precise;
        }
        // 无音频或音频时钟不可用时，退回系统锚点时钟
        if (anchorRealNs == 0) {
            return anchorMediaUs;
        }
        long elapsedUs = (System.nanoTime() - anchorRealNs) / 1000;
        return anchorMediaUs + (long) (elapsedUs * speed);
    }

    /**
     * 精确音频时钟：媒体位置 = 锚点 pts − 缓冲区里尚未播出的媒体时长。
     *
     * 之前用的是「最后写入的 pts + 经过时间 × 倍速」。这个算法有两个致命缺陷：
     * 1) 写入的数据还排在 AudioTrack 缓冲里没播出去，等于凭空超前了一个缓冲时长；
     * 2) 一旦 AudioTrack 变速实际没生效（很多设备静默失败），音频仍按 1x 播，
     *    而时钟按倍速推进，视频就会疯狂丢帧追赶 → 卡顿 + 音画严重不同步。
     *
     * 现在直接读播放头，天然包含缓冲延迟与实际播放速率，音画才能真正对齐。
     */
    private long preciseAudioClockUs() {
        if (!hasAudio || audioTrack == null || audioMuted || anchorPtsUs < 0) {
            return -1;
        }
        long ageNs = System.nanoTime() - audioClockNs;
        if (ageNs > 1000000000L) {
            return -1;   // 音频停更超过 1 秒，判定不可用
        }
        int head;
        try {
            head = audioTrack.getPlaybackHeadPosition();
        } catch (Exception e) {
            return -1;
        }
        if (head < 0) {
            head = 0;
        }
        if (head < lastHead - 1) {
            // 播放头回退（AudioTrack 被重置），重新对齐锚点
            anchorFrames = writtenFrames;
        }
        lastHead = head;
        long pending = anchorFrames - head;
        if (pending < 0) {
            pending = 0;
        }
        if (pending > sampleRate * 2L) {
            pending = sampleRate * 2L;   // 限幅，异常值不污染时钟
        }
        double sp = speed > 0.01f ? speed : 1f;
        double pendingMediaUs = pending * 1000000.0 / sampleRate / sp;
        long us = anchorPtsUs - (long) pendingMediaUs;
        if (us < 0) {
            us = 0;
        }
        return us;
    }

    /** 音频位置重置（seek / start 时调用），避免旧锚点污染时钟 */
    private void resetAudioClock() {
        writtenFrames = 0;
        anchorFrames = 0;
        anchorPtsUs = -1;
        lastHead = 0;
        audioClockUs = -1;
    }

    private void resumeClock() {
        long cur = position() * 1000L;
        anchorMediaUs = cur;
        anchorRealNs = System.nanoTime();
    }

    /* ============================ 控制 ============================ */
    public void start() {
        if (released) {
            return;
        }
        if (audioTrack != null) {
            try {
                audioTrack.play();
            } catch (Exception ignored) {
            }
        }
        anchorMediaUs = pausedPos > 0 ? pausedPos * 1000L : anchorMediaUs;
        anchorRealNs = System.nanoTime();
        pausedPos = 0;
        running = true;
        videoEos = false;
        audioEos = false;
        notifySync();
    }

    public void pause() {
        pausedPos = position();
        running = false;
        if (audioTrack != null) {
            try {
                audioTrack.pause();
            } catch (Exception ignored) {
            }
        }
    }

    private void notifySync() {
        synchronized (sync) {
            sync.notifyAll();
        }
    }

    public void seekTo(long ms) {
        lateCount = 0;
        lastRenderNs = 0;
        // flush 后解码器参数会被重置，重新告知运行速率，避免倍速下 seek 后卡住
        try {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                public void run() {
                    updateOperatingRate();
                }
            });
        } catch (Exception ignored) {
        }
        long us = ms * 1000L;
        if (durationUs > 0 && us > durationUs) {
            us = durationUs;
        }
        if (us < 0) {
            us = 0;
        }
        long keep = position();
        pausedPos = ms;
        try {
            if (vEx != null) {
                vEx.seekTo(us, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            }
            if (aEx != null) {
                aEx.seekTo(us, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            }
            if (vDec != null) {
                vDec.flush();
            }
            if (aDec != null) {
                aDec.flush();
            }
            if (audioTrack != null) {
                audioTrack.flush();
            }
        } catch (Exception ignored) {
        }
        inputEosV = false;
        inputEosA = false;
        videoEos = false;
        audioEos = false;
        pendingFrames = 0;
        anchorMediaUs = us;
        anchorRealNs = System.nanoTime();
        audioClockUs = -1;
        if (durationUs > 0 && us >= durationUs - 500000) {
            postError("");
        }
    }

    private void seekInternal(long us) {
        try {
            if (vEx != null) {
                vEx.seekTo(us, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            }
            if (aEx != null) {
                aEx.seekTo(us, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            }
        } catch (Exception ignored) {
        }
    }

    public long position() {
        // 与渲染共用同一个精确时钟，播放页显示的进度才不会和画面对不上
        long precise = preciseAudioClockUs();
        if (precise >= 0 && running) {
            if (durationUs > 0 && precise > durationUs) {
                precise = durationUs;
            }
            return precise / 1000;
        }
        if (audioClockUs >= 0 && hasAudio && running) {
            long elapsedNs = System.nanoTime() - audioClockNs;
            long us = audioClockUs + (long) (elapsedNs / 1000.0 * speed);
            if (us < 0) {
                us = 0;
            }
            if (durationUs > 0 && us > durationUs) {
                us = durationUs;
            }
            return us / 1000;
        }
        if (pausedPos > 0 && !running) {
            return pausedPos;
        }
        if (anchorRealNs == 0) {
            return startMs;
        }
        long elapsedUs = (System.nanoTime() - anchorRealNs) / 1000;
        long us = anchorMediaUs + (long) (elapsedUs * speed);
        if (durationUs > 0 && us > durationUs) {
            us = durationUs;
        }
        return us / 1000;
    }

    public long duration() {
        return durationUs / 1000;
    }

    public boolean isPlaying() {
        return running;
    }

    public void setSpeed(float s) {
        if (s <= 0) {
            s = 1f;
        }
        this.speed = s;
        resumeClock();
        // 硬件解码器必须被告知新的运行速率，否则倍速时解码输出跟不上，
        // 表现为画面卡住、音频丢声甚至内核报错退出
        updateOperatingRate();
        updateAudioSpeed();
    }

    /** 动态设置解码器运行速率 = 帧率 × 倍速，让硬件解码器按倍速吐帧 */
    private void updateOperatingRate() {
        if (vDec == null || videoFps <= 0) {
            return;
        }
        if (Build.VERSION.SDK_INT < 23) {
            return;
        }
        try {
            int rate = (int) (videoFps * speed);
            if (rate < 1) {
                rate = 1;
            }
            if (rate > 240) {
                rate = 240;
            }
            Bundle b = new Bundle();
            b.putInt(MediaFormat.KEY_OPERATING_RATE, rate);
            b.putInt(MediaFormat.KEY_PRIORITY, 0);
            vDec.setParameters(b);
        } catch (Exception ignored) {
        }
    }

    /**
     * 倍速时的音频策略：
     * - 0.8x ~ 1.5x：交给 AudioTrack 变速，保持音调不变
     * - 超出该范围：直接静音（不写 AudioTrack），避免硬件变速导致的
     *   卡死、爆音、丢声音。这是主流播放器的通行做法。
     */
    private void updateAudioSpeed() {
        // 大多数设备的 AudioTrack 支持 0.5x~2.0x 变速；超出该范围才静音，
        // 之前 0.8~1.5 收得太紧，导致常用倍速（0.5x / 2x）直接没声音
        boolean mute = speed < 0.5f || speed > 2.0f;
        if (!mute) {
            // 先尝试真正变速；设备不支持则必须静音，
            // 否则音频按 1x 播、视频按倍速播，必然不同步且卡顿
            mute = !applyPlaybackRate(speed);
        }
        if (mute == audioMuted) {
            return;
        }
        audioMuted = mute;
        if (mute) {
            // 丢弃音频输出，视频改用自身锚点时钟
            audioClockUs = -1;
            try {
                if (audioTrack != null) {
                    audioTrack.pause();
                    audioTrack.flush();
                }
            } catch (Exception ignored) {
            }
        } else {
            try {
                if (audioTrack != null) {
                    applyPlaybackRate(speed);
                    audioTrack.play();
                }
            } catch (Exception ignored) {
            }
        }
    }

    /** 设置音频变速，返回是否真正生效（部分设备静默失败，必须探测出来） */
    private boolean applyPlaybackRate(double s) {
        if (audioTrack == null) {
            return false;
        }
        if (Build.VERSION.SDK_INT < 23) {
            return Math.abs(s - 1f) < 0.01f;
        }
        try {
            float want = Math.max(0.1f, (float) (Math.round(s * 100) / 100.0));
            PlaybackParams pp = audioTrack.getPlaybackParams();
            pp.setSpeed(want);
            pp.setPitch(1.0f);
            audioTrack.setPlaybackParams(pp);
            // 读回来验证：不支持变速的设备会保持 1.0，此时必须静音
            PlaybackParams after = audioTrack.getPlaybackParams();
            float got = after.getSpeed();
            audioRateOk = Math.abs(got - want) < 0.05f;
            return audioRateOk;
        } catch (Exception e) {
            audioRateOk = false;
            return false;
        }
    }

    /** 音量放大倍数（1.0 ~ 2.0） */
    private float boost = 1.0f;

    public void setBoost(float b) {
        boost = b;
    }

    /**
     * 对 16bit PCM 数据做增益（放大），并做饱和限幅防止爆音。
     * 这是音量放大能真正生效的关键：AudioTrack 的音量上限只有 1.0，
     * 必须直接放大采样值才能超过视频本身的音量。
     */
    private static void applyGain(byte[] pcm, int len, float gain) {
        if (pcm == null || gain <= 1.0f) {
            return;
        }
        int n = len & ~1;   // 只处理完整的 16bit 样本
        for (int i = 0; i + 1 < n; i += 2) {
            int v = (short) ((pcm[i] & 0xFF) | (pcm[i + 1] << 8));
            long g = Math.round(v * gain);
            if (g > 32767L) {
                g = 32767L;
            } else if (g < -32768L) {
                g = -32768L;
            }
            int sv = (int) g;
            pcm[i] = (byte) (sv & 0xFF);
            pcm[i + 1] = (byte) ((sv >> 8) & 0xFF);
        }
    }

    public void setVolume(float left, float right) {
        if (audioTrack != null && Build.VERSION.SDK_INT >= 21) {
            try {
                // 放大由 PCM 增益完成，这里只应用用户设置的音量（最大 1.0）
                float v = (left + right) / 2f;
                if (v < 0f) {
                    v = 0f;
                }
                if (v > 1f) {
                    v = 1f;
                }
                audioTrack.setVolume(v);
            } catch (Exception ignored) {
            }
        }
    }

    public int buffered() {
        return 100;
    }

    public List<TrackInfo> tracks() {
        return trackList;
    }

    public void selectTrack(int index) {
        boolean audio = false;
        for (TrackInfo t : trackList) {
            if (t.index == index) {
                audio = (t.type == 1);
            }
        }
        if (!audio) {
            return;
        }
        boolean wasPlaying = running;
        long pos = position();
        running = false;
        sleepQuiet(80);
        try {
            if (aDec != null) {
                aDec.stop();
                aDec.release();
            }
        } catch (Exception ignored) {
        }
        try {
            if (aEx != null) {
                aEx.release();
            }
        } catch (Exception ignored) {
        }
        try {
            if (audioTrack != null) {
                audioTrack.stop();
                audioTrack.release();
            }
        } catch (Exception ignored) {
        }
        aDec = null;
        aEx = null;
        audioTrack = null;
        aIndex = index;
        inputEosA = false;
        audioEos = false;
        try {
            aEx = createExtractor();
            aEx.selectTrack(aIndex);
            MediaFormat af = aEx.getTrackFormat(aIndex);
            sampleRate = getInt(af, MediaFormat.KEY_SAMPLE_RATE);
            channelCount = getInt(af, MediaFormat.KEY_CHANNEL_COUNT);
            if (sampleRate <= 0) {
                sampleRate = 44100;
            }
            if (channelCount <= 0) {
                channelCount = 2;
            }
            aDec = createDecoder(af, true);
            initAudioTrack();
            hasAudio = aDec != null && audioTrack != null;
            seekInternal(pos * 1000L);
            anchorMediaUs = pos * 1000L;
            anchorRealNs = System.nanoTime();
            audioClockUs = -1;
            inputEosA = false;
            audioEos = false;
            if (aDec != null) {
                aThread = new Thread(audioRun, "shichen-audio2");
                aThread.setPriority(Thread.MAX_PRIORITY);
                aThread.start();
            }
            for (TrackInfo t : trackList) {
                if (t.type == 1) {
                    t.selected = (t.index == aIndex);
                }
            }
        } catch (Exception ignored) {
            hasAudio = false;
        }
        if (wasPlaying) {
            start();
        } else {
            pausedPos = pos;
        }
    }

    public void release() {
        released = true;
        running = false;
        notifySync();
        try {
            if (vThread != null) {
                vThread.join(250);
            }
            if (aThread != null) {
                aThread.join(250);
            }
        } catch (Exception ignored) {
        }
        try {
            if (vDec != null) {
                vDec.stop();
                vDec.release();
            }
        } catch (Exception ignored) {
        }
        try {
            if (aDec != null) {
                aDec.stop();
                aDec.release();
            }
        } catch (Exception ignored) {
        }
        try {
            if (vEx != null) {
                vEx.release();
            }
        } catch (Exception ignored) {
        }
        try {
            if (aEx != null) {
                aEx.release();
            }
        } catch (Exception ignored) {
        }
        try {
            if (audioTrack != null) {
                audioTrack.stop();
                audioTrack.release();
            }
        } catch (Exception ignored) {
        }
        vDec = null;
        aDec = null;
        vEx = null;
        aEx = null;
        audioTrack = null;
        vThread = null;
        aThread = null;
    }

    public String engineName() {
        return "自研 MediaCodec 内核";
    }

    public int audioSessionId() {
        if (audioTrack != null) {
            try {
                return audioTrack.getAudioSessionId();
            } catch (Exception ignored) {
            }
        }
        return 0;
    }

    public int getRotation() {
        return rotation;
    }

    private static void sleepQuiet(long ms) {
        if (ms <= 0) {
            return;
        }
        try {
            Thread.sleep(ms);
        } catch (Exception ignored) {
        }
    }

    @SuppressWarnings("unused")
    private static long elapsedRealtime() {
        return SystemClock.elapsedRealtime();
    }
}
