package com.shichen.player;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.media.AudioManager;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** 播放界面内的可调设置面板（半透明、限高） */
public class PlaySettingsPanel {

    public interface PlayControl {
        float speed();

        void applySpeed(float s);

        int ratio();

        void applyRatio(int r);

        void applyOrientation(int o);

        float zoom();

        void applyZoom(float z);

        void reloadEngine();

        void openTracks();

        void openSubtitleMenu();

        void applySubtitleStyle();

        void openEqualizer();

        float brightness();

        void applyBrightness(float b);

        float volume();

        void applyVolume(float v);

        void applyHq(boolean on);

        void applyStatus();

        void applyBoost(float b);

        void refreshPanelBg();

        Activity activity();
    }

    private final PlayControl ctl;
    private final Activity act;
    private final int accent;

    /* ---- 分类导航 ---- */
    private final List<String> navNames = new ArrayList<String>();
    private final List<LinearLayout> groups = new ArrayList<LinearLayout>();
    private LinearLayout content;
    private LinearLayout cur;
    private int navIndex = -1;

    public PlaySettingsPanel(PlayControl c) {
        ctl = c;
        act = c.activity();
        accent = ThemeEngine.accent(act);
    }

    public View build() {
        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        int d = (int) act.getResources().getDisplayMetrics().density;
        root.setPadding(6 * d, 2 * d, 6 * d, 4 * d);

        content = new LinearLayout(act);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        navNames.clear();
        groups.clear();
        cur = null;

        /* ---------- 播放 ---------- */
        /* ---------- 快捷（最常用，置顶可见） ---------- */
        String[] o = null;
        section("播放");
        final float[] speeds = {0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 2.5f, 3.0f, 4.0f};
        add(chips(MediaUtils.formatSpeedArray(speeds), indexOfSpeed(speeds, ctl.speed()),
                new OnChip() {
                    public void onPick(int i) {
                        ctl.applySpeed(speeds[i]);
                    }
                }));
        add(rowValue("循环模式", SettingsPage.repeatName(Prefs.repeatMode(act)),
                new View.OnClickListener() {
                    public void onClick(View v) {
                        String[] o = {"不循环", "列表循环", "单曲循环"};
                        Ui.sheet(act, "循环模式", o, Prefs.repeatMode(act), new Ui.OnPick() {
                            public void onPick(int i) {
                                Prefs.setRepeatMode(act, i);
                            }
                        });
                    }
                }));
        add(rowValue("快进/快退秒数", Prefs.skipSec(act) + " 秒", new View.OnClickListener() {
            public void onClick(View v) {
                String[] o = {"5 秒", "10 秒", "15 秒", "30 秒", "60 秒"};
                final int[] vals = {5, 10, 15, 30, 60};
                Ui.sheet(act, "快进/快退秒数", o, indexOf(vals, Prefs.skipSec(act)), new Ui.OnPick() {
                    public void onPick(int i) {
                        Prefs.setSkipSec(act, vals[i]);
                    }
                });
            }
        }));
        add(rowValue("播放列表", "查看并跳转", new View.OnClickListener() {
            public void onClick(View v) {
                ((PlayerActivity) act).showPlaylist();
            }
        }));
        add(switchRow("自动连播", Prefs.autoNext(act), new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setAutoNext(act, v);
            }
        }));
        add(switchRow("记住上次倍速", Prefs.rememberSpeed(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setRememberSpeed(act, v);
                    }
                }));
        add(switchRow("记住播放进度", Prefs.rememberPos(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setRememberPos(act, v);
                    }
                }));
        add(subTitle("— 画面 —"));
        String[] ratios = {"适应屏幕", "16:9", "4:3", "铺满(拉伸)", "原始尺寸",
                "裁剪填充", "1:1", "21:9"};
        add(chips(ratios, ctl.ratio(), new OnChip() {
            public void onPick(int i) {
                ctl.applyRatio(i);
            }
        }));
        add(rowValue("屏幕方向", SettingsPage.oriName(Prefs.orientation(act)),
                new View.OnClickListener() {
                    public void onClick(View v) {
                        String[] o = {"跟随视频", "自动旋转", "强制横屏", "强制竖屏", "跟随系统"};
                        Ui.sheet(act, "屏幕方向", o, Prefs.orientation(act), new Ui.OnPick() {
                            public void onPick(int i) {
                                Prefs.setOrientation(act, i);
                                ctl.applyOrientation(i);
                            }
                        });
                    }
                }));
        add(sliderRow("画面缩放", (int) (ctl.zoom() * 50), 50, 300,
                new OnSlide() {
                    public void onSlide(int v) {
                        ctl.applyZoom(v / 100f);
                    }
                }, new Fmt() {
                    public String fmt(int v) {
                        return (v / 100f) + "x";
                    }
                }));
        add(sliderRow("亮度", (int) (ctl.brightness() * 100), 0, 100, new OnSlide() {
            public void onSlide(int v) {
                ctl.applyBrightness(v / 100f);
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + "%";
            }
        }));
        add(switchRow("屏幕常亮", Prefs.keepScreenOn(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setKeepScreenOn(act, v);
                        if (v) {
                            act.getWindow().addFlags(
                                    android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        } else {
                            act.getWindow().clearFlags(
                                    android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        }
                    }
                }));
        add(sliderRow("播放结束时亮度恢复", Prefs.restoreBright(act), 0, 100,
                new OnSlide() {
            public void onSlide(int v) {
                Prefs.setRestoreBright(act, v);
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + "%";
            }
        }));
        add(subTitle("— 手势 —"));
        add(sliderRow("长按倍速", (int) (Prefs.longPressSpeed(act) * 100), 100, 400,
                new OnSlide() {
                    public void onSlide(int v) {
                        Prefs.setLongPressSpeed(act, v / 100f);
                    }
                }, new Fmt() {
                    public String fmt(int v) {
                        return (v / 100f) + "x";
                    }
                }));
        add(sliderRow("滑动灵敏度", Prefs.seekSensitivity(act), 30, 300, new OnSlide() {
            public void onSlide(int v) {
                Prefs.setSeekSensitivity(act, v);
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + " 秒";
            }
        }));
        add(subTitle("— 锁定后可用手势 —"));
        add(switchRow("双击暂停", Prefs.lockDoubleTap(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setLockDoubleTap(act, v);
                    }
                }));
        add(switchRow("长按加速", Prefs.lockLongPress(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setLockLongPress(act, v);
                    }
                }));
        add(switchRow("滑动快进", Prefs.lockSeek(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setLockSeek(act, v);
                    }
                }));
        add(switchRow("滑动调亮度", Prefs.lockBrightness(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setLockBrightness(act, v);
                    }
                }));
        add(switchRow("滑动调音量", Prefs.lockVolume(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setLockVolume(act, v);
                    }
                }));
        add(switchRow("双指缩放", Prefs.lockZoom(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setLockZoom(act, v);
                    }
                }));
        section("声音");
        add(sliderRow("音量", (int) (ctl.volume() * 100), 0, 100, new OnSlide() {
            public void onSlide(int v) {
                ctl.applyVolume(v / 100f);
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + "%";
            }
        }));
        add(rowValue("选择轨道", "音轨 / 字幕轨", new View.OnClickListener() {
            public void onClick(View v) {
                ctl.openTracks();
            }
        }));
        add(sliderRow("音画同步（音频延迟）", Prefs.audioDelay(act) + 1000, -1000, 1000,
                new OnSlide() {
            public void onSlide(int v) {
                Prefs.setAudioDelay(act, v - 1000);
                Ui.toast(act, "音频延迟 " + (v - 1000) + " ms");
            }
        }, new Fmt() {
            public String fmt(int v) {
                return (v - 1000) + " ms";
            }
        }));
        add(rowValue("音量放大", Prefs.boostVolume(act) + "%",
                new View.OnClickListener() {
            public void onClick(View v) {
                String[] o = {"100%（原始）", "120%", "140%", "160%", "180%", "200%"};
                final int[] vals = {100, 120, 140, 160, 180, 200};
                int cur = 0;
                for (int i = 0; i < vals.length; i++) {
                    if (vals[i] == Prefs.boostVolume(act)) {
                        cur = i;
                    }
                }
                Ui.sheet(act, "音量放大", o, cur, new Ui.OnPick() {
                    public void onPick(int i) {
                        Prefs.setBoostVolume(act, vals[i]);
                        ctl.reloadEngine();
                    }
                });
            }
        }));
        section("字幕");
        add(rowValue("字幕设置", "开关 / 大小 / 延迟", new View.OnClickListener() {
            public void onClick(View v) {
                ctl.openSubtitleMenu();
            }
        }));
        add(sliderRow("字幕字号", Prefs.subtitleSize(act), 10, 32, new OnSlide() {
            public void onSlide(int v) {
                Prefs.setSubtitleSize(act, v);
                ctl.applySubtitleStyle();
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + " sp";
            }
        }));
        add(sliderRow("字幕延迟", (Prefs.subtitleDelay(act) + 3000) / 10, 0, 600,
                new OnSlide() {
                    public void onSlide(int v) {
                        Prefs.setSubtitleDelay(act, v * 10 - 3000);
                        ctl.applySubtitleStyle();
                    }
                }, new Fmt() {
                    public String fmt(int v) {
                        return (v * 10 - 3000) + " ms";
                    }
                }));
            String[] osc = {"白", "黄", "青", "绿", "粉"};
            o = osc;
            add(chips(o, Prefs.subtitleColor(act), new OnChip() {
                public void onPick(int i) {
                    Prefs.setSubtitleColor(act, i);
                    ctl.applySubtitleStyle();
                }
            }));
        add(sliderRow("字幕描边粗细", Prefs.subtitleOutline(act), 0, 6,
                new OnSlide() {
            public void onSlide(int v) {
                Prefs.setSubtitleOutline(act, v);
                ctl.applySubtitleStyle();
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v == 0 ? "无" : v + " px";
            }
        }));
        add(sliderRow("字幕底部边距", Prefs.subtitleBottom(act), 0, 120,
                new OnSlide() {
            public void onSlide(int v) {
                Prefs.setSubtitleBottom(act, v);
                ctl.applySubtitleStyle();
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + " dp";
            }
        }));
        section("解码");
            String[] odc = {"系统内核", "时尘硬件解码", "时尘软件解码", "自动"};
            o = odc;
            add(chips(o, Prefs.decodeMode(act), new OnChip() {
                public void onPick(int i) {
                    Prefs.setDecodeMode(act, i);
                    ctl.reloadEngine();
                }
            }));
        add(rowValue("渲染模式",
                Prefs.renderKind(act) == VideoRenderView.KIND_TEXTURE ? "高级" : "兼容",
                new View.OnClickListener() {
            public void onClick(View v) {
                String[] o = {"兼容模式（最稳定）", "高级模式（支持缩放裁剪）"};
                Ui.sheet(act, "渲染模式", o, Prefs.renderKind(act), new Ui.OnPick() {
                    public void onPick(int i) {
                        Prefs.setRenderKind(act, i);
                        ctl.reloadEngine();
                    }
                });
            }
        }));
        add(switchRow("解码失败自动回退", Prefs.fallback(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setFallback(act, v);
                    }
                }));
        section("界面");
        add(switchRow("顶部状态显示（时长 / 电量）", Prefs.statusOverlay(act),
                new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setStatusOverlay(act, v);
                ctl.applyStatus();
            }
        }));
            o = new String[]{"当前/总时长", "总时长", "剩余时长"};
            add(chips(o, Prefs.statusLeftMode(act), new OnChip() {
                public void onPick(int i) {
                    Prefs.setStatusLeftMode(act, i);
                    ctl.applyStatus();
                }
            }));
            o = new String[]{"电量+时间", "仅电量", "仅时间"};
            add(chips(o, Prefs.statusRightMode(act), new OnChip() {
                public void onPick(int i) {
                    Prefs.setStatusRightMode(act, i);
                    ctl.applyStatus();
                }
            }));
        add(sliderRow("左右同步内缩（刘海/圆角补偿）", Prefs.statusInsetX(act), 0, 200,
                new OnSlide() {
            public void onSlide(int v) {
                Prefs.setStatusInsetX(act, v);
                ctl.applyStatus();
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + " dp";
            }
        }));
        add(sliderRow("距顶部偏移", Prefs.statusInsetY(act), 0, 200, new OnSlide() {
            public void onSlide(int v) {
                Prefs.setStatusInsetY(act, v);
                ctl.applyStatus();
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + " dp";
            }
        }));
        add(sliderRow("播放界面弹窗透明度", Prefs.panelAlphaKind(act, "player"), 0, 100,
                new OnSlide() {
            public void onSlide(int v) {
                Prefs.setPanelAlphaKind(act, "player", v);
                Ui.refreshPanelAlpha(act);
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + "%";
            }
        }));
        add(sliderRow("倍速面板透明度", Prefs.panelAlphaKind(act, "speed"), 0, 100,
                new OnSlide() {
            public void onSlide(int v) {
                Prefs.setPanelAlphaKind(act, "speed", v);
                Ui.refreshPanelAlpha(act);
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + "%";
            }
        }));
        add(sliderRow("播放列表透明度", Prefs.panelAlphaKind(act, "playlist"), 0, 100,
                new OnSlide() {
            public void onSlide(int v) {
                Prefs.setPanelAlphaKind(act, "playlist", v);
                Ui.refreshPanelAlpha(act);
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + "%";
            }
        }));
        add(sliderRow("控制条自动隐藏秒数", Prefs.autoHideSec(act), 2, 15,
                new OnSlide() {
            public void onSlide(int v) {
                Prefs.setAutoHideSec(act, v);
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + " 秒";
            }
        }));
        add(sliderRow("进度条拖动预览缩略图大小", Prefs.previewScale(act), 50, 150,
                new OnSlide() {
            public void onSlide(int v) {
                Prefs.setPreviewScale(act, v);
            }
        }, new Fmt() {
            public String fmt(int v) {
                return v + "%";
            }
        }));
        add(switchRow("拖动时保持预览可见", Prefs.previewSticky(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setPreviewSticky(act, v);
                    }
                }));
        section("高级");
        add(switchRow("播放完成自动退出", Prefs.exitOnFinish(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setExitOnFinish(act, v);
                    }
                }));
        add(switchRow("列表自动定位当前播放项", Prefs.autoScrollList(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setAutoScrollList(act, v);
                    }
                }));
        add(switchRow("后台播放", Prefs.backgroundPlay(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setBackgroundPlay(act, v);
                    }
                }));
        add(switchRow("耳机拔出暂停", Prefs.headphonePause(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setHeadphonePause(act, v);
                    }
                }));
        add(switchRow("显示调试信息", Prefs.showDebug(act),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        Prefs.setShowDebug(act, v);
                    }
                }));

        // 顶部导航 + 分组内容
        root.addView(buildNav());
        for (int i = 0; i < groups.size(); i++) {
            content.addView(groups.get(i));
        }
        root.addView(content);
        // 初始应用一次选中态
        navIndex = 0;
        for (int i = 0; i < groups.size(); i++) {
            groups.get(i).setVisibility(View.VISIBLE);
        }
        ScrollView sv = new ScrollView(act);
        sv.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        sv.setFillViewport(false);
        sv.addView(root);
        return sv;
    }

    public interface OnChip {
        void onPick(int index);
    }

    public interface OnSlide {
        void onSlide(int value);
    }

    public interface Fmt {
        String fmt(int value);
    }

    private static int indexOfSpeed(float[] vals, float v) {
        for (int i = 0; i < vals.length; i++) {
            if (Math.abs(vals[i] - v) < 0.01f) {
                return i;
            }
        }
        return 3;
    }

    private static int indexOf(int[] vals, int v) {
        for (int i = 0; i < vals.length; i++) {
            if (vals[i] == v) {
                return i;
            }
        }
        return 0;
    }

    /** 分组内的小节标题（不参与导航，仅做视觉分隔） */
    private View subTitle(String t) {
        TextView v = new TextView(act);
        v.setText(t);
        v.setTextSize(12f);
        v.setTextColor(0xAAFFFFFF);
        v.setPadding(10 * (int) act.getResources().getDisplayMetrics().density,
                10 * (int) act.getResources().getDisplayMetrics().density,
                6 * (int) act.getResources().getDisplayMetrics().density,
                4 * (int) act.getResources().getDisplayMetrics().density);
        return v;
    }

    /** 新建分组：标题 + 独立容器，供顶部导航切换 */
    private View section(String title) {
        LinearLayout g = new LinearLayout(act);
        g.setOrientation(LinearLayout.VERTICAL);
        g.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        int sd = (int) act.getResources().getDisplayMetrics().density;
        TextView t = new TextView(act);
        t.setText(title);
        t.setTextSize(12.5f);
        t.setTextColor(ThemeEngine.accent(act));
        t.setPadding(10 * sd, 12 * sd, 6 * sd, 6 * sd);
        g.addView(t);
        navNames.add(title);
        groups.add(g);
        cur = g;
        return g;
    }

    /** 向当前分组添加一行 */
    private void add(View v) {
        if (cur != null) {
            cur.addView(v);
        } else if (content != null) {
            content.addView(v);
        }
    }

    /** 构建顶部导航栏 */
    private View buildNav() {
        android.widget.HorizontalScrollView hs =
                new android.widget.HorizontalScrollView(act);
        hs.setHorizontalScrollBarEnabled(false);
        int sd = (int) act.getResources().getDisplayMetrics().density;
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(6 * sd, 6 * sd, 6 * sd, 6 * sd);
        final List<TextView> chips = new ArrayList<TextView>();
        // "全部" 在最前
        final List<String> names = new ArrayList<String>();
        names.add("全部");
        names.addAll(navNames);
        for (int i = 0; i < names.size(); i++) {
            final int idx = i;
            TextView t = new TextView(act);
            t.setText(names.get(i));
            t.setTextSize(12.5f);
            t.setGravity(Gravity.CENTER);
            t.setPadding(14 * sd, 7 * sd, 14 * sd, 7 * sd);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (i > 0) {
                lp.leftMargin = 6 * sd;
            }
            t.setLayoutParams(lp);
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    navIndex = idx;
                    applyNav(chips);
                }
            });
            row.addView(t);
            chips.add(t);
        }
        hs.addView(row);
        // 默认选中"全部"并应用一次高亮
        navIndex = 0;
        applyNav(chips);
        return hs;
    }

    private void applyNav(List<TextView> chips) {
        for (int i = 0; i < chips.size(); i++) {
            TextView t = chips.get(i);
            boolean on = (i == navIndex);
            t.setTextColor(on ? Color.WHITE : 0xFFB8B8C8);
            t.setBackgroundResource(on ? R.drawable.bg_panel_btn_sel
                    : R.drawable.bg_panel_btn);
        }
        for (int i = 0; i < groups.size(); i++) {
            // navIndex 0 = 全部；其余对应 groups[i]
            groups.get(i).setVisibility(
                    navIndex == 0 || navIndex == i + 1 ? View.VISIBLE : View.GONE);
        }
    }


    private View chips(String[] names, int selected, final OnChip cb) {
        final FlowLayout fl = new FlowLayout(act);
        int sd = (int) act.getResources().getDisplayMetrics().density;
        fl.setGaps(8 * sd, 8 * sd);
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            final boolean on = i == selected;
            TextView t = new TextView(act);
            t.setText(names[i]);
            t.setTextSize(12.5f);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(on ? Color.WHITE : 0xFFDCDCE6);
            t.setBackgroundResource(on ? R.drawable.bg_panel_btn_sel : R.drawable.bg_panel_btn);
            t.setPadding(14 * sd, 8 * sd, 14 * sd, 8 * sd);
            t.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    repaintChips(fl, idx);
                    cb.onPick(idx);
                }
            });
            fl.addView(t);
        }
        return fl;
    }

    private void repaintChips(FlowLayout fl, int sel) {
        for (int i = 0; i < fl.getChildCount(); i++) {
            View v = fl.getChildAt(i);
            if (v instanceof TextView) {
                TextView t = (TextView) v;
                boolean on = (i == sel);
                t.setBackgroundResource(on ? R.drawable.bg_panel_btn_sel : R.drawable.bg_panel_btn);
                t.setTextColor(on ? Color.WHITE : 0xFFDCDCE6);
            }
        }
    }

    private View rowValue(String title, String value, View.OnClickListener l) {
        LinearLayout ll = new LinearLayout(act);
        ll.setOrientation(LinearLayout.HORIZONTAL);
        ll.setGravity(Gravity.CENTER_VERTICAL);
        int d = (int) act.getResources().getDisplayMetrics().density;
        ll.setPadding(10 * d, 11 * d, 10 * d, 11 * d);
        ll.setBackgroundResource(R.drawable.bg_panel_row);
        TextView a = new TextView(act);
        a.setText(title);
        a.setTextSize(13.5f);
        a.setTextColor(0xFFF0F0F5);
        a.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView b = new TextView(act);
        b.setText(value);
        b.setTextSize(12.5f);
        b.setTextColor(accent);
        ll.addView(a);
        ll.addView(b);
        ll.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 6 * d;
        ll.setLayoutParams(lp);
        return ll;
    }

    private View switchRow(String title, boolean on, CompoundButton.OnCheckedChangeListener l) {
        LinearLayout ll = new LinearLayout(act);
        ll.setOrientation(LinearLayout.HORIZONTAL);
        ll.setGravity(Gravity.CENTER_VERTICAL);
        int d = (int) act.getResources().getDisplayMetrics().density;
        ll.setPadding(10 * d, 8 * d, 8 * d, 8 * d);
        ll.setBackgroundResource(R.drawable.bg_panel_row);
        TextView a = new TextView(act);
        a.setText(title);
        a.setTextSize(13.5f);
        a.setTextColor(0xFFF0F0F5);
        a.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Switch sw = new Switch(act);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener(l);
        ll.addView(a);
        ll.addView(sw);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 6 * d;
        ll.setLayoutParams(lp);
        return ll;
    }

    private View sliderRow(String title, int value, final int min, int max,
                           final OnSlide cb, final Fmt fmt) {
        LinearLayout ll = new LinearLayout(act);
        ll.setOrientation(LinearLayout.VERTICAL);
        int d = (int) act.getResources().getDisplayMetrics().density;
        ll.setPadding(10 * d, 8 * d, 10 * d, 6 * d);
        ll.setBackgroundResource(R.drawable.bg_panel_row);

        LinearLayout top = new LinearLayout(act);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView a = new TextView(act);
        a.setText(title);
        a.setTextSize(13.5f);
        a.setTextColor(0xFFF0F0F5);
        a.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView b = new TextView(act);
        b.setText(fmt.fmt(value));
        b.setTextSize(12.5f);
        b.setTextColor(accent);
        top.addView(a);
        top.addView(b);
        ll.addView(top);

        SeekBar sb = new SeekBar(act);
        sb.setMax(max - min);
        sb.setProgress(Math.max(0, Math.min(max - min, value - min)));
        sb.setProgressDrawable(act.getResources().getDrawable(R.drawable.progress_player));
        sb.setThumb(act.getResources().getDrawable(R.drawable.thumb_seek));
        sb.setSplitTrack(false);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) {
                    b.setText(fmt.fmt(p + min));
                }
            }

            public void onStartTrackingTouch(SeekBar s) {
            }

            public void onStopTrackingTouch(SeekBar s) {
                cb.onSlide(s.getProgress() + min);
            }
        });

        ll.addView(sb);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 6 * d;
        ll.setLayoutParams(lp);
        return ll;
    }
}
