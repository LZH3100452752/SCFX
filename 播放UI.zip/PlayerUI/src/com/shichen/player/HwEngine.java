package com.shichen.player;

import android.content.Context;
import android.view.Surface;

import com.hwdecoder.DecoderConfig;
import com.hwdecoder.HWDecoder;
import com.hwdecoder.HWDecoderListener;
import com.hwdecoder.MediaClock;
import com.hwdecoder.PlayerState;

import java.util.ArrayList;
import java.util.List;

/**
 * 适配层：把 com.hwdecoder.HWDecoder 接到本项目既有的 PlayerEngine 接口上。
 *
 * 单位换算：本项目 PlayerEngine 一律用毫秒，HWDecoder 内部一律用微秒。
 * 本类负责两者之间的转换，播放页无需改动。
 *
 * 也负责把音量放大（1.0~8.0）、倍速（0.25~8.0）映射到解码器能力上。
 */
public class HwEngine implements PlayerEngine {

    /** true = 强制纯硬件解码（不回退软解）；false = 允许软解回退 */
    private final boolean hardwareOnly;
    /** true = 优先软件解码（兼容性优先） */
    private final boolean preferSoftware;

    private final Context appCtx;
    private HWDecoder decoder;
    private Callback cb;
    private Surface surface;

    private long durationMs = 0;
    private long seekTargetMs = -1;
    private boolean prepared = false;
    private boolean firstFrame = false;
    private boolean released = false;
    private float speed = 1.0f;
    private float volumeBoost = 1.0f;
    private float systemVolume = 1.0f;
    private long pendingStartMs = 0;
    private String lastError = null;
    private int pendingTrack = -1;

    public HwEngine(Context c, boolean hardwareOnly, boolean preferSoftware) {
        appCtx = c.getApplicationContext();
        this.hardwareOnly = hardwareOnly;
        this.preferSoftware = preferSoftware;
    }

    @Override
    public void setCallback(Callback cb) {
        this.cb = cb;
    }

    @Override
    public void setSurface(Surface s) {
        surface = s;
        if (decoder != null && s != null) {
            try {
                decoder.setSurface(s);
            } catch (Throwable ignored) {
            }
        }
    }

    @Override
    public void prepare(Context c, String path, long startMs) {
        released = false;
        prepared = false;
        firstFrame = false;
        durationMs = 0;
        lastError = null;
        pendingStartMs = startMs;
        seekTargetMs = startMs > 0 ? startMs : -1;

        // 必须先释放旧实例：否则它的异步回调会在新实例之后继续抛错误
        // （典型现象：画面已经出来了，随后又弹出一条解码错误）
        if (decoder != null) {
            try {
                decoder.setListener(null);
                decoder.release();
            } catch (Throwable ignored) {
            }
            decoder = null;
        }

        decoder = new HWDecoder(appCtx);
        decoder.setListener(new HWDecoderListener() {
            @Override
            public void onPrepared(int width, int height, long durationUs) {
                durationMs = durationUs / 1000L;
                prepared = true;
                // 尺寸为 0 时从轨道信息兜底，避免播放页按 0x0 计算比例导致画面异常
                if (width <= 0 || height <= 0) {
                    try {
                        java.util.List<com.hwdecoder.TrackInfo> tl = decoder.getTrackList();
                        if (tl != null) {
                            for (com.hwdecoder.TrackInfo t : tl) {
                                if (t.type == com.hwdecoder.TrackInfo.TYPE_VIDEO
                                        && t.width > 0 && t.height > 0) {
                                    width = t.width;
                                    height = t.height;
                                    break;
                                }
                            }
                        }
                    } catch (Throwable ignored) {
                    }
                }
                if (pendingStartMs > 0) {
                    try {
                        decoder.seekTo(pendingStartMs * 1000L);
                    } catch (Throwable ignored) {
                    }
                }
                if (cb != null) {
                    cb.onPrepared(width, height, durationMs);
                }
            }

            @Override
            public void onVideoSizeChanged(int width, int height) {
                if (cb != null && prepared) {
                    cb.onPrepared(width, height, durationMs);
                }
            }

            @Override
            public void onProgress(long positionUs, long durationUs) {
                if (durationUs > 0) {
                    durationMs = durationUs / 1000L;
                }
                if (!firstFrame) {
                    firstFrame = true;
                    if (cb != null) {
                        cb.onFirstFrame();
                    }
                }
                // seek 到位后清掉保护标记
                if (seekTargetMs >= 0
                        && Math.abs(positionUs / 1000L - seekTargetMs) < 1200) {
                    seekTargetMs = -1;
                }
            }

            @Override
            public void onCompletion() {
                if (cb != null) {
                    cb.onCompletion();
                }
            }

            @Override
            public void onError(int errorCode, String message) {
                lastError = message;
                boolean noSurface = (surface == null);
                Diagnostics.log("hwdecoder",
                        "error code=" + errorCode + " msg=" + message
                        + " surface=" + (noSurface ? "NULL" : "ok")
                        + " hwOnly=" + hardwareOnly);
                if (noSurface && !released) {
                    // 渲染表面已销毁（切后台/悬浮窗切换/页面重建）导致的失败不是致命解码错误，
                    // 不弹错误框，等 surface 恢复后由播放页重新 open
                    Diagnostics.log("hwdecoder", "ignore error: surface lost, wait re-open");
                    return;
                }
                if (cb != null) {
                    cb.onError("解码错误：" + message);
                }
            }

            @Override
            public void onStateChanged(PlayerState state) {
                if (state == PlayerState.PLAYING && !firstFrame) {
                    firstFrame = true;
                    if (cb != null) {
                        cb.onFirstFrame();
                    }
                }
                if (state == PlayerState.PREPARED || state == PlayerState.PLAYING) {
                    if (pendingTrack >= 0) {
                        pendingTrack = -1;
                    }
                }
            }
        });

        DecoderConfig cfg = DecoderConfig.builder()
                .source(path)
                .surface(surface)
                .volume(volumeBoost)
                .speed(speed)
                .autoPlay(false)                 // 由播放页统一控制起播
                .hardwareOnly(hardwareOnly)
                .softwareFallback(!hardwareOnly) // 硬解模式下禁止软解回退
                .preferSoftware(preferSoftware)
                .pitchPreserve(true)             // 变速不变调
                .bigCoreBinding(false)           // 默认关闭，避免个别设备异常
                .pauseOnBecomingNoisy(false)     // 播放页自己管理耳机拔出
                .build();
        Diagnostics.log("hwdecoder", "prepare path=" + path
                + " surface=" + (surface == null ? "NULL" : "ok")
                + " hwOnly=" + hardwareOnly + " swFirst=" + preferSoftware);
        try {
            decoder.setDataSource(cfg);
            decoder.prepareAsync();
        } catch (Throwable t) {
            Diagnostics.log("hwdecoder", "prepare failed: " + t);
            if (cb != null) {
                cb.onError("解码器启动失败");
            }
        }
    }

    @Override
    public void start() {
        if (decoder != null) {
            try {
                decoder.start();
                if (systemVolume < 1.0f) {
                    decoder.setVolume(volumeBoost * systemVolume);
                }
            } catch (Throwable ignored) {
            }
        }
    }

    @Override
    public void pause() {
        if (decoder != null) {
            try {
                decoder.pause();
            } catch (Throwable ignored) {
            }
        }
    }

    @Override
    public void seekTo(long ms) {
        if (decoder == null) {
            pendingStartMs = ms;
            return;
        }
        if (ms < 0) {
            ms = 0;
        }
        seekTargetMs = ms;
        try {
            decoder.seekTo(ms * 1000L);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public long position() {
        if (decoder == null) {
            return pendingStartMs;
        }
        try {
            long us = decoder.getPositionUs();
            if (seekTargetMs >= 0) {
                // seek 是异步的：目标未到达前返回目标值，避免进度条回弹
                long cur = us / 1000L;
                if (Math.abs(cur - seekTargetMs) > 1200) {
                    return seekTargetMs;
                }
                seekTargetMs = -1;
            }
            return us / 1000L;
        } catch (Throwable ignored) {
            return 0;
        }
    }

    @Override
    public long duration() {
        return durationMs;
    }

    @Override
    public boolean isPlaying() {
        try {
            return decoder != null && decoder.isPlaying();
        } catch (Throwable ignored) {
            return false;
        }
    }

    @Override
    public void setSpeed(float speed) {
        this.speed = speed;
        if (decoder != null) {
            try {
                decoder.setSpeed(speed);
            } catch (Throwable ignored) {
            }
        }
    }

    /**
     * 音量：v 为系统音量（0~1）。
     * 放大倍数单独保存，最终增益 = 放大倍数 × 系统音量，交给解码器原生放大。
     */
    @Override
    public void setVolume(float left, float right) {
        systemVolume = Math.max(left, right);
        if (decoder != null) {
            applyGain();
        }
    }

    private void applyGain() {
        try {
            decoder.setVolume(clamp(volumeBoost * systemVolume, 0f, 8f));
        } catch (Throwable ignored) {
        }
    }

    /** 音量放大倍数（1.0 = 原始音量，最大 2.0 = 200%） */
    public void setBoost(float b) {
        volumeBoost = clamp(b, 1f, 2f);
        if (decoder != null) {
            applyGain();
        }
    }

    private static float clamp(float v, float lo, float hi) {
        if (v < lo) {
            return lo;
        }
        if (v > hi) {
            return hi;
        }
        return v;
    }

    @Override
    public int buffered() {
        // 解码器未直接暴露缓冲百分比，返回 100 表示本地播放始终可用
        return 100;
    }

    @Override
    public List<TrackInfo> tracks() {
        List<TrackInfo> out = new ArrayList<TrackInfo>();
        if (decoder == null) {
            return out;
        }
        try {
            List<com.hwdecoder.TrackInfo> src = decoder.getTrackList();
            if (src == null) {
                return out;
            }
            for (int i = 0; i < src.size(); i++) {
                com.hwdecoder.TrackInfo t = src.get(i);
                int type = (t.type == com.hwdecoder.TrackInfo.TYPE_AUDIO) ? 1 : 0;
                TrackInfo ti = new TrackInfo(t.index, type, t.mime, t.language);
                ti.selected = (i == decoder.getAudioTrackIndex());
                out.add(ti);
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    @Override
    public void selectTrack(int index) {
        if (decoder == null) {
            return;
        }
        try {
            pendingTrack = index;
            decoder.selectAudioTrack(index);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void release() {
        released = true;
        if (decoder != null) {
            try {
                decoder.release();
            } catch (Throwable ignored) {
            }
            decoder = null;
        }
        surface = null;
    }

    @Override
    public String engineName() {
        if (decoder == null) {
            return "时尘硬解内核";
        }
        try {
            com.hwdecoder.StatsCollector.Stats s = decoder.stats().snapshot();
            if (s != null && s.videoCodec != null) {
                boolean hw = s.hardwareVideo;
                return (hw ? "时尘硬解内核 · " : "时尘软解内核 · ") + s.videoCodec;
            }
        } catch (Throwable ignored) {
        }
        return hardwareOnly ? "时尘硬解内核" : "时尘软解内核";
    }

    @Override
    public int audioSessionId() {
        // 解码器内部自行管理音频输出，不暴露 AudioSession，返回 0 表示不接管系统音效
        return 0;
    }

    /** 均衡器面板用：返回时尘内核内置 EQ */
    public com.hwdecoder.Equalizer equalizer() {
        return decoder != null ? decoder.getEqualizer() : null;
    }

    /** 供播放页查询当前解码器是否真的走了硬件 */
    public boolean isHardware() {
        if (decoder == null) {
            return hardwareOnly;
        }
        try {
            com.hwdecoder.StatsCollector.Stats s = decoder.stats().snapshot();
            return s != null && s.hardwareVideo;
        } catch (Throwable ignored) {
            return hardwareOnly;
        }
    }
}
