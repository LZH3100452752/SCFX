package com.shichen.player;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

/** 简易流式布局：用于排序字段 chip、均衡器预设等 */
public class FlowLayout extends ViewGroup {
    private int hGap = 10;
    private int vGap = 10;

    public FlowLayout(Context c) {
        super(c);
        init(c);
    }

    public FlowLayout(Context c, AttributeSet a) {
        super(c, a);
        init(c);
    }

    public FlowLayout(Context c, AttributeSet a, int s) {
        super(c, a, s);
        init(c);
    }

    private void init(Context c) {
        float d = c.getResources().getDisplayMetrics().density;
        hGap = (int) (9 * d);
        vGap = (int) (9 * d);
    }

    public void setGaps(int h, int v) {
        hGap = h;
        vGap = v;
        requestLayout();
    }

    protected void onMeasure(int wSpec, int hSpec) {
        int width = MeasureSpec.getSize(wSpec) - getPaddingLeft() - getPaddingRight();
        int count = getChildCount();
        int x = getPaddingLeft();
        int y = getPaddingTop();
        int rowH = 0;
        for (int i = 0; i < count; i++) {
            View v = getChildAt(i);
            if (v.getVisibility() == GONE) {
                continue;
            }
            measureChild(v, wSpec, hSpec);
            int cw = v.getMeasuredWidth();
            int ch = v.getMeasuredHeight();
            if (x + cw > getPaddingLeft() + width && x > getPaddingLeft()) {
                x = getPaddingLeft();
                y += rowH + vGap;
                rowH = 0;
            }
            x += cw + hGap;
            rowH = Math.max(rowH, ch);
        }
        int totalH = y + rowH + getPaddingBottom();
        setMeasuredDimension(resolveSize(MeasureSpec.getSize(wSpec), wSpec),
                resolveSize(totalH, hSpec));
    }

    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int width = r - l - getPaddingLeft() - getPaddingRight();
        int x = getPaddingLeft();
        int y = getPaddingTop();
        int rowH = 0;
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View v = getChildAt(i);
            if (v.getVisibility() == GONE) {
                continue;
            }
            int cw = v.getMeasuredWidth();
            int ch = v.getMeasuredHeight();
            if (x + cw > getPaddingLeft() + width && x > getPaddingLeft()) {
                x = getPaddingLeft();
                y += rowH + vGap;
                rowH = 0;
            }
            v.layout(x, y, x + cw, y + ch);
            x += cw + hGap;
            rowH = Math.max(rowH, ch);
        }
    }
}
