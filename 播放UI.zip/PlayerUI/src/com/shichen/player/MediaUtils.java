package com.shichen.player;

import android.content.Context;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class MediaUtils {

    public static String formatDuration(long ms) {
        if (ms <= 0) {
            return "00:00";
        }
        long total = ms / 1000;
        long h = total / 3600;
        long m = (total % 3600) / 60;
        long s = total % 60;
        if (h > 0) {
            return String.format(Locale.getDefault(), "%d:%02d:%02d", h, m, s);
        }
        return String.format(Locale.getDefault(), "%02d:%02d", m, s);
    }

    public static String formatDurationCn(long ms) {
        if (ms <= 0) {
            return "未知";
        }
        long total = ms / 1000;
        long h = total / 3600;
        long m = (total % 3600) / 60;
        long s = total % 60;
        if (h > 0) {
            return h + "小时" + m + "分";
        }
        if (m > 0) {
            return m + "分" + s + "秒";
        }
        return s + "秒";
    }

    public static String formatSize(long bytes) {
        if (bytes <= 0) {
            return "0B";
        }
        String[] u = {"B", "KB", "MB", "GB", "TB"};
        int i = (int) (Math.log(bytes) / Math.log(1024));
        if (i >= u.length) {
            i = u.length - 1;
        }
        return String.format(Locale.getDefault(), "%.1f%s", bytes / Math.pow(1024, i), u[i]);
    }

    public static String formatDate(long ms) {
        if (ms <= 0) {
            return "未知";
        }
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        return f.format(new Date(ms));
    }

    public static String formatRelative(long ms) {
        if (ms <= 0) {
            return "从未播放";
        }
        long diff = System.currentTimeMillis() - ms;
        if (diff < 60000) {
            return "刚刚";
        }
        if (diff < 3600000) {
            return (diff / 60000) + " 分钟前";
        }
        if (diff < 86400000) {
            return (diff / 3600000) + " 小时前";
        }
        if (diff < 2592000000L) {
            return (diff / 86400000) + " 天前";
        }
        return formatDate(ms);
    }

    /** 紧凑倍速文本：2.0 → "2"，1.25 → "1.25"（不带 x 后缀） */
    public static String trimSpeed(float s) {
        if (Math.abs(s - Math.round(s)) < 0.01f) {
            return String.format(Locale.getDefault(), "%.0f", s);
        }
        return String.format(Locale.getDefault(), "%.2f", s);
    }

    public static String[] formatSpeedArray(float[] arr) {
        String[] out = new String[arr.length];
        for (int i = 0; i < arr.length; i++) {
            out[i] = formatSpeed(arr[i]);
        }
        return out;
    }

    public static String formatSpeed(float s) {
        if (Math.abs(s - Math.round(s)) < 0.01f) {
            return String.format(Locale.getDefault(), "%.0fx", s);
        }
        return String.format(Locale.getDefault(), "%.2fx", s);
    }

    private static void putIf(MediaMetadataRetriever mmr, Map<String, String> map,
                              String label, int key) {
        try {
            String v = mmr.extractMetadata(key);
            if (v != null && v.length() > 0 && !v.equals("null")) {
                map.put(label, v);
            }
        } catch (Exception ignored) {
        }
    }

    private static String ratioName(float r) {
        if (Math.abs(r - 16f / 9f) < 0.02f) {
            return "16:9";
        }
        if (Math.abs(r - 4f / 3f) < 0.02f) {
            return "4:3";
        }
        if (Math.abs(r - 1f) < 0.02f) {
            return "1:1";
        }
        if (Math.abs(r - 21f / 9f) < 0.05f) {
            return "21:9";
        }
        if (Math.abs(r - 1.85f) < 0.05f) {
            return "1.85:1";
        }
        if (Math.abs(r - 2.35f) < 0.05f) {
            return "2.35:1";
        }
        return String.format(java.util.Locale.getDefault(), "%.2f:1", r);
    }

    public static Map<String, String> info(Context c, String path) {
        Map<String, String> map = new LinkedHashMap<String, String>();
        MediaExtractor ex = null;
        try {
            ex = new MediaExtractor();
            if (path.startsWith("content://") || path.startsWith("http")) {
                ex.setDataSource(c, Uri.parse(path), null);
            } else {
                ex.setDataSource(path);
            }
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime == null) {
                    continue;
                }
                String kind = mime.startsWith("video") ? "视频轨"
                        : (mime.startsWith("audio") ? "音频轨"
                        : (mime.startsWith("text") || mime.contains("subtitle")) ? "字幕轨" : "其他轨");
                StringBuilder sb = new StringBuilder(mime);
                try {
                    if (mime.startsWith("video")) {
                        sb.append("  ").append(f.getInteger(MediaFormat.KEY_WIDTH)).append("x")
                                .append(f.getInteger(MediaFormat.KEY_HEIGHT));
                        if (f.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                            sb.append(" @").append(f.getInteger(MediaFormat.KEY_FRAME_RATE)).append("fps");
                        }
                    } else if (mime.startsWith("audio")) {
                        sb.append("  ").append(f.getInteger(MediaFormat.KEY_SAMPLE_RATE)).append("Hz ")
                                .append(f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)).append("ch");
                    }
                    if (f.containsKey(MediaFormat.KEY_BIT_RATE)) {
                        sb.append("  ").append(f.getInteger(MediaFormat.KEY_BIT_RATE) / 1000).append("kbps");
                    }
                } catch (Exception ignored) {
                }
                if (f.containsKey("language")) {
                    sb.append("  [").append(f.getString("language")).append("]");
                }
                map.put(kind + " #" + i, sb.toString());
            }
        } catch (Exception e) {
            map.put("轨道信息", "无法解析");
        } finally {
            if (ex != null) {
                try {
                    ex.release();
                } catch (Exception ignored) {
                }
            }
        }
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            if (path.startsWith("content://") || path.startsWith("http")) {
                mmr.setDataSource(c, Uri.parse(path));
            } else {
                mmr.setDataSource(path);
            }
            String dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            String title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
            String author = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_AUTHOR);
            if (dur != null) {
                map.put("时长", formatDurationCn(Long.parseLong(dur)));
            }
            if (title != null) {
                map.put("内嵌标题", title);
            }
            if (author != null) {
                map.put("作者", author);
            }
            putIf(mmr, map, "专辑", MediaMetadataRetriever.METADATA_KEY_ALBUM);
            putIf(mmr, map, "艺术家", MediaMetadataRetriever.METADATA_KEY_ARTIST);
            putIf(mmr, map, "年份", MediaMetadataRetriever.METADATA_KEY_YEAR);
            putIf(mmr, map, "流派", MediaMetadataRetriever.METADATA_KEY_GENRE);
            putIf(mmr, map, "作曲者", MediaMetadataRetriever.METADATA_KEY_COMPOSER);
            // 首帧取真实画面尺寸与旋转角
            try {
                String w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
                String h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
                String rot = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
                if (w != null && h != null) {
                    int iw = Integer.parseInt(w);
                    int ih = Integer.parseInt(h);
                    int ir = rot == null ? 0 : Integer.parseInt(rot);
                    boolean land = (ir == 90 || ir == 270);
                    int dw = land ? ih : iw;
                    int dh = land ? iw : ih;
                    map.put("分辨率", dw + " × " + dh
                            + (ir == 0 ? "" : "（原始 " + iw + "×" + ih + "，旋转 " + ir + "°）"));
                    map.put("宽高比", ratioName(dw / (float) dh));
                }
            } catch (Exception ignored) {
            }
        } catch (Exception ignored) {
        } finally {
            try {
                mmr.release();
            } catch (Exception ignored) {
            }
        }
        return map;
    }

    /** 返回 {width, height, rotation, duration} */
    public static long[] probeVideoSize(String path) {
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(path);
            String w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            String h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            String r = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            String d = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            return new long[]{w == null ? 0 : Long.parseLong(w), h == null ? 0 : Long.parseLong(h),
                    r == null ? 0 : Long.parseLong(r), d == null ? 0 : Long.parseLong(d)};
        } catch (Exception e) {
            return new long[]{0, 0, 0, 0};
        } finally {
            try {
                mmr.release();
            } catch (Exception ignored) {
            }
        }
    }
}
