package com.shichen.player;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 播放界面功能面板
 * 半透明底 + 圆形线性图标网格；图标顺序可长按自由调整并持久化；
 * 覆盖原"更多"菜单的全部功能，另含小窗、后台播放等扩展项。
 */
public class PlayToolsPanel {

    private final PlayerActivity act;
    private final int accent;
    private final int d;

    public PlayToolsPanel(Activity a) {
        act = (PlayerActivity) a;
        accent = ThemeEngine.accent(a);
        d = (int) a.getResources().getDisplayMetrics().density;
    }

    /* ==================== 工具项定义 ==================== */
    static final String[] IDS = {
            "playlist", "ratio", "zoom", "audio", "subtitle", "ab", "fav", "addlist",
            "speed", "repeat", "decode", "eq", "info", "url", "sleep", "shot",
            "lock", "rotate", "bright", "settings", "boost", "status", "avsync",
            "pip", "bgplay", "wake", "share", "scan", "jump",
            "flip", "ctrlkeys",
            "bookmark", "abclear", "balance", "resetorder",
    };
    static final int[] ICONS = {
        R.drawable.ic_playlist, R.drawable.ic_ratio, R.drawable.ic_zoom,
            R.drawable.ic_audio, R.drawable.ic_subtitle, R.drawable.ic_ab,
            R.drawable.ic_fav, R.drawable.ic_add, R.drawable.ic_speed,
            R.drawable.ic_repeat, R.drawable.ic_decode, R.drawable.ic_equalizer,
            R.drawable.ic_info, R.drawable.ic_url, R.drawable.ic_sleep,
            R.drawable.ic_screenshot, R.drawable.ic_lock, R.drawable.ic_screen_rotate,
            R.drawable.ic_brightness, R.drawable.ic_settings, R.drawable.ic_volume,
            R.drawable.ic_statusbar, R.drawable.ic_avsync, R.drawable.ic_pip,
            R.drawable.ic_bgplay, R.drawable.ic_wake, R.drawable.ic_share,
            R.drawable.ic_scan, R.drawable.ic_jump, R.drawable.ic_flip,
            R.drawable.ic_quickedit, R.drawable.ic_bookmark,
            R.drawable.ic_abclear, R.drawable.ic_balance, R.drawable.ic_reset,
    };
    static final String[] LABELS = {
        "播放列表", "长宽比", "显示设置", "音轨", "字幕", "A-B循环", "收藏", "加入列表", "倍速", "循环模式", "解码", "均衡器",
            "信息", "网络串流", "睡眠定时", "截图", "锁定", "屏幕方向", "亮度音量", "播放设置", "音量放大", "顶部状态", "音画同步",
            "小窗", "后台播放", "屏幕常亮", "分享", "扫描", "跳转", "视频翻转", "控制栏按键", "书签", "清除A-B",
            "声道平衡", "重置排序",
    };

    private List<String> loadOrder() {
        List<String> order = new ArrayList<String>();
        List<String> hidden = hiddenList();
        String saved = Prefs.toolsOrder(act);
        if (saved != null && saved.length() > 0) {
            for (String t : saved.split(",")) {
                // 已隐藏的项即便存在于自定义顺序里也必须排除
                if (hidden.contains(t)) {
                    continue;
                }
                for (String id : IDS) {
                    if (id.equals(t) && !order.contains(t)) {
                        order.add(t);
                        break;
                    }
                }
            }
        }
        for (String id : IDS) {
            if (!order.contains(id) && !hidden.contains(id)) {
                order.add(id);
            }
        }
        return order;
    }

    /** 重新读取顺序并排除隐藏项，立即刷新工具网格（无需重开面板） */
    private void reloadOrder() {
        List<String> nl = loadOrder();
        order.clear();
        order.addAll(nl);
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
        // GridView 行数变了要重算高度，否则会被截断
        if (gv != null) {
            final int cols = calcCols();
            final int rowH = (int) (72 * d);
            gv.post(new Runnable() {
                public void run() {
                    int rows = (order.size() + cols - 1) / cols;
                    int want = rows * (rowH + 10 * d) + 16 * d;
                    ViewGroup.LayoutParams lp = gv.getLayoutParams();
                    lp.height = want;
                    gv.setLayoutParams(lp);
                    gv.requestLayout();
                }
            });
        }
    }

    private List<String> hiddenList() {
        List<String> h = new ArrayList<String>();
        String saved = Prefs.hiddenTools(act);
        if (saved != null && saved.length() > 0) {
            for (String t : saved.split(",")) {
                if (t.length() > 0) {
                    h.add(t);
                }
            }
        }
        return h;
    }

    private void saveOrder(List<String> order) {
        StringBuilder sb = new StringBuilder();
        for (String s2 : order) {
            if (sb.length() > 0) {
                sb.append(',');
            }
            sb.append(s2);
        }
        Prefs.setToolsOrder(act, sb.toString());
    }

    static int iconOfStatic(String id) {
        for (int i = 0; i < IDS.length; i++) {
            if (IDS[i].equals(id)) {
                return ICONS[i];
            }
        }
        return R.drawable.ic_more;
    }

    /** 供外部（快捷键栏）直接触发某项功能 */
    public void dispatchStatic(String id) {
        dispatch(id);
    }

    private int iconOf(String id) {
        for (int i = 0; i < IDS.length; i++) {
            if (IDS[i].equals(id)) {
                return ICONS[i];
            }
        }
        return R.drawable.ic_more;
    }

    private String labelOf(String id) {
        for (int i = 0; i < IDS.length; i++) {
            if (IDS[i].equals(id)) {
                return LABELS[i];
            }
        }
        return id;
    }

    /* ==================== 主网格 ==================== */
    private boolean editing = false;
    private GridView gv;
    private GridAdapter adapter;
    private List<String> order;

    public View build() {
        order = loadOrder();

        LinearLayout outer = new LinearLayout(act);
        outer.setOrientation(LinearLayout.VERTICAL);

        // 提示与"编辑"按钮并排：左边说明文字，右边编辑入口，不留空区
        LinearLayout header = new LinearLayout(act);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(10 * d, 6 * d, 10 * d, 2 * d);

        final TextView tip = new TextView(act);
        tip.setText("\u2699 长按图标可调整顺序");
        tip.setTextSize(11f);
        tip.setTextColor(0x99FFFFFF);
        tip.setSingleLine(true);
        tip.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(tip);

        TextView edit = new TextView(act);
        edit.setText("编辑");
        edit.setTextSize(12f);
        edit.setTextColor(accent);
        edit.setGravity(Gravity.CENTER);
        edit.setBackgroundResource(R.drawable.bg_panel_btn_sel);
        edit.setPadding(14 * d, 6 * d, 14 * d, 6 * d);
        edit.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        edit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showToolEdit();
            }
        });
        header.addView(edit);
        outer.addView(header);

        gv = new GridView(act);
        final int cols = calcCols();
        gv.setNumColumns(cols);
        gv.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        gv.setHorizontalSpacing(4 * d);
        gv.setVerticalSpacing(10 * d);
        gv.setPadding(6 * d, 2 * d, 6 * d, 10 * d);
        gv.setSelector(android.R.color.transparent);
        adapter = new GridAdapter();
        gv.setAdapter(adapter);
        // GridView 放进 ScrollView 后若不显式给高度只会显示一行，这里按行数补齐
        final int rowH = (int) (72 * d);
        gv.getViewTreeObserver().addOnGlobalLayoutListener(
                new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                int rows = (order.size() + cols - 1) / cols;
                int want = rows * (rowH + 10 * d) + 16 * d;
                if (gv.getHeight() < want - 8 * d) {
                    ViewGroup.LayoutParams lp = gv.getLayoutParams();
                    lp.height = want;
                    gv.setLayoutParams(lp);
                    gv.requestLayout();
                }
            }
        });

        gv.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                if (!editing) {
                    dispatch(order.get(pos));
                }
            }
        });
        gv.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(android.widget.AdapterView<?> p, View v,
                                           int pos, long id) {
                editing = !editing;
                tip.setText(editing ? "编辑模式：点 ← → 移动顺序，再长按退出"
                        : "\u2699 长按图标可调整顺序");
                adapter.notifyDataSetChanged();
                return true;
            }
        });
        outer.addView(gv);
        return outer;
    }

    private int calcCols() {
        try {
            int wpx = act.getResources().getDisplayMetrics().widthPixels;
            boolean land = act.getResources().getConfiguration().orientation
                    == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
            float avail = land ? wpx * 0.42f : wpx;
            int per = (int) (74 * act.getResources().getDisplayMetrics().density);
            return Math.max(3, Math.min(5, (int) (avail / per)));
        } catch (Exception e) {
            return 4;
        }
    }

    private class GridAdapter extends BaseAdapter {
        public int getCount() {
            return order == null ? 0 : order.size();
        }

        public Object getItem(int pos) {
            return order.get(pos);
        }

        public long getItemId(int pos) {
            return pos;
        }

        public View getView(final int pos, View cv, ViewGroup parent) {
            final String id = order.get(pos);
            LinearLayout cell = new LinearLayout(act);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(2 * d, 4 * d, 2 * d, 4 * d);

            android.widget.FrameLayout circle = new android.widget.FrameLayout(act);
            int sz = (int) (46 * d);
            circle.setLayoutParams(new LinearLayout.LayoutParams(sz, sz));
            ImageView iv = new ImageView(act);
            iv.setImageResource(iconOf(id));
            iv.setColorFilter(0xFFF2F2F8);
            int ip = (int) (11 * d);
            android.widget.FrameLayout.LayoutParams flp =
                    new android.widget.FrameLayout.LayoutParams(sz - ip, sz - ip);
            flp.gravity = Gravity.CENTER;
            circle.addView(iv, flp);
            cell.addView(circle);

            TextView t = new TextView(act);
            t.setText(labelOf(id));
            t.setTextSize(10.5f);
            t.setTextColor(0xCCFFFFFF);
            t.setGravity(Gravity.CENTER);
            t.setSingleLine(true);
            t.setPadding(0, 4 * d, 0, 0);
            cell.addView(t);

            if (editing) {
                LinearLayout btns = new LinearLayout(act);
                btns.setOrientation(LinearLayout.HORIZONTAL);
                btns.setGravity(Gravity.CENTER);
                TextView left = new TextView(act);
                left.setText("\u2190");
                left.setTextSize(14f);
                left.setTextColor(accent);
                left.setPadding(9 * d, 2 * d, 12 * d, 2 * d);
                left.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        move(pos, -1);
                    }
                });
                TextView right = new TextView(act);
                right.setText("\u2192");
                right.setTextSize(14f);
                right.setTextColor(accent);
                right.setPadding(12 * d, 2 * d, 9 * d, 2 * d);
                right.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        move(pos, 1);
                    }
                });
                btns.addView(left);
                btns.addView(right);
                cell.addView(btns);
            }
            return cell;
        }
    }

    private void move(int pos, int dir) {
        int to = pos + dir;
        if (to < 0 || to >= order.size()) {
            return;
        }
        String a = order.get(pos);
        order.set(pos, order.get(to));
        order.set(to, a);
        saveOrder(order);
        adapter.notifyDataSetChanged();
    }

    /* ==================== 功能分发 ==================== */
    private void dispatch(String id) {
        if ("playlist".equals(id)) {
            act.showPlaylist();
        } else if ("ratio".equals(id)) {
            showRatio();
        } else if ("zoom".equals(id)) {
            showZoom();
        } else if ("audio".equals(id)) {
            act.showTracks();
        } else if ("subtitle".equals(id)) {
            act.showSubtitleMenu();
        } else if ("ab".equals(id)) {
            act.toggleAb();
        } else if ("fav".equals(id)) {
            act.toggleFav();
        } else if ("addlist".equals(id)) {
            Ui.toast(act, "已加入播放列表");
        } else if ("speed".equals(id)) {
            showSpeed();
        } else if ("repeat".equals(id)) {
            showRepeat();
        } else if ("decode".equals(id)) {
            showDecode();
        } else if ("eq".equals(id)) {
            act.openEqualizer();
        } else if ("info".equals(id)) {
            act.showInfo();
        } else if ("url".equals(id)) {
            act.showUrlDialog();
        } else if ("sleep".equals(id)) {
            act.showSleep();
        } else if ("shot".equals(id)) {
            act.screenshot();
        } else if ("lock".equals(id)) {
            act.setLocked(true);
        } else if ("rotate".equals(id)) {
            showOrientation();
        } else if ("bright".equals(id)) {
            showBrightVol();
        } else if ("settings".equals(id)) {
            act.openPlaySettings();
        } else if ("boost".equals(id)) {
            showBoost();
        } else if ("status".equals(id)) {
            showStatus();
        } else if ("avsync".equals(id)) {
            showAudioDelay();
        } else if ("pip".equals(id)) {
            act.enterPip();
        } else if ("bgplay".equals(id)) {
            act.startBackground();
        } else if ("wake".equals(id)) {
            toggleWake();
        } else if ("share".equals(id)) {
            act.shareCurrent();
        } else if ("scan".equals(id)) {
            act.rescanLibrary();
        } else if ("jump".equals(id)) {
            showJump();
        } else if ("flip".equals(id)) {
            showFlip();
        } else if ("ctrlkeys".equals(id)) {
            showCtrlKeys();
        } else if ("tooledit".equals(id)) {
            showToolEdit();
        } else if ("bookmark".equals(id)) {
            act.showBookmarks();
        } else if ("abclear".equals(id)) {
            act.clearAb();
            Ui.toast(act, "已清除 A-B 循环");
        } else if ("balance".equals(id)) {
            showBalance();
        } else if ("resetorder".equals(id)) {
            Prefs.setToolsOrder(act, "");
            Ui.toast(act, "已重置为默认顺序");
        }
    }

    private void toggleWake() {
        boolean on = !Prefs.keepScreenOn(act);
        Prefs.setKeepScreenOn(act, on);
        try {
            if (on) {
                act.getWindow().addFlags(
                        android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            } else {
                act.getWindow().clearFlags(
                        android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        } catch (Exception ignored) {
        }
        Ui.toast(act, on ? "屏幕常亮：开" : "屏幕常亮：关");
    }

    private void showJump() {
        final android.widget.EditText ed = new android.widget.EditText(act);
        ed.setHint("输入秒数 或 mm:ss");
        ed.setTextColor(0xFFFFFFFF);
        ed.setHintTextColor(0x88FFFFFF);
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(16 * d, 12 * d, 16 * d, 12 * d);
        box.addView(ed);
        act.hideControls();
        Ui.panel(act, "跳转到", box, true, new Ui.OnPanel() {
            public void onOk(android.app.AlertDialog d) {
                String t = ed.getText().toString().trim();
                long ms = 0;
                try {
                    if (t.indexOf(':') > 0) {
                        String[] pp = t.split(":");
                        ms = (Long.parseLong(pp[0]) * 60L + Long.parseLong(pp[1])) * 1000L;
                    } else {
                        ms = (long) (Float.parseFloat(t) * 1000);
                    }
                } catch (Exception ignored) {
                }
                act.seekToMs(ms);
            }
        });
    }

    /* ==================== 子面板 ==================== */
    private void showRatio() {
        String[] o = {"适应屏幕", "16:9", "4:3", "铺满(拉伸)", "原始尺寸", "裁剪填充", "1:1", "21:9"};
        chips("长宽比", o, act.ratio(), new ChipsCb() {
            public void onPick(int i) {
                act.applyRatio(i);
            }
        });
    }

    private void showZoom() {
        makeSliderRow("画面缩放", (int) (act.zoom() * 50), 25, 250, new OnVal() {
            public void onVal(int v) {
                act.applyZoom(v / 50f);
            }
        }, new Fmt2() {
            public String fmt(int v) {
                return (v / 50f) + "x";
            }
        }, "画面缩放");
    }

    private void showSpeed() {
        // 与控制栏倍速按钮共用同一个最新面板（滑杆 + 档位 + 自定义）
        act.showSpeedPanel();
    }

    private void showRepeat() {
        String[] o = {"不循环", "列表循环", "单曲循环"};
        chips("循环模式", o, Prefs.repeatMode(act), new ChipsCb() {
            public void onPick(int i) {
                Prefs.setRepeatMode(act, i);
                act.updateRepeatIcon();
            }
        });
    }

    private void showDecode() {
        String[] o = {"系统内核", "时尘硬件解码", "时尘软件解码", "自动"};
        chips("解码方式", o, Prefs.decodeMode(act), new ChipsCb() {
            public void onPick(int i) {
                Prefs.setDecodeMode(act, i);
                act.reloadEngine();
            }
        });
    }

    private void showOrientation() {
        String[] o = {"跟随视频", "自动旋转", "强制横屏", "强制竖屏", "跟随系统"};
        chips("屏幕方向", o, Prefs.orientation(act), new ChipsCb() {
            public void onPick(int i) {
                act.applyOrientation(i);
            }
        });
    }

    private void showBrightVol() {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14 * d, 12 * d, 14 * d, 12 * d);
        box.addView(makeSlider("亮度", (int) (act.brightness() * 100), 0, 100, new OnVal() {
            public void onVal(int v) {
                act.applyBrightness(v / 100f);
            }
        }));
        box.addView(makeSlider("音量", (int) (act.volume() * 100), 0, 100, new OnVal() {
            public void onVal(int v) {
                act.applyVolume(v / 100f);
            }
        }));
        act.hideControls();
        Ui.panel(act, "亮度 / 音量", box, true, null);
    }

    private void showBoost() {
        String[] o = {"100%（原始）", "120%", "140%", "160%", "180%", "200%"};
        final int[] vals = {100, 120, 140, 160, 180, 200};
        int cur = 0;
        for (int i = 0; i < vals.length; i++) {
            if (vals[i] == Prefs.boostVolume(act)) {
                cur = i;
            }
        }
        chips("音量放大（当前 " + Prefs.boostVolume(act) + "%）", o, cur, new ChipsCb() {
            public void onPick(int i) {
                Prefs.setBoostVolume(act, vals[i]);
                act.applyBoost(vals[i] / 100f);
            }
        });
    }

    private void showStatus() {
        showStatusPosition();
    }


    private void showAudioDelay() {
        String[] o = {"-500 ms", "-250 ms", "0（默认）", "+250 ms", "+500 ms"};
        final int[] vals = {-500, -250, 0, 250, 500};
        int cur = 2;
        for (int i = 0; i < vals.length; i++) {
            if (vals[i] == Prefs.audioDelay(act)) {
                cur = i;
            }
        }
        chips("音画同步（音频延迟）", o, cur, new ChipsCb() {
            public void onPick(int i) {
                Prefs.setAudioDelay(act, vals[i]);
                Ui.toast(act, "音频延迟 " + vals[i] + " ms");
            }
        });
    }

    /** 状态栏位置：可视化拖动调整 */
    private void showStatusPosition() {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14 * d, 14 * d, 14 * d, 14 * d);

        TextView tip = new TextView(act);
        tip.setText("拖动调整顶部状态栏位置，实时生效");
        tip.setTextSize(12f);
        tip.setTextColor(0xAAFFFFFF);
        box.addView(tip);

        // 上限 = 屏幕宽度的一半（dp）：拉到最大时左右两个胶囊正好挨在一起
        int maxX = Math.round(act.getResources().getDisplayMetrics().widthPixels
                / act.getResources().getDisplayMetrics().density / 2f);
        if (maxX < 40) {
            maxX = 40;
        }
        box.addView(makeSlider("左右同步内缩（最大 " + maxX + " dp 时两者相邻）",
                Prefs.statusInsetX(act), 0, maxX, new OnVal() {
            public void onVal(int v) {
                Prefs.setStatusInsetX(act, v);
                act.applyStatus();
            }
        }));
        box.addView(makeSlider("距顶部偏移", Prefs.statusInsetY(act), 0, 200, new OnVal() {
            public void onVal(int v) {
                Prefs.setStatusInsetY(act, v);
                act.applyStatus();
            }
        }));

        TextView gather = new TextView(act);
        gather.setText("一键靠拢（左右贴到一起）");
        gather.setTextSize(12.5f);
        gather.setTextColor(accent);
        gather.setGravity(Gravity.CENTER);
        gather.setPadding(0, 10 * d, 0, 6 * d);
        gather.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // 屏幕宽度的 40% 足以让两个胶囊完全贴在一起
                int w = act.getResources().getDisplayMetrics().widthPixels;
                int v2 = (int) (w / act.getResources().getDisplayMetrics().density * 0.4f);
                Prefs.setStatusInsetX(act, v2);
                act.applyStatus();
            }
        });
        box.addView(gather);

        String[] lo = {"当前 / 总时长", "总时长", "剩余时长"};
        box.addView(makeChips("左侧内容", lo, Prefs.statusLeftMode(act), new OnVal() {
            public void onVal(int v) {
                Prefs.setStatusLeftMode(act, v);
                act.applyStatus();
            }
        }));
        String[] ro = {"电量 + 时间", "仅电量", "仅时间"};
        box.addView(makeChips("右侧内容", ro, Prefs.statusRightMode(act), new OnVal() {
            public void onVal(int v) {
                Prefs.setStatusRightMode(act, v);
                act.applyStatus();
            }
        }));

        act.hideControls();
        Ui.panel(act, "状态栏位置与内容", box, true, null);
    }

    /** 声道平衡：左右声道音量 */
    private void showBalance() {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14 * d, 12 * d, 14 * d, 12 * d);
        box.addView(makeSlider("声道平衡（0 左 ← → 100 右）",
                Prefs.balance(act), 0, 100, new OnVal() {
            public void onVal(int v) {
                Prefs.setBalance(act, v);
                act.applyBalance(v);
            }
        }));
        act.hideControls();
        Ui.panel(act, "声道平衡", box, true, null);
    }

    /** 工具按钮显示 / 隐藏编辑：取消勾选即从工具面板隐藏 */
    private void showToolEdit() {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14 * d, 14 * d, 14 * d, 14 * d);

        final List<String> hidden = hiddenList();

        TextView tip = new TextView(act);
        tip.setText("勾选需要显示的功能，取消勾选即从工具面板隐藏");
        tip.setTextSize(12.5f);
        tip.setTextColor(0xFFF0F0F5);
        box.addView(tip);

        final TextView cnt = new TextView(act);
        cnt.setTextSize(11.5f);
        cnt.setTextColor(0xAAFFFFFF);
        box.addView(cnt);

        final FlowLayout fl = new FlowLayout(act);
        fl.setGaps(8 * d, 8 * d);
        fl.setPadding(0, 10 * d, 0, 6 * d);

        final Runnable repaint = new Runnable() {
            public void run() {
                for (int i = 0; i < fl.getChildCount(); i++) {
                    View v = fl.getChildAt(i);
                    if (!(v instanceof TextView)) {
                        continue;
                    }
                    TextView t = (TextView) v;
                    Object tag = t.getTag();
                    boolean on = tag != null && !hidden.contains(tag.toString());
                    t.setTextColor(on ? Color.WHITE : 0xFF8A8A96);
                    t.setBackgroundResource(on ? R.drawable.bg_panel_btn_sel
                            : R.drawable.bg_panel_btn);
                    t.setText((on ? "\u2713 " : "\u25CB ") + t.getContentDescription());
                }
                cnt.setText("已显示 " + (IDS.length - hidden.size()) + " / " + IDS.length
                        + "    （\u2713 显示  \u25CB 隐藏）");
            }
        };

        for (int i = 0; i < IDS.length; i++) {
            final String id = IDS[i];
            if ("tooledit".equals(id)) {
                continue;
            }
            final int idx = i;
            TextView t = new TextView(act);
            t.setTag(id);
            t.setContentDescription(LABELS[idx]);
            t.setText(LABELS[idx]);
            t.setTextSize(12.5f);
            t.setGravity(Gravity.CENTER);
            t.setPadding(14 * d, 8 * d, 14 * d, 8 * d);
            t.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (hidden.contains(id)) {
                        hidden.remove(id);
                    } else {
                        hidden.add(id);
                    }
                    StringBuilder sb = new StringBuilder();
                    for (String q : hidden) {
                        if (sb.length() > 0) {
                            sb.append(',');
                        }
                        sb.append(q);
                    }
                    Prefs.setHiddenTools(act, sb.toString());
                    reloadOrder();
                    repaint.run();
                }
            });
            fl.addView(t);
        }
        repaint.run();
        box.addView(fl);

        LinearLayout btns = new LinearLayout(act);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.CENTER);
        String[] ops = {"全部显示", "仅保留常用"};
        final String[] common = {
                "playlist", "speed", "ratio", "decode", "subtitle", "audio",
                "flip", "settings", "boost", "info",
        };
        for (int i = 0; i < ops.length; i++) {
            final int which = i;
            TextView b = new TextView(act);
            b.setText(ops[i]);
            b.setTextSize(12.5f);
            b.setGravity(Gravity.CENTER);
            b.setTextColor(accent);
            b.setBackgroundResource(R.drawable.bg_panel_btn);
            b.setPadding(14 * d, 8 * d, 14 * d, 8 * d);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) {
                lp.leftMargin = 8 * d;
            }
            b.setLayoutParams(lp);
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    hidden.clear();
                    if (which == 1) {
                        for (String id : IDS) {
                            boolean keep = false;
                            for (String c : common) {
                                if (c.equals(id)) {
                                    keep = true;
                                    break;
                                }
                            }
                            if (!keep && !"tooledit".equals(id)) {
                                hidden.add(id);
                            }
                        }
                    }
                    StringBuilder sb = new StringBuilder();
                    for (String q : hidden) {
                        if (sb.length() > 0) {
                            sb.append(',');
                        }
                        sb.append(q);
                    }
                    Prefs.setHiddenTools(act, sb.toString());
                    reloadOrder();
                    repaint.run();
                }
            });
            btns.addView(b);
        }
        box.addView(btns);

        act.hideControls();
        Ui.panel(act, "工具按钮编辑", box, true, new Ui.OnPanel() {
            public void onOk(android.app.AlertDialog d) {
                reloadOrder();
            }
        });
    }

    /**
     * 视频翻转 / 旋转（已合并 90° 旋转）。
     * 用于录制方向错误的视频：明明该竖着看，却存成了横屏。
     * 旋转后会按新的宽高比重算缩放，绝不会拉伸变形。
     */
    private void showFlip() {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14 * d, 14 * d, 14 * d, 14 * d);

        TextView tip = new TextView(act);
        tip.setText("视频方向不对时，用旋转或翻转校正。旋转后保持原始比例，不会拉伸。");
        tip.setTextSize(12f);
        tip.setTextColor(0xAAFFFFFF);
        box.addView(tip);

        // 旋转：0/90/180/270，带快捷 90° 步进
        String[] ro = {"0°（原始）", "90°", "180°", "270°"};
        int rcur = Prefs.videoRotate(act) / 90;
        box.addView(makeChips("旋转", ro, rcur, new OnVal() {
            public void onVal(int v) {
                act.applyUserRotate(v * 90);
            }
        }));

        LinearLayout step = new LinearLayout(act);
        step.setOrientation(LinearLayout.HORIZONTAL);
        step.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = 4 * d;
        step.setLayoutParams(slp);
        String[] sb2 = {"↺ 左转90°", "↻ 右转90°", "归零"};
        for (int i = 0; i < sb2.length; i++) {
            final int which = i;
            TextView b = new TextView(act);
            b.setText(sb2[i]);
            b.setTextSize(12.5f);
            b.setGravity(Gravity.CENTER);
            b.setTextColor(0xFFDDDDE6);
            b.setBackgroundResource(R.drawable.bg_panel_btn);
            b.setPadding(14 * d, 8 * d, 14 * d, 8 * d);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) {
                blp.leftMargin = 6 * d;
            }
            b.setLayoutParams(blp);
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    int cur = Prefs.videoRotate(act);
                    if (which == 0) {
                        act.applyUserRotate((cur + 270) % 360);
                    } else if (which == 1) {
                        act.applyUserRotate((cur + 90) % 360);
                    } else {
                        act.applyUserRotate(0);
                    }
                }
            });
            step.addView(b);
        }
        box.addView(step);

        // 翻转：镜像 / 垂直 / 180°
        String[] fo = {"不翻转", "水平镜像", "垂直翻转", "旋转 180°"};
        box.addView(makeChips("翻转", fo, Prefs.videoFlip(act), new OnVal() {
            public void onVal(int v) {
                act.applyFlip(v);
            }
        }));

        // 组合预设：常见"录反了"的场景一键校正
        TextView t3 = new TextView(act);
        t3.setText("一键校正");
        t3.setTextSize(12.5f);
        t3.setTextColor(0xFFF0F0F5);
        LinearLayout.LayoutParams t3p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        t3p.topMargin = 10 * d;
        t3.setLayoutParams(t3p);
        box.addView(t3);

        String[] pres = {"原始（复原）", "顺时针 90°", "逆时针 90°", "倒转 180°",
                "镜像（自拍视角）"};
        box.addView(makeChips("预设", new String[]{pres[1], pres[2], pres[3], pres[4]},
                -1, new OnVal() {
            public void onVal(int v) {
                if (v == 0) {
                    act.applyUserRotate(90);
                } else if (v == 1) {
                    act.applyUserRotate(270);
                } else if (v == 2) {
                    act.applyUserRotate(180);
                } else {
                    act.applyUserRotate(0);
                    act.applyFlip(1);
                }
            }
        }));

        TextView reset = new TextView(act);
        reset.setText("全部复原");
        reset.setTextSize(12f);
        reset.setTextColor(accent);
        reset.setPadding(0, 10 * d, 0, 4 * d);
        reset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                act.applyUserRotate(0);
                act.applyFlip(0);
                Ui.toast(act, "已复原");
            }
        });
        box.addView(reset);

        act.hideControls();
        Ui.panel(act, "视频翻转 / 旋转", box, true, null);
    }


    /**
     * 控制栏右侧按键编辑：默认 倍速 / 画面比例 / 小窗，
     * 最多 5 个，可全部移除，上方实时显示预览。
     */
    private void showCtrlKeys() {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14 * d, 14 * d, 14 * d, 14 * d);

        final List<String> current = new ArrayList<String>();
        String saved = Prefs.controlKeys(act);
        if (saved != null && saved.length() > 0) {
            for (String t : saved.split(",")) {
                if (t.length() > 0) {
                    current.add(t);
                }
            }
        }

        // ---- 预览区 ----
        TextView t1 = new TextView(act);
        t1.setText("预览（当前生效顺序）");
        t1.setTextSize(12.5f);
        t1.setTextColor(0xFFF0F0F5);
        box.addView(t1);

        final LinearLayout preview = new LinearLayout(act);
        preview.setOrientation(LinearLayout.HORIZONTAL);
        preview.setGravity(Gravity.CENTER_VERTICAL);
        preview.setPadding(6 * d, 10 * d, 6 * d, 10 * d);
        preview.setBackgroundResource(R.drawable.bg_panel_row);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.topMargin = 6 * d;
        preview.setLayoutParams(plp);
        box.addView(preview);

        final TextView count = new TextView(act);
        count.setTextSize(11.5f);
        count.setTextColor(0xAAFFFFFF);
        box.addView(count);

        final Runnable save = new Runnable() {
            public void run() {
                StringBuilder sb = new StringBuilder();
                for (String q : current) {
                    if (sb.length() > 0) {
                        sb.append(',');
                    }
                    sb.append(q);
                }
                Prefs.setControlKeys(act, sb.toString());
                act.rebuildActionBar();
            }
        };        final Runnable[] repaint = new Runnable[1];
        repaint[0] = new Runnable() {
            public void run() {
                preview.removeAllViews();
                if (current.isEmpty()) {
                    TextView empty = new TextView(act);
                    empty.setText("（无按键，控制栏右侧留空）");
                    empty.setTextSize(11.5f);
                    empty.setTextColor(0x88FFFFFF);
                    empty.setPadding(8 * d, 6 * d, 8 * d, 6 * d);
                    preview.addView(empty);
                } else {
                    java.util.List<String> pv = new java.util.ArrayList<String>();
                    for (String q : current) {
                        pv.add(q);
                    }
                    java.util.Collections.reverse(pv);
                    for (final String id : pv) {
                        int idx = -1;
                        for (int i = 0; i < PlayerActivity.CTRL_IDS.length; i++) {
                            if (PlayerActivity.CTRL_IDS[i].equals(id)) {
                                idx = i;
                                break;
                            }
                        }
                        if (idx < 0) {
                            continue;
                        }
                        android.widget.FrameLayout cell =
                                new android.widget.FrameLayout(act);
                        int sz = (int) (34 * d);
                        cell.setLayoutParams(new LinearLayout.LayoutParams(sz, sz));
                        if ("speed".equals(id)) {
                            TextView tv = new TextView(act);
                            tv.setText("1x");
                            tv.setTextSize(11f);
                            tv.setTextColor(0xFFFFFFFF);
                            tv.setGravity(Gravity.CENTER);
                            android.widget.FrameLayout.LayoutParams flp =
                                    new android.widget.FrameLayout.LayoutParams(sz, sz);
                            flp.gravity = Gravity.CENTER;
                            cell.addView(tv, flp);
                        } else {
                            ImageView iv = new ImageView(act);
                            iv.setImageResource(PlayerActivity.CTRL_ICONS[idx]);
                            iv.setColorFilter(0xFFF0F0F8);
                            int ip = (int) (7 * d);
                            android.widget.FrameLayout.LayoutParams flp =
                                    new android.widget.FrameLayout.LayoutParams(
                                            sz - ip, sz - ip);
                            flp.gravity = Gravity.CENTER;
                            cell.addView(iv, flp);
                        }
                        // 点预览中的项可移除
                        cell.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                current.remove(id);
                                save.run();
                                repaint[0].run();
                            }
                        });
                        preview.addView(cell);
                    }
                }
                count.setText("已选 " + current.size() + " / 5    （点击预览中的按键可移除）");
            }
        };



        // ---- 候选区 ----
        TextView t2 = new TextView(act);
        t2.setText("点击添加（最多 5 个）");
        t2.setTextSize(12.5f);
        t2.setTextColor(0xFFF0F0F5);
        LinearLayout.LayoutParams t2p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        t2p.topMargin = 12 * d;
        t2.setLayoutParams(t2p);
        box.addView(t2);

        final FlowLayout fl = new FlowLayout(act);
        fl.setGaps(8 * d, 8 * d);
        fl.setPadding(0, 8 * d, 0, 4 * d);
        for (int i = 0; i < PlayerActivity.CTRL_IDS.length; i++) {
            final String id = PlayerActivity.CTRL_IDS[i];
            final int idx = i;
            TextView t = new TextView(act);
            t.setText(PlayerActivity.CTRL_LABELS[idx]);
            t.setTag(id);
            t.setTextSize(12.5f);
            t.setGravity(Gravity.CENTER);
            t.setPadding(14 * d, 8 * d, 14 * d, 8 * d);
            t.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (current.contains(id)) {
                        current.remove(id);
                    } else {
                        if (current.size() >= 5) {
                            Ui.toast(act, "最多 5 个按键");
                            return;
                        }
                        current.add(id);
                    }
                    save.run();
                    repaint[0].run();
                    repaintChips(fl, current);
                }
            });
            fl.addView(t);
        }
        repaintChips(fl, current);
        box.addView(fl);

        TextView def = new TextView(act);
        def.setText("恢复默认（倍速 / 画面比例 / 小窗）");
        def.setTextSize(12f);
        def.setTextColor(accent);
        def.setPadding(0, 10 * d, 0, 4 * d);
        def.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                current.clear();
                current.add("speed");
                current.add("aspect");
                current.add("pip");
                save.run();
                repaint[0].run();
                repaintChips(fl, current);
            }
        });
        box.addView(def);

        repaint[0].run();
        act.hideControls();
        Ui.panel(act, "控制栏按键", box, true, null);
    }

    private void repaintChips(FlowLayout fl, List<String> current) {
        for (int i = 0; i < fl.getChildCount(); i++) {
            View v = fl.getChildAt(i);
            if (!(v instanceof TextView)) {
                continue;
            }
            TextView t = (TextView) v;
            Object tag = t.getTag();
            boolean on = tag != null && current.contains(tag.toString());
            t.setTextColor(on ? Color.WHITE : 0xFFDDDDE6);
            t.setBackgroundResource(on ? R.drawable.bg_panel_btn_sel
                    : R.drawable.bg_panel_btn);
        }
    }


    public void doRatio() {
        showRatio();
    }

    public void doOrientation() {
        showOrientation();
    }

    public void doRepeat() {
        showRepeat();
    }

    public void doDecode() {
        showDecode();
    }

    public void doBoost() {
        showBoost();
    }

    public void doBrightVol() {
        showBrightVol();
    }

    public void doFlip() {
        showFlip();
    }

    public void doJump() {
        showJump();
    }

    /* ==================== 通用控件 ==================== */
    interface ChipsCb {
        void onPick(int index);
    }

    interface OnVal {
        void onVal(int v);
    }

    interface Fmt2 {
        String fmt(int v);
    }

    private void chips(String title, final String[] names, int selected,
                       final ChipsCb cb) {
        final FlowLayout fl = new FlowLayout(act);
        fl.setGaps(8 * d, 8 * d);
        fl.setPadding(10 * d, 8 * d, 10 * d, 8 * d);
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            final boolean on = i == selected;
            TextView t = new TextView(act);
            t.setText(names[i]);
            t.setTextSize(13f);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(on ? Color.WHITE : 0xFFDDDDE6);
            t.setBackgroundResource(on ? R.drawable.bg_panel_btn_sel : R.drawable.bg_panel_btn);
            t.setPadding(16 * d, 9 * d, 16 * d, 9 * d);
            t.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    repaint(fl, idx);
                    cb.onPick(idx);
                }
            });
            fl.addView(t);
        }
        Ui.panel(act, title, fl, true, null);
    }

    private void repaint(FlowLayout fl, int sel) {
        for (int i = 0; i < fl.getChildCount(); i++) {
            View v = fl.getChildAt(i);
            if (v instanceof TextView) {
                TextView t = (TextView) v;
                boolean on = (i == sel);
                t.setTextColor(on ? Color.WHITE : 0xFFDDDDE6);
                t.setBackgroundResource(on ? R.drawable.bg_panel_btn_sel
                        : R.drawable.bg_panel_btn);
            }
        }
    }

    private void makeSliderRow(String title, int value, int min, int max,
                               final OnVal cb, final Fmt2 fmt, String panelTitle) {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14 * d, 12 * d, 14 * d, 12 * d);
        box.addView(makeSliderFmt(title, value, min, max, cb, fmt));
        Ui.panel(act, panelTitle, box, true, null);
    }

    private View makeSlider(String title, int value, final int min, int max,
                            final OnVal cb) {
        return makeSliderFmt(title, value, min, max, cb, new Fmt2() {
            public String fmt(int v) {
                return v + " dp";
            }
        });
    }

    private View makeSliderFmt(String title, int value, final int min, int max,
                               final OnVal cb, final Fmt2 fmt) {
        LinearLayout ll = new LinearLayout(act);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setPadding(0, 10 * d, 0, 6 * d);

        LinearLayout top = new LinearLayout(act);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView a = new TextView(act);
        a.setText(title);
        a.setTextSize(12.5f);
        a.setTextColor(0xFFF0F0F5);
        a.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView b = new TextView(act);
        b.setText(fmt.fmt(value));
        b.setTextSize(12.5f);
        b.setTextColor(accent);
        top.addView(a);
        top.addView(b);
        ll.addView(top);

        SeekBar sb = new SeekBar(act);
        sb.setMax(max - min);
        sb.setProgress(Math.max(0, Math.min(max - min, value - min)));
        sb.setProgressDrawable(act.getResources().getDrawable(R.drawable.progress_player));
        sb.setThumb(act.getResources().getDrawable(R.drawable.thumb_seek));
        sb.setSplitTrack(false);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s2, int p, boolean fromUser) {
                b.setText(fmt.fmt(p + min));
                if (fromUser) {
                    cb.onVal(p + min);
                }
            }

            public void onStartTrackingTouch(SeekBar s2) {
            }

            public void onStopTrackingTouch(SeekBar s2) {
                cb.onVal(s2.getProgress() + min);
            }
        });
        ll.addView(sb);
        return ll;
    }

    private View makeChips(String title, String[] names, int sel, final OnVal cb) {
        LinearLayout ll = new LinearLayout(act);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setPadding(0, 8 * d, 0, 4 * d);
        TextView a = new TextView(act);
        a.setText(title);
        a.setTextSize(12.5f);
        a.setTextColor(0xFFF0F0F5);
        ll.addView(a);

        final FlowLayout fl = new FlowLayout(act);
        fl.setGaps(8 * d, 8 * d);
        fl.setPadding(0, 6 * d, 0, 0);
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            final boolean on = i == sel;
            TextView t = new TextView(act);
            t.setText(names[i]);
            t.setTextSize(13f);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(on ? Color.WHITE : 0xFFDDDDE6);
            t.setBackgroundResource(on ? R.drawable.bg_panel_btn_sel : R.drawable.bg_panel_btn);
            t.setPadding(16 * d, 9 * d, 16 * d, 9 * d);
            t.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    repaint(fl, idx);
                    cb.onVal(idx);
                }
            });
            fl.addView(t);
        }
        ll.addView(fl);
        return ll;
    }
}
