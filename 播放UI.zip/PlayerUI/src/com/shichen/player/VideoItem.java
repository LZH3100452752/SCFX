package com.shichen.player;

public class VideoItem {
    public long id;
    public String path = "";
    public String title = "";
    public long duration;
    public long size;
    public long dateAdded;
    public long dateModified;
    public int width;
    public int height;
    public String bucket = "";
    public long lastPlay;
    public long position;
    public boolean fav;
    public String mime = "";
    public int fps = 0;

    public VideoItem() {
    }

    public String dir() {
        int i = path.lastIndexOf('/');
        return i > 0 ? path.substring(0, i) : path;
    }

    public String dirName() {
        String d = dir();
        int i = d.lastIndexOf('/');
        String n = i >= 0 ? d.substring(i + 1) : d;
        return n.length() == 0 ? d : n;
    }

    public String nameNoExt() {
        String n = title;
        int i = n.lastIndexOf('.');
        return i > 0 ? n.substring(0, i) : n;
    }

    public String ext() {
        int i = title.lastIndexOf('.');
        if (i < 0) {
            return "";
        }
        return title.substring(i + 1).toLowerCase();
    }

    public String resolution() {
        if (width > 0 && height > 0) {
            return width + "x" + height;
        }
        return "";
    }

    public long pixels() {
        return (long) width * (long) height;
    }

    /** 观看状态：0 未看 1 看过一点 2 看完 */
    public int watchState() {
        if (duration <= 0) {
            return 0;
        }
        if (position <= 0) {
            return 0;
        }
        if (position >= duration * 0.95) {
            return 2;
        }
        return 1;
    }

    public boolean exists() {
        return path != null && path.length() > 0;
    }
}
